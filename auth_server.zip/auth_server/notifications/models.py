from django.db import models
from accounts.models import BaseModel, CustomUser
# Create your models here.

class NotificationTemplate(BaseModel):
    name = models.CharField(max_length=255)
    subject = models.CharField(max_length=255)
    body = models.TextField()

    def __str__(self):
        return self.name


class Notification(BaseModel):
    recipient = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    template = models.ForeignKey(NotificationTemplate, on_delete=models.CASCADE)
    is_read = models.BooleanField(default=False)

    def __str__(self):
        return f"To: {self.recipient} - {self.template.name} ({'Read' if self.is_read else 'Unread'})"