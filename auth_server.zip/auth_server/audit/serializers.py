from rest_framework import serializers
from audit.models import *

class AuditLogTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = AuditLogType
        fields = '__all__'

class AuditLogEntrySerializer(serializers.ModelSerializer):
    class Meta:
        model = AuditLogEntry
        fields = '__all__'
        depth = 1  # T