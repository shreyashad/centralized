from django.shortcuts import render
from rest_framework import viewsets
from audit.models import *
from audit.serializers import *
from rest_framework.permissions import IsAuthenticated
from accounts.permissions import IsAdminOrReadOnly
# Create your views here.


class AuditLogTypeViewSet(viewsets.ModelViewSet):
    queryset = AuditLogType.objects.all()
    serializer_class = AuditLogTypeSerializer
    permission_classes = [IsAdminOrReadOnly]

class AuditLogEntryViewSet(viewsets.ModelViewSet):
    queryset = AuditLogEntry.objects.all()
    serializer_class = AuditLogEntrySerializer
    permission_classes = [IsAdminOrReadOnly]