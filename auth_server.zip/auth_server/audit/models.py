from django.db import models
from accounts.models import BaseModel,CustomUser
from django.contrib.contenttypes.models import ContentType
from django.contrib.contenttypes.fields import GenericForeignKey
# Create your models here.


class AuditLogType(BaseModel):
    name = models.CharField(max_length=255, unique=True)
    description = models.TextField(blank=True)

    def __str__(self):
        return self.name


class AuditLogEntry(BaseModel):
    user = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, blank=True)
    action_type = models.ForeignKey(AuditLogType, on_delete=models.SET_NULL, null=True, blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    object_id = models.CharField(max_length=255)
    object_type = models.ForeignKey(ContentType, on_delete=models.SET_NULL, null=True, blank=True)
    content_object = GenericForeignKey('object_type', 'object_id')
    details = models.TextField()

    def __str__(self):
        return f"{self.action_type} on {self.object_type} - {self.timestamp}"