from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from accounts.serializers import *
from accounts.models import *
from rest_framework.decorators import api_view
from rest_framework.permissions import AllowAny
from org.serializers import *

# Create your views here.

#for authentication related views


class LoginAPIView(APIView):
    serializer_class = LoginSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        response_data = serializer.save()

        return Response(response_data, status=status.HTTP_200_OK)


class UserRegistrationAPIView(APIView):
    serializer_class = UserRegistrationSerializer

    def post(self, request, *args, **kwargs):
        data = request.data
        serializer = self.serializer_class(data=data)
        if serializer.is_valid():
            serializer.save()
            return Response({"message": "User registered successfully"}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)





class OrgNameList(APIView):
    permission_classes = [AllowAny]

    def get(self, request, *args, **kwargs):
        org_type = request.query_params.get('orgType')
        if org_type:
            organizations = Organization.objects.filter(org_type=org_type)
        else:
            organizations = Organization.objects.all()
        serializer = OrganizationSerializer(organizations, many=True)
        return Response(serializer.data)


class OrgSubTypeList(APIView):
    permission_classes = [AllowAny]

    def get(self, request, *args, **kwargs):
        org_type = request.query_params.get('orgType')
        if org_type:
            org_sub_types = OrganizationSubType.objects.filter(org_type=org_type)
        else:
            org_sub_types = OrganizationSubType.objects.all()
        serializer = OrganizationSubTypeSerializer(org_sub_types, many=True)
        return Response(serializer.data)

class LocationTypeList(APIView):
    permission_classes = [AllowAny]

    def get(self, request, *args, **kwargs):
        org_name = request.query_params.get('orgName')
        if org_name:
            locations = Locations.objects.filter(org_name=org_name)
        else:
            locations = Locations.objects.all()
        serializer = LocationsSerializer(locations, many=True)
        return Response(serializer.data)

class LocationNamesAndCodesList(APIView):
    permission_classes = [AllowAny]

    def get(self, request, *args, **kwargs):
        org_name = request.query_params.get('orgName')
        location_type = request.query_params.get('locationType')
        if org_name and location_type:
            locations = Locations.objects.filter(org_name=org_name, location_type=location_type)
        elif org_name:
            locations = Locations.objects.filter(org_name=org_name)
        elif location_type:
            locations = Locations.objects.filter(location_type=location_type)
        else:
            locations = Locations.objects.all()
        serializer = LocationsSerializer(locations, many=True)
        return Response(serializer.data)



# for all user related CURD operations


class UserListView(APIView):
    def get(self, request, *args, **kwargs):
        users = CustomUser.objects.all()
        serializer = CustomUsersSerializer(users, many=True)
        return Response(serializer.data)




class UserDetailView(APIView):
    def get_object(self, pk):
        return CustomUser.object.filter(id=pk).first()

    def get(self, request, pk, format=None):
        self.object = self.get_object(pk)
        if not self.object:
            return Response(
                {
                    "error": True,
                    "errors": "User does not exist",
                    "status": status.HTTP_403_FORBIDDEN
                }

            )
        if self.request.userprofile.role != "ADMINISTRATOR" and not self.request.user.is_superuser:
            if not (
                    (self.request.user == self.object.created_by)

            ):
                return Response(
                    {
                        "error": True,
                        "errors": "You don not have Permission to perform this action",
                    },
                    status=status.HTTP_403_FORBIDDEN,
                )

    def delete(self, request, pk, format=None):
        user = self.get_object(pk)
        if not user:
            return Response(
                {
                    "error": True,
                    "errors": "User does not exist"
                    ,
                },
                status=status.HTTP_403_FORBIDDEN,

            )
        user.delete()
        return Response(
            {
                "error": False,
                "message": "User deleted Successfully"
            },
            status=status.HTTP_200_OK,
        )

    def put(self, request, pk, format=None):
        self.object = self.get_object(pk)
        params = request.data
        if not self.object:
            return Response(
                {
                    "error": True,
                    "errors": "User does not exist"
                },
                status=status.HTTP_403_FORBIDDEN,
            )
        serializer = CustomUsersSerializer()
        if serializer.is_valid():
            user = serializer.save()
            return Response(
                {
                    "error": False,
                    "message": "User Updated Successfully"
                },
                status=status.HTTP_200_OK
            )
        return Response(
            {"error": True, "errors": serializer.errors},
            status=status.HTTP_400_BAD_REQUEST,
        )
#
# @api_view(['GET'])
# def get_org_names(request):
#     org_type = request.GET.get('org_type')
#     if org_type:
#         org_names = Organization.objects.filter(org_type=org_type).values('id', 'name')
#         return Response(list(org_names), status=status.HTTP_200_OK)
#     return Response({"error": "orgType parameter is required"}, status=status.HTTP_400_BAD_REQUEST)
#
# @api_view(['GET'])
# def get_org_sub_types(request):
#     org_type = request.GET.get('orgType')
#     if org_type:
#         org_sub_types = OrganizationSubType.objects.filter(org_type=org_type).values('id', 'subtype')
#         return Response(list(org_sub_types), status=status.HTTP_200_OK)
#     return Response({"error": "orgType parameter is required"}, status=status.HTTP_400_BAD_REQUEST)
#
# @api_view(['GET'])
# def get_location_types(request):
#     org_name = request.GET.get('orgName')
#     if org_name:
#         location_types = Locations.objects.filter(org_name=org_name).values_list('location_type', flat=True).distinct()
#         return Response(list(location_types), status=status.HTTP_200_OK)
#     return Response({"error": "orgName parameter is required"}, status=status.HTTP_400_BAD_REQUEST)
#
# @api_view(['GET'])
# def get_location_names_and_codes(request):
#     org_name = request.GET.get('orgName')
#     location_type = request.GET.get('locationType')
#     if org_name and location_type:
#         locations = Locations.objects.filter(org_name=org_name, location_type=location_type)
#         location_names = locations.values('id', 'location_name')
#         location_codes = locations.values('id', 'location_code')
#         return Response({'names': list(location_names), 'codes': list(location_codes)}, status=status.HTTP_200_OK)
#     return Response({"error": "orgName and locationType parameters are required"}, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
def get_total_user_count(request, format=None):
    total_user = CustomUser.objects.count()
    content = {'total_user': total_user}
    return Response(content)

@api_view(['GET'])
def get_active_user_count(request, format=None):
    active_user = CustomUser.objects.filter(is_online=True).count()
    content = {'active_user': active_user}
    return Response(content)

@api_view(['GET'])
def get_verification_pending_count(request, format=None):
    verification_pending = CustomUser.objects.filter(is_verified=False).count()
    content = {'verification_pending': verification_pending}
    return Response(content)
