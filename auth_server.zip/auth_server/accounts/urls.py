from django.urls import path
from .views import *

urlpatterns = [
    path('login/', LoginAPIView.as_view(), name='login'),
    path('register/', UserRegistrationAPIView.as_view(), name='register_user'),
    path('org-names/', OrgNameList.as_view(), name='org-name-list'),
    path('org-sub-types/', OrgSubTypeList.as_view(), name='org-sub-type-list'),
    path('location-types/', LocationTypeList.as_view(), name='location-type-list'),
    path('location-names-and-codes/', LocationNamesAndCodesList.as_view(), name='location-names-codes-list'),
    path('user-list/', UserListView.as_view(), name='user_list'),
    path('user/<uuid:pk>/detail/', UserDetailView.as_view(), name="user_details"),
    path('total-users/', get_total_user_count, name='total_user_count'),
    path('active-users/', get_active_user_count, name='active_user_count'),
    path('verification-pending/', get_verification_pending_count, name='verification_pending'),
]

