from rest_framework import serializers
from accounts.models import *
from org.models import *
from django.contrib.auth import authenticate
from rest_framework_simplejwt.tokens import RefreshToken
from roles.models import UserRole, Application
from django.contrib.auth.password_validation import validate_password




class LoginSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField(style={'input_type': 'password'}, trim_whitespace=False)
    application_token = serializers.CharField(max_length=255)


    def validate(self, data):
        username = data.get('username')
        password = data.get('password')
        application_token = data.get('application_token')

        if username and password and application_token:
            user = authenticate(username=username, password=password)
            if user:
                if not user.is_active:
                    raise serializers.ValidationError("User account is disabled.")
                if not user.is_verified:
                    raise serializers.ValidationError("User is not been verified please contact your administrator.")

                try:
                    application = Application.objects.get(token=application_token)
                except Application.DoesNotExist:
                    raise serializers.ValidationError("Invalid application token.")

                data['user'] = user
                data['application'] = application
            else:
                raise serializers.ValidationError("Unable to log in with provided credentials.")
        else:
            raise serializers.ValidationError("Must include 'username','password', and 'application_token'.")


        return data


    def create(self, validated_data):
        user = validated_data['user']
        refresh = RefreshToken.for_user(user)

        user_roles = UserRole.objects.filter(user=user)
        roles_data = [
            {
                'role': role.role.name,
                'application': role.application.name,

            }
        ]
        return {
            'refresh': str(refresh),
            'access': str(refresh.access_token),
            'user': {
                'id': str(user.id),
                'username': user.username,
                'first_name': user.first_name,
                'last_name': user.last_name,
                'roles': roles_data
            }
        }







class UserAuthenticationSerializer(serializers.Serializer):
    username = serializers.CharField(max_length=150)
    password = serializers.CharField(max_length=128, write_only=True)

    def validate(self, attrs):
        username = attrs.get('username')
        password = attrs.get('password')

        if username and password:
            user = authenticate(username=username, password=password)

            if user:
                if not user.is_active:
                    raise serializers.ValidationError("User account is disabled.")
                return user
            else:
                raise serializers.ValidationError("Unable to login with provided credentials.")
        else:
            raise serializers.ValidationError("Must include 'username' and 'password'.")



class CustomUsersSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = ['id','username', 'first_name', 'last_name','org_type', 'org_name', 'emp_code', 'is_online', 'is_verified' ]



class UserRegistrationSerializer(serializers.ModelSerializer):
    first_name = serializers.CharField(max_length=150)
    last_name = serializers.CharField(max_length=150)
    org_type = serializers.ChoiceField(choices=OrgType.choices)
    org_name = serializers.ChoiceField(choices=[])
    org_sub_type = serializers.ChoiceField(choices=[])
    location_type = serializers.ChoiceField(choices=[])
    location_name = serializers.ChoiceField(choices=[])
    location_code = serializers.ChoiceField(choices=[])
    department = serializers.PrimaryKeyRelatedField(queryset=Department.objects.all())
    designation = serializers.PrimaryKeyRelatedField(queryset=Designation.objects.all())
    mobile = PhoneNumberField()
    username = serializers.CharField(max_length=150)
    emp_code = serializers.CharField(max_length=150)
    password = serializers.CharField(write_only=True, required=True, validators=[validate_password])
    confirm_password = serializers.CharField(write_only=True, required=True)

    class Meta:
        model = CustomUser
        fields = [
            'first_name', 'last_name', 'org_type', 'org_name', 'org_sub_type',
            'location_type', 'location_name', 'location_code', 'department',
            'designation', 'mobile', 'username', 'emp_code', 'password', 'confirm_password'
        ]

    def __int__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['org_name'].choices = self.get_org_name_choices([])
        self.fields['org_sub_type'].choices = self.get_org_sub_type_choices([])
        self.fields['location_type'].choices = self.get_location_type_choices([])
        self.fields['location_name'].choices = self.get_location_name_choices([])
        self.fields['location_code'].choices = self.get_location_code_choices([])

    def get_org_name_choices(self, org_type):
        queryset = Organization.objects.filter(org_type=org_type).values_list('id', 'name')
        return [(item[0], item[1]) for item in queryset]

    def get_org_sub_type_choices(self, org_type):
        queryset = OrganizationSubType.objects.filter(org_type=org_type).values_list('id', 'subtype')
        return [(item[0], item[1]) for item in queryset]

    def get_location_type_choices(self, org_name):
        queryset = Locations.objects.filter(org_name=org_name).values_list('id', 'location_type')
        return [(item[0], item[1]) for item in queryset]

    def get_location_name_choices(self, location_type):
        queryset = Locations.objects.filter(location_type=location_type).values_list('id', 'location_name')
        return [(item[0], item[1]) for item in queryset]

    def get_location_code_choices(self, location_type):
        queryset = Locations.objects.filter(location_type=location_type).values_list('id', 'location_code')
        return [(item[0], item[1]) for item in queryset]

    def validate(self, attrs):
        if attrs['password'] != attrs['confirm_password']:
            raise serializers.ValidationError({"password": "Password fields didn't match."})
        if CustomUser.objects.filter(username=attrs['username']).exists():
            raise serializers.ValidationError({"username": "This username is already taken."})
        if CustomUser.objects.filter(mobile=attrs['mobile']).exists():
            raise serializers.ValidationError({"mobile": "This mobile number is already registered."})
        if CustomUser.objects.filter(emp_code=attrs['emp_code']).exists():
            raise serializers.ValidationError({"emp_code": "This employee code is already registered."})
        return attrs

    def create(self, validated_data):
        validated_data.pop('confirm_password')
        password = validated_data.pop('password')
        user = CustomUser(**validated_data)
        user.set_password(password)
        user.save()
        return user