from django.shortcuts import render
from rest_framework import viewsets
from .models import Report
from .serializers import ReportSerializer
from accounts.permissions import IsAdminOrReadOnly
# Create your views here.
# reports/views.py


class ReportViewSet(viewsets.ModelViewSet):
    queryset = Report.objects.all()
    serializer_class = ReportSerializer
    permission_classes = [IsAdminOrReadOnly]
