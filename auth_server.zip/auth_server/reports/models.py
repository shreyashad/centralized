from django.db import models
from accounts.models import BaseModel, CustomUser

# Create your models here.

class Report(BaseModel):
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    generated_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, blank=True)
    generated_at = models.DateTimeField(auto_now_add=True)
    file = models.FileField(upload_to='reports/')

    def __str__(self):
        return self.name