# teams/views.py
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, generics
from rest_framework.permissions import IsAuthenticated
from teams.models import *
from .serializers import *
from accounts.permissions import IsAdminOrReadOnly
from django.db import IntegrityError


# team related CURD operations

class TeamListView(APIView):
    def get(self, request):
        teams = Team.objects.all()
        serializer = TeamSerializer(teams, many=True)
        return Response(serializer.data)


class TeamCreateView(APIView):
    serializer_class = TeamSerializer

    def post(self,request, format=None):
        data = request.data
        serializer = self.serializer_class(data=data)
        if serializer.is_valid():
            try:
                team_obj = serializer.save(created_by=request.user, updated_by=request.user)
                return Response(
                    {"error": False, "message": "New Team is created ", "team": self.serializer_class(team_obj).data},
                    status=status.HTTP_201_CREATED,
                )
            except IntegrityError:
                return Response(
                    {"error": True, "message": "An team with this name already exists."},
                    status=status.HTTP_400_BAD_REQUEST
                )
            else:
                return Response(
                    {"error": True,"errors": serializer.errors,},
                    status=status.HTTP_400_BAD_REQUEST
                )


class TeamDetailView(APIView):
    serializer_class = TeamSerializer

    def get_object(self, pk):
        try:
            return Team.object.get(pk=pk)
        except Team.DoesNotExist:
            return None

    def get(self, request, pk):
        try :
            team = self.get_object(pk)
            if not team:
                return Response(
                    {"error": True, "errors": "Team does not exist "},
                    status=status.HTTP_404_NOT_FOUND,
                )

            user = request.user
            if user.role != "ADMINISTRATOR" and not user.is_superuser and org.created_by != user:
                return Response(
                    {"error": True, "errors": "You do not have permission to perform this action"},
                    status=status.HTTP_403_FORBIDDEN,
                )
            serializer = self.serializer_class(team)
            return Response(serializer.data)
        except ValueError:
            return Response(
                {"error": True, "errors": "Invalid UUID format"},
                status=status.HTTP_400_BAD_REQUEST,
            )

    def delete(self, request, pk, format=None):
        try:
            team = self.get_object(pk)
            if not team:
                return Response(
                    {"error": True, "errors": "Team does not exist"},
                    status=status.HTTP_404_NOT_FOUND,
                )
            team.delete()
            return Response(
                {"error": False, "message": "team deleted successfully"},
                status=status.HTTP_200_OK,
            )
        except ValueError:
            return Response(
                {"error": True, "errors": "Invalid UUID format"},
                status=status.HTTP_400_BAD_REQUEST,
            )
    def put(self, request, pk, format=None):
        try:
            team = self.get_object(pk)
            if not team:
                return Response(
                    {"error": True, "errors": "Team does not exist"},
                    status=status.HTTP_404_NOT_FOUND,
                )

                serializer = self.serializer_class(team, data=request.data)
                if serializer.is_valid():
                    serializer.save(updated_by=request.user)
                    return Response(
                        {"error": False, "message": "Team updated successfully"},
                        status=status.HTTP_200_OK,
                    )
                return Response(
                    {"error": True, "errors": serializer.errors},
                    status=status.HTTP_400_BAD_REQUEST,
                )

        except ValueError:
            return Response(
                {"error": True, "errors": "Invalid UUID format"},
                status=status.HTTP_400_BAD_REQUEST,
            )


# Team Membership Views

class AddUserToTeamView(APIView):

    def post(self, request, team_id, user_id):
        role = request.data.get("role", "member")
        try:
            team = Team.objects.get(id=team_id)
            user = CustomUser.objects.get(id=user_id)
            TeamMembership.objects.create(team=team,user=user,role=role)
            return Response({"detail": "User added to team"}, status=status.HTTP_200_OK)
        except (Team.DoesNotExist, CustomUser.DoesNotExist):
            return Response({"detail": "Team or User not found"}, status=status.HTTP_404_NOT_FOUND)


class RemoveUserFromTeamView(APIView):

    def post(self, request, team_id, user_id):
        try:
            team_membership = TeamMembership.objects.get(team_id=team_id, user_id=user_id)
            team_membership.delete()
            return Response({"detail": "User removed from team"}, status=status.HTTP_200_OK)
        except TeamMembership.DoesNotExist:
            return Response({"detail": "Team membership not found"}, status=status.HTTP_404_NOT_FOUND)

class ListUsersInTeamView(generics.ListAPIView):
    serializer_class = TeamsCustomUserSerializer

    def get_queryset(self):
        team_id = self.kwargs['team_id']
        return CustomUser.objects.filter(teammembership__team_id=team_id)
