from rest_framework import generics, permissions
from .models import Team
from .serializers import TeamSerializer

class TeamListCreateView(generics.ListCreateAPIView):
    queryset = Team.objects.all()
    serializer_class = TeamSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save()

from rest_framework import generics, permissions
from .models import Team
from .serializers import TeamSerializer

class TeamDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Team.objects.all()
    serializer_class = TeamSerializer
    permission_classes = [permissions.IsAuthenticated]



from rest_framework import views, status
from rest_framework.response import Response
from .models import Team, CustomUser
from .serializers import TeamSerializer

class AddUserToTeamView(views.APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, team_id, user_id):
        try:
            team = Team.objects.get(id=team_id)
            user = CustomUser.objects.get(id=user_id)
            team.users.add(user)
            team.save()
            return Response({"detail": "User added to team"}, status=status.HTTP_200_OK)
        except (Team.DoesNotExist, CustomUser.DoesNotExist):
            return Response({"detail": "Team or User not found"}, status=status.HTTP_404_NOT_FOUND)

class RemoveUserFromTeamView(views.APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, team_id, user_id):
        try:
            team = Team.objects.get(id=team_id)
            user = CustomUser.objects.get(id=user_id)
            team.users.remove(user)
            team.save()
            return Response({"detail": "User removed from team"}, status=status.HTTP_200_OK)
        except (Team.DoesNotExist, CustomUser.DoesNotExist):
            return Response({"detail": "Team or User not found"}, status=status.HTTP_404_NOT_FOUND)


from rest_framework import generics, permissions
from .models import Team, CustomUser
from .serializers import CustomUserSerializer

class ListUsersInTeamView(generics.ListAPIView):
    serializer_class = CustomUserSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        team_id = self.kwargs['team_id']
        return CustomUser.objects.filter(teams__id=team_id)

from rest_framework import views, status
from rest_framework.response import Response
from .models import Team, CustomUser, TeamRole
from .serializers import TeamRoleSerializer

class AssignRoleToUserView(views.APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, team_id, user_id):
        role = request.data.get("role")
        try:
            team = Team.objects.get(id=team_id)
            user = CustomUser.objects.get(id=user_id)
            team_role, created = TeamRole.objects.get_or_create(team=team, user=user)
            team_role.role = role
            team_role.save()
            return Response({"detail": "Role assigned to user"}, status=status.HTTP_200_OK)
        except (Team.DoesNotExist, CustomUser.DoesNotExist):
            return Response({"detail": "Team or User not found"}, status=status.HTTP_404_NOT_FOUND)

from rest_framework import views, status
from rest_framework.response import Response
from .models import Team, CustomUser, TeamInvitation
from .serializers import TeamInvitationSerializer

class InviteUserToTeamView(views.APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, team_id):
        email = request.data.get("email")
        try:
            team = Team.objects.get(id=team_id)
            invitation = TeamInvitation.objects.create(team=team, email=email)
            invitation.save()
            # Send email invitation logic here
            return Response({"detail": "Invitation sent"}, status=status.HTTP_200_OK)
        except Team.DoesNotExist:
            return Response({"detail": "Team not found"}, status=status.HTTP_404_NOT_FOUND)

from rest_framework import generics, permissions
from .models import Team
from .serializers import TeamSerializer

class FilterTeamsView(generics.ListAPIView):
    serializer_class = TeamSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        query_params = self.request.query_params
        queryset = Team.objects.all()
        if 'attribute' in query_params:
            queryset = queryset.filter(attribute=query_params['attribute'])
        return queryset

from django.db.models.signals import m2m_changed
from django.dispatch import receiver
from .models import Team

@receiver(m2m_changed, sender=Team.users.through)
def notify_user_team_change(sender, instance, action, **kwargs):
    if action == "post_add" or action == "post_remove":
        # Notify users about the change
        pass

-------------------------------
from django.db import models
from accounts.models import CustomUser

class Team(models.Model):
    name = models.CharField(max_length=150)
    description = models.TextField()
    users = models.ManyToManyField(CustomUser, through='TeamMembership')
    created_at = models.DateTimeField(auto_now_add=True)

class TeamMembership(models.Model):
    team = models.ForeignKey(Team, on_delete=models.CASCADE)
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    role = models.CharField(max_length=50, choices=(('admin', 'Admin'), ('member', 'Member')))

    class Meta:
        unique_together = ('team', 'user')

from django.db import models

class TeamInvitation(models.Model):
    team = models.ForeignKey(Team, on_delete=models.CASCADE)
    email = models.EmailField()
    invited_at = models.DateTimeField(auto_now_add=True)
    accepted = models.BooleanField(default=False)
    accepted_at = models.DateTimeField(null=True, blank=True)

    def accept(self):
        self.accepted = True
        self.accepted_at = timezone.now()
        self.save()

from rest_framework import serializers
from .models import Team, TeamMembership

class TeamSerializer(serializers.ModelSerializer):
    class Meta:
        model = Team
        fields = ['id', 'name', 'description', 'created_at']
from rest_framework import serializers
from accounts.models import CustomUser

class CustomUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = ['id', 'username', 'email']
from rest_framework import serializers
from .models import TeamMembership

class TeamMembershipSerializer(serializers.ModelSerializer):
    class Meta:
        model = TeamMembership
        fields = ['team', 'user', 'role']
from rest_framework import serializers
from .models import TeamInvitation

class TeamInvitationSerializer(serializers.ModelSerializer):
    class Meta:
        model = TeamInvitation
        fields = ['id', 'team', 'email', 'invited_at', 'accepted', 'accepted_at']

from rest_framework import generics, permissions
from .models import Team
from .serializers import TeamSerializer

class TeamListCreateView(generics.ListCreateAPIView):
    queryset = Team.objects.all()
    serializer_class = TeamSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save()

from rest_framework import generics, permissions
from .models import Team
from .serializers import TeamSerializer

class TeamDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Team.objects.all()
    serializer_class = TeamSerializer
    permission_classes = [permissions.IsAuthenticated]


from rest_framework import views, status
from rest_framework.response import Response
from .models import Team, CustomUser, TeamMembership
from .serializers import TeamMembershipSerializer

class AddUserToTeamView(views.APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, team_id, user_id):
        role = request.data.get("role", "member")
        try:
            team = Team.objects.get(id=team_id)
            user = CustomUser.objects.get(id=user_id)
            TeamMembership.objects.create(team=team, user=user, role=role)
            return Response({"detail": "User added to team"}, status=status.HTTP_200_OK)
        except (Team.DoesNotExist, CustomUser.DoesNotExist):
            return Response({"detail": "Team or User not found"}, status=status.HTTP_404_NOT_FOUND)

class RemoveUserFromTeamView(views.APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, team_id, user_id):
        try:
            team_membership = TeamMembership.objects.get(team_id=team_id, user_id=user_id)
            team_membership.delete()
            return Response({"detail": "User removed from team"}, status=status.HTTP_200_OK)
        except TeamMembership.DoesNotExist:
            return Response({"detail": "Team membership not found"}, status=status.HTTP_404_NOT_FOUND)


from rest_framework import generics, permissions
from .models import Team, CustomUser, TeamMembership
from .serializers import CustomUserSerializer

class ListUsersInTeamView(generics.ListAPIView):
    serializer_class = CustomUserSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        team_id = self.kwargs['team_id']
        return CustomUser.objects.filter(teammembership__team_id=team_id)

from rest_framework import views, status
from rest_framework.response import Response
from .models import Team, CustomUser, TeamMembership

class AssignRoleToUserView(views.APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, team_id, user_id):
        role = request.data.get("role")
        try:
            team_membership = TeamMembership.objects.get(team_id=team_id, user_id=user_id)
            team_membership.role = role
            team_membership.save()
            return Response({"detail": "Role assigned to user"}, status=status.HTTP_200_OK)
        except TeamMembership.DoesNotExist:
            return Response({"detail": "Team membership not found"}, status=status.HTTP_404_NOT_FOUND)

from rest_framework import views, status
from rest_framework.response import Response
from .models import Team, TeamInvitation
from .serializers import TeamInvitationSerializer

class InviteUserToTeamView(views.APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, team_id):
        email = request.data.get("email")
        try:
            team = Team.objects.get(id=team_id)
            invitation = TeamInvitation.objects.create(team=team, email=email)
            invitation.save()
            # Add email sending logic here
            return Response({"detail": "Invitation sent"}, status=status.HTTP_200_OK)
        except Team.DoesNotExist:
            return Response({"detail": "Team not found"}, status=status.HTTP_404_NOT_FOUND)
------------------
from django.db import models
from accounts.models import BaseModel, CustomUser

class Team(BaseModel):
    name = models.CharField(max_length=150)
    description = models.TextField()
    users = models.ManyToManyField(CustomUser, through='TeamMembership', related_name='teams')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Team"
        verbose_name_plural = "Teams"
        ordering = ("-created_at",)

    def __str__(self):
        return self.name

    def get_user_ids(self):
        return list(self.users.values_list("id", flat=True))

    def get_usernames(self):
        return list(self.users.values_list("username", flat=True))


class TeamMembership(BaseModel):
    ROLE_CHOICES = [
        ('admin', 'Admin'),
        ('member', 'Member'),
        ('viewer', 'Viewer'),
    ]

    team = models.ForeignKey(Team, on_delete=models.CASCADE)
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    role = models.CharField(max_length=50, choices=ROLE_CHOICES)

    class Meta:
        unique_together = ('team', 'user')
        verbose_name = "Team Membership"
        verbose_name_plural = "Team Memberships"

    def __str__(self):
        return f"{self.user.username} - {self.team.name} - {self.role}"


class TeamInvitation(BaseModel):
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='invitations')
    email = models.EmailField()
    invited_at = models.DateTimeField(auto_now_add=True)
    accepted = models.BooleanField(default=False)
    accepted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        verbose_name = "Team Invitation"
        verbose_name_plural = "Team Invitations"

    def accept(self):
        self.accepted = True
        self.accepted_at = timezone.now()
        self.save()

    def __str__(self):
        return f"Invitation to {self.email} for {self.team.name}"


class TeamMetadata(BaseModel):
    team = models.OneToOneField(Team, on_delete=models.CASCADE, related_name='metadata')
    custom_field_1 = models.CharField(max_length=255, blank=True, null=True)
    custom_field_2 = models.CharField(max_length=255, blank=True, null=True)
    custom_field_3 = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        verbose_name = "Team Metadata"
        verbose_name_plural = "Team Metadata"

    def __str__(self):
        return f"Metadata for {self.team.name}"
from rest_framework import serializers
from .models import Team, TeamMembership, TeamInvitation, TeamMetadata
from accounts.models import CustomUser

class TeamSerializer(serializers.ModelSerializer):
    class Meta:
        model = Team
        fields = ['id', 'name', 'description', 'created_at']


class CustomUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = ['id', 'username', 'email']


class TeamMembershipSerializer(serializers.ModelSerializer):
    user = CustomUserSerializer()
    class Meta:
        model = TeamMembership
        fields = ['team', 'user', 'role']


class TeamInvitationSerializer(serializers.ModelSerializer):
    class Meta:
        model = TeamInvitation
        fields = ['id', 'team', 'email', 'invited_at', 'accepted', 'accepted_at']


class TeamMetadataSerializer(serializers.ModelSerializer):
    class Meta:
        model = TeamMetadata
        fields = ['team', 'custom_field_1', 'custom_field_2', 'custom_field_3']
from rest_framework import generics, permissions, views, status
from rest_framework.response import Response
from .models import Team, TeamMembership, TeamInvitation, TeamMetadata
from .serializers import TeamSerializer, CustomUserSerializer, TeamMembershipSerializer, TeamInvitationSerializer, TeamMetadataSerializer
from accounts.models import CustomUser

# Team Views
class TeamListCreateView(generics.ListCreateAPIView):
    queryset = Team.objects.all()
    serializer_class = TeamSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save()

class TeamDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Team.objects.all()
    serializer_class = TeamSerializer
    permission_classes = [permissions.IsAuthenticated]

# Team Membership Views
class AddUserToTeamView(views.APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, team_id, user_id):
        role = request.data.get("role", "member")
        try:
            team = Team.objects.get(id=team_id)
            user = CustomUser.objects.get(id=user_id)
            TeamMembership.objects.create(team=team, user=user, role=role)
            return Response({"detail": "User added to team"}, status=status.HTTP_200_OK)
        except (Team.DoesNotExist, CustomUser.DoesNotExist):
            return Response({"detail": "Team or User not found"}, status=status.HTTP_404_NOT_FOUND)

class RemoveUserFromTeamView(views.APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, team_id, user_id):
        try:
            team_membership = TeamMembership.objects.get(team_id=team_id, user_id=user_id)
            team_membership.delete()
            return Response({"detail": "User removed from team"}, status=status.HTTP_200_OK)
        except TeamMembership.DoesNotExist:
            return Response({"detail": "Team membership not found"}, status=status.HTTP_404_NOT_FOUND)

class ListUsersInTeamView(generics.ListAPIView):
    serializer_class = CustomUserSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        team_id = self.kwargs['team_id']
        return CustomUser.objects.filter(teammembership__team_id=team_id)

# Team Invitation Views
class InviteUserToTeamView(views.APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, team_id):
        email = request.data.get("email")
        try:
            team = Team.objects.get(id=team_id)
            invitation = TeamInvitation.objects.create(team=team, email=email)
            invitation.save()
            # Add email sending logic here
            return Response({"detail": "Invitation sent"}, status=status.HTTP_200_OK)
        except Team.DoesNotExist:
            return Response({"detail": "Team not found"}, status=status.HTTP_404_NOT_FOUND)

# Team Metadata Views
class TeamMetadataView(generics.RetrieveUpdateAPIView):
    queryset = TeamMetadata.objects.all()
    serializer_class = TeamMetadataSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_object(self):
        team_id = self.kwargs['team_id']
        return TeamMetadata.objects.get(team_id=team_id)


from rest_framework import serializers
from .models import Team, TeamMembership
from accounts.models import CustomUser

class CustomUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = ['id', 'username', 'email']

class TeamSerializer(serializers.ModelSerializer):
    users = serializers.SerializerMethodField()

    class Meta:
        model = Team
        fields = ['id', 'name', 'description', 'users', 'created_at']

    def get_users(self, obj):
        return [user.username for user in obj.users.all()]

class TeamMembershipSerializer(serializers.ModelSerializer):
    user = CustomUserSerializer()

    class Meta:
        model = TeamMembership
        fields = ['team', 'user', 'role']

class TeamInvitationSerializer(serializers.ModelSerializer):
    class Meta:
        model = TeamInvitation
        fields = ['id', 'team', 'email', 'invited_at', 'accepted', 'accepted_at']

class TeamMetadataSerializer(serializers.ModelSerializer):
    class Meta:
        model = TeamMetadata
        fields = ['team', 'custom_field_1', 'custom_field_2', 'custom_field_3']
