from django.db import models
from accounts.models import BaseModel,CustomUser
from django.utils import timezone
# Create your models here.


class TeamRole(models.TextChoices):
    ADMIN = 'admin', 'Admin'
    MEMBER = 'member', 'Member'


class Team(BaseModel):
    name = models.CharField(max_length=150)
    description = models.TextField()
    users = models.ManyToManyField("self", through='TeamMembership', related_name='teams')

    class Meta:
        verbose_name = "Team"
        verbose_name_plural = "Teams"
        ordering = ("-created_at",)

    def __str__(self):
        return self.name

    def get_user_ids(self):
        return list(self.users.values_list("id", flat=True))

    def get_usernames(self):
        return list(self.users.values_list("username", flat=True))


class TeamMembership(BaseModel):
    team = models.ForeignKey(Team, on_delete=models.CASCADE)
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    role = models.CharField(max_length=50, choices=TeamRole.choices)

    class Meta:
        unique_together = ('team', 'user')
        verbose_name = "Team Membership"
        verbose_name_plural = "Team Memberships"

    def __str__(self):
        return f"{self.user.username} - {self.team.name} - {self.role}"


class TeamInvitation(BaseModel):
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='invitations')
    email = models.EmailField()
    invited_at = models.DateTimeField(auto_now_add=True)
    accepted = models.BooleanField(default=False)
    accepted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        verbose_name = "Team Invitation"
        verbose_name_plural = "Team Invitations"

    def accept(self):
        self.accepted = True
        self.accepted_at = timezone.now()
        self.save()

    def __str__(self):
        return f"Invitation to {self.email} for {self.team.name}"
