# teams/urls.py
from django.urls import path
from .views import *


urlpatterns = [
    path('teams-list/',TeamListView.as_view(), name='team-list'),
    path('teams-create', TeamCreateView.as_view(), name='team_create'),
    path('teams/<int:pk>/details', TeamDetailView.as_view(), name='team-detail'),
    path('teams/<int:team_id>/users/', ListUsersInTeamView.as_view(), name='list-users-in-team'),
    path('teams/<int:team_id>/users/add/<int:user_id>/', AddUserToTeamView.as_view(), name='add-user-to-team'),
    path('teams/<int:team_id>/users/remove/<int:user_id>/', RemoveUserFromTeamView.as_view(),
         name='remove-user-from-team'),

]
