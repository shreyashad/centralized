# teams/serializers.py
from rest_framework import serializers
from .models import *
from accounts.models import CustomUser

# class TeamSerializer(serializers.ModelSerializer):
#     user_ids = serializers.PrimaryKeyRelatedField(
#         many=True,
#         queryset=CustomUser.objects.all(),
#         source='users'
#     )
#     usernames = serializers.StringRelatedField(
#         many=True,
#         source='users'
#     )
#
#     class Meta:
#         model = Team
#         fields = ['id', 'name', 'description', 'user_ids', 'usernames', 'created_at']
#         read_only_fields = ['usernames', 'created_at']
#
#     def create(self, validated_data):
#         users = validated_data.pop('users', [])
#         team = Team.objects.create(**validated_data)
#         team.users.set(users)
#         return team
#
#     def update(self, instance, validated_data):
#         users = validated_data.pop('users', [])
#         instance = super().update(instance, validated_data)
#         instance.users.set(users)
#         return instance

class TeamsCustomUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = ['id', 'username', 'first_name', 'last_name', 'org_type','org_name','emp_code','designation','mobile','department']

class TeamSerializer(serializers.ModelSerializer):
    users = serializers.SerializerMethodField()

    class Meta:
        model = Team
        fields = ['id', 'name', 'description', 'users', 'created_at']

    def get_users(self, obj):
        return [user.username for user in obj.users.all()]


class TeamMembershipSerializer(serializers.ModelSerializer):
    user = TeamsCustomUserSerializer()

    class Meta:
        model = TeamMembership
        fields = ['team', 'user', 'role']
