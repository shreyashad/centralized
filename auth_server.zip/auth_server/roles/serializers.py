# roles/serializers.py
from rest_framework import serializers
from roles.models import *

class ApplicationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Application
        fields = ['id', 'name', 'description', 'base_url', 'created_at', 'updated_at', 'client_id', 'client_secret', 'active']
        read_only_fields = ['created_at', 'updated_at']



# class TokenSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Token
#         fields = ['refresh_token', 'expires_at']





class PermissionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Permission
        fields = ['id', 'name', 'application', 'description', 'created_at', 'updated_at']
        read_only_fields = ['created_at', 'updated_at']


class RoleSerializer(serializers.ModelSerializer):
    permissions = PermissionSerializer(many=True, read_only=True)
    permission_ids = serializers.PrimaryKeyRelatedField(queryset=Permission.objects.all(), many=True, write_only=True)

    class Meta:
        model = Role
        fields = ['id', 'name', 'application', 'permissions', 'permission_ids', 'created_at', 'updated_at']
        read_only_fields = ['created_at', 'updated_at']

    def create(self, validated_data):
        permission_ids = validated_data.pop('permission_ids')
        role = Role.objects.create(**validated_data)
        role.permissions.set(permission_ids)
        return role

    def update(self, instance, validated_data):
        permission_ids = validated_data.pop('permission_ids')
        instance = super().update(instance, validated_data)
        instance.permissions.set(permission_ids)
        return instance



class UserRoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserRole
        fields = ['id', 'user', 'role', 'application', 'can_create', 'can_read', 'can_update', 'can_delete', 'created_at', 'updated_at']
        read_only_fields = ['created_at', 'updated_at']