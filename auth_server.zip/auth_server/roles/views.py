from django.shortcuts import render
from rest_framework import viewsets, status
from rest_framework.permissions import IsAuthenticated
from .models import *
from roles.serializers import *
from rest_framework.views import APIView
from rest_framework.response import Response
from django.db import IntegrityError
from rest_framework.decorators import api_view
from rest_framework_simplejwt.tokens import RefreshToken
from datetime import timedelta
from django.utils import timezone
# Create your views here.

# CURD operations for Application


class ApplicationListView(APIView):

    def get(self, request):
        apps = Application.objects.all()
        serializer = ApplicationSerializer(apps, many=True)
        return Response(serializer.data)


class ApplicationCreateView(APIView):
    serializer_class = ApplicationSerializer

    def post(self, request, format=None):
        data=request.data
        serializer = self.serializer_class(data=data)
        if serializer.is_valid():
            try:
                app_obj = serializer.save(created_by=request.user, updated_by=request.user)
                return Response(
                    {"error": False,"message": "New Application is created","apps": self.serializer_class(app_obj).data, },
                    status=status.HTTP_201_CREATED
                )
            except IntegrityError:
                return Response(
                    {"error": True, "message": "An application with this name already exists."},
                    status=status.HTTP_400_BAD_REQUEST,
                )
        else:
            return Response(
                {"error": True,"errors": serializer.errors,},
                status=status.HTTP_400_BAD_REQUEST,
            )



class ApplicationDetailView(APIView):
    serializer_class = ApplicationSerializer

    def get_object(self, pk):
        try:
            return Application.object.get(pk=pk)
        except Application.DoesNotExist:
            return None

    def get(self, request, pk):
        try :
            apps = self.get_object(pk)
            if not apps:
                return Response(
                    {"error": True, "errors": "Application does not exist "},
                    status=status.HTTP_404_NOT_FOUND,
                )

            user = request.user
            if user.role != "ADMINISTRATOR" and not user.is_superuser and apps.created_by != user:
                return Response(
                    {"error": True, "errors": "You do not have permission to perform this action"},
                    status=status.HTTP_403_FORBIDDEN,
                )
            serializer = self.serializer_class(apps)
            return Response(serializer.data)
        except ValueError:
            return Response(
                {"error": True, "errors": "Invalid UUID format"},
                status=status.HTTP_400_BAD_REQUEST,
            )

    def delete(self, request, pk, format=None):
        try:
            apps = self.get_object(pk)
            if not apps:
                return Response(
                    {"error": True, "errors": "Application does not exist"},
                    status=status.HTTP_404_NOT_FOUND,
                )
            apps.delete()
            return Response(
                {"error": False, "message": "Application deleted successfully"},
                status=status.HTTP_200_OK,
            )
        except ValueError:
            return Response(
                {"error": True, "errors": "Invalid UUID format"},
                status=status.HTTP_400_BAD_REQUEST,
            )
    def put(self, request, pk, format=None):
        try:
            apps = self.get_object(pk)
            if not apps:
                return Response(
                    {"error": True, "errors": "Application does not exist"},
                    status=status.HTTP_404_NOT_FOUND,
                )

                serializer = self.serializer_class(team, data=request.data)
                if serializer.is_valid():
                    serializer.save(updated_by=request.user)
                    return Response(
                        {"error": False, "message": "Application updated successfully"},
                        status=status.HTTP_200_OK,
                    )
                return Response(
                    {"error": True, "errors": serializer.errors},
                    status=status.HTTP_400_BAD_REQUEST,
                )

        except ValueError:
            return Response(
                {"error": True, "errors": "Invalid UUID format"},
                status=status.HTTP_400_BAD_REQUEST,
            )

# CURD operation for Role
class RolesListView(APIView):

    def get(self, request):
        role = Role.objects.all()
        serializer = RoleSerializer(role, many=True)
        return Response(serializer.data)


class RoleCreateView(APIView):
    serializer_class = ApplicationSerializer

    def post(self, request, format=None):
        data=request.data
        serializer = self.serializer_class(data=data)
        if serializer.is_valid():
            try:
                app_obj = serializer.save(created_by=request.user, updated_by=request.user)
                return Response(
                    {"error": False,"message": "New Application is created","apps": self.serializer_class(app_obj).data, },
                    status=status.HTTP_201_CREATED
                )
            except IntegrityError:
                return Response(
                    {"error": True, "message": "An application with this name already exists."},
                    status=status.HTTP_400_BAD_REQUEST,
                )
        else:
            return Response(
                {"error": True,"errors": serializer.errors,},
                status=status.HTTP_400_BAD_REQUEST,
            )



class RoleDetailView(APIView):
    serializer_class = RoleSerializer

    def get_object(self, pk):
        try:
            return Role.object.get(pk=pk)
        except Role.DoesNotExist:
            return None

    def get(self, request, pk):
        try :
            rol = self.get_object(pk)
            if not rol:
                return Response(
                    {"error": True, "errors": "Role does not exist "},
                    status=status.HTTP_404_NOT_FOUND,
                )

            user = request.user
            if user.role != "ADMINISTRATOR" and not user.is_superuser and rol.created_by != user:
                return Response(
                    {"error": True, "errors": "You do not have permission to perform this action"},
                    status=status.HTTP_403_FORBIDDEN,
                )
            serializer = self.serializer_class(rol)
            return Response(serializer.data)
        except ValueError:
            return Response(
                {"error": True, "errors": "Invalid UUID format"},
                status=status.HTTP_400_BAD_REQUEST,
            )

    def delete(self, request, pk, format=None):
        try:
            rol = self.get_object(pk)
            if not rol:
                return Response(
                    {"error": True, "errors": "Role does not exist"},
                    status=status.HTTP_404_NOT_FOUND,
                )
            rol.delete()
            return Response(
                {"error": False, "message": "Role deleted successfully"},
                status=status.HTTP_200_OK,
            )
        except ValueError:
            return Response(
                {"error": True, "errors": "Invalid UUID format"},
                status=status.HTTP_400_BAD_REQUEST,
            )
    def put(self, request, pk, format=None):
        try:
            rol = self.get_object(pk)
            data = request.data
            if not rol:
                return Response(
                    {"error": True, "errors": "Role does not exist"},
                    status=status.HTTP_404_NOT_FOUND,
                )

                serializer = self.serializer_class(rol, data=data)
                if serializer.is_valid():
                    serializer.save(updated_by=request.user)
                    return Response(
                        {"error": False, "message": "Role updated successfully"},
                        status=status.HTTP_200_OK,
                    )
                return Response(
                    {"error": True, "errors": serializer.errors},
                    status=status.HTTP_400_BAD_REQUEST,
                )

        except ValueError:
            return Response(
                {"error": True, "errors": "Invalid UUID format"},
                status=status.HTTP_400_BAD_REQUEST,
            )

# CURD operation for Permissions

class PermissionListView(APIView):

    def get(self, request):
        perms = Permission.objects.all()
        serializer = PermissionSerializer(perms, many=True)
        return Response(serializer.data)


class PermissionCreateView(APIView):
    serializer_class = PermissionSerializer

    def post(self, request, format=None):
        data=request.data
        serializer = self.serializer_class(data=data)
        if serializer.is_valid():
            try:
                app_obj = serializer.save(created_by=request.user, updated_by=request.user)
                return Response(
                    {"error": False,"message": "New Permission is created","apps": self.serializer_class(app_obj).data, },
                    status=status.HTTP_201_CREATED
                )
            except IntegrityError:
                return Response(
                    {"error": True, "message": "An Permission with this name already exists."},
                    status=status.HTTP_400_BAD_REQUEST,
                )
        else:
            return Response(
                {"error": True,"errors": serializer.errors,},
                status=status.HTTP_400_BAD_REQUEST,
            )



class PermissionDetailView(APIView):
    serializer_class = PermissionSerializer

    def get_object(self, pk):
        try:
            return Permission.object.get(pk=pk)
        except Permission.DoesNotExist:
            return None

    def get(self, request, pk):
        try :
            perms = self.get_object(pk)
            if not perms:
                return Response(
                    {"error": True, "errors": "Permission does not exist "},
                    status=status.HTTP_404_NOT_FOUND,
                )

            user = request.user
            if user.role != "ADMINISTRATOR" and not user.is_superuser and org.created_by != user:
                return Response(
                    {"error": True, "errors": "You do not have permission to perform this action"},
                    status=status.HTTP_403_FORBIDDEN,
                )
            serializer = self.serializer_class(perms)
            return Response(serializer.data)
        except ValueError:
            return Response(
                {"error": True, "errors": "Invalid UUID format"},
                status=status.HTTP_400_BAD_REQUEST,
            )

    def delete(self, request, pk, format=None):
        try:
            perms = self.get_object(pk)
            if not perms:
                return Response(
                    {"error": True, "errors": "Permission does not exist"},
                    status=status.HTTP_404_NOT_FOUND,
                )
            perms.delete()
            return Response(
                {"error": False, "message": "Permission deleted successfully"},
                status=status.HTTP_200_OK,
            )
        except ValueError:
            return Response(
                {"error": True, "errors": "Invalid UUID format"},
                status=status.HTTP_400_BAD_REQUEST,
            )
    def put(self, request, pk, format=None):
        try:
            perms = self.get_object(pk)
            if not perms:
                return Response(
                    {"error": True, "errors": "Permission does not exist"},
                    status=status.HTTP_404_NOT_FOUND,
                )

                serializer = self.serializer_class(perms, data=request.data)
                if serializer.is_valid():
                    serializer.save(updated_by=request.user)
                    return Response(
                        {"error": False, "message": "Permission updated successfully"},
                        status=status.HTTP_200_OK,
                    )
                return Response(
                    {"error": True, "errors": serializer.errors},
                    status=status.HTTP_400_BAD_REQUEST,
                )

        except ValueError:
            return Response(
                {"error": True, "errors": "Invalid UUID format"},
                status=status.HTTP_400_BAD_REQUEST,
            )








class ApplicationTokenAPIView(APIView):
    def post(self, request, *args,**kwargs):
        try:
            application = Application.objects.get(name=request.data.get('name'))
            token = application.token
            return Response({'token': token}, status=status.HTTP_200_OK)
        except Application.DoesNotExist:
            return Response({'error': 'Application not found'}, status=status.HTTP_404_NOT_FOUND)


# class ObtainTokenView(APIView):
#     def post(self, request):
#         client_id = request.data.get('client_id')
#         client_secret = request.data.get('client_secret')
#
#         try:
#             application = Application.objects.get(client_id=client_id, client_secret=client_secret)
#         except Application.DoesNotExist:
#             return Response({'detail': 'Invalid client credentials'}, status=status.HTTP_400_BAD_REQUEST)
#
#         user = request.user
#         refresh = RefreshToken.for_user(user)
#         expires_at = timezone.now() + + timedelta(days=7)
#
#         Token.objects.update_or_create(application=application, defaults={
#             'refresh_token': str(refresh),
#             'expires_at': expires_at
#         })
#
#         return Response({
#             'refresh': str(refresh),
#             'access': str(refresh.access_token),
#             'expires_at': expires_at
#         })
#
#
# class RefreshTokenView(APIView):
#     def post(self, request):
#         refresh_token = request.data.get('refresh_token')
#         try:
#             token = Token.objects.get(refresh_token=refresh_token)
#         except Token.DoesNotExist:
#             return Response({'detail': 'Invalid refresh token'}, status=status.HTTP_400_BAD_REQUEST)
#
#         if token.expires_at < timezone.now():
#             return Response({'detail': 'Refresh token expired'}, status=status.HTTP_400_BAD_REQUEST)
#
#         refresh = RefreshToken(token.refresh_token)
#         token.refresh_token = str(refresh)
#         token.expires_at = timezone.now() + timedelta(days=7)
#         token.save()
#
#         return Response({
#             'refresh': str(refresh),
#             'access': str(refresh.access_token),
#             'expires_at': token.expires_at
#         })



@api_view(['GET'])
def get_application_count(request, format=None):
    apps = Application.objects.filter(active=True).count()
    content = {'apps_count': apps}
    return Response(content)
