import uuid
from django.db import models
from accounts.models import BaseModel, CustomUser
# Create your models here.

class Application(BaseModel):
    name = models.CharField(max_length=255, unique=True)
    description = models.TextField()
    base_url = models.URLField(blank=True, null=True, help_text="Base URL for the application")
    token = models.CharField(max_length=255, unique=True, blank=True, null=True,
                             help_text="Token for application authentication")
    active = models.BooleanField(default=True, help_text="Is the application active?")


    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if not self.token:
            self.token = uuid.uuid4().hex
        super().save(*args, **kwargs)


# class Token(models.Model):
#     application = models.OneToOneField(Application, on_delete=models.CASCADE)
#     refresh_token = models.CharField(max_length=255, unique=True, help_text="Token refresh for application authentication")
#
#     expires_at = models.DateTimeField()
#
#     def __str__(self):
#         return f"Token for {self.application.name}"



class Permission(BaseModel):
    name = models.CharField(max_length=255)
    application = models.ForeignKey(Application, on_delete=models.CASCADE)
    description = models.TextField(blank=True)

    def __str__(self):
        return f"{self.name} - {self.application.name}"


class Role(BaseModel):
    name = models.CharField(max_length=255)
    permissions = models.ManyToManyField(Permission)
    application = models.ForeignKey(Application, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.name} - {self.application.name}"




class UserRole(BaseModel):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    role = models.ForeignKey(Role, on_delete=models.CASCADE)
    application = models.ForeignKey(Application, on_delete=models.CASCADE)
    can_create = models.BooleanField(default=False)
    can_read = models.BooleanField(default=True)
    can_update = models.BooleanField(default=False)
    can_delete = models.BooleanField(default=False)

    class Meta:
        unique_together = ('user', 'role', 'application')

    def get_absolute_url(self):
        if self.application.base_url:
            return f"{self.application.base_url}/user/{self.user.username}"
        else:
            return "/profile/"

    def __str__(self):
        return f"{self.user.username} - {self.role.name} - {self.application.name}"