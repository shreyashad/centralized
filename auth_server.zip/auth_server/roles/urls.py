# roles/urls.py
from django.urls import path
from .views import *


urlpatterns = [
    path('application-list/', ApplicationListView.as_view(), name='app_list'),
    path('application-create/', ApplicationCreateView.as_view(), name='app_create'),
    path('application/<uuid:pk>/details', ApplicationDetailView.as_view(), name='app_details'),
    path('application-count/', get_application_count, name='apps_count'),
    path('roles-list/', RolesListView.as_view(), name='role_list'),
    path('role-create/', RoleCreateView.as_view(), name='role_create'),
    path('role/<uuid:pk>/details',RoleDetailView.as_view(), name='role_detail'),

    path('permissions-list/', PermissionListView.as_view(), name='permission_list'),
    path('permission-create/', PermissionCreateView.as_view(), name='permission_create'),
    path('permission/<uuid:pk>/details', PermissionDetailView.as_view(), name='permission_details'),

]