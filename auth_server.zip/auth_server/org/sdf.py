from django.shortcuts import render
from org.serializers import *
from org.models import *
from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from accounts.permissions import IsAdminOrReadOnly
from rest_framework.views import APIView
from rest_framework.response import Response
# Create your views here.




# views.py
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.exceptions import NotFound
from .models import Org
from .serializers import OrgSerializer
import uuid

class OrgListCreateAPIView(APIView):
    def get(self, request):
        orgs = Org.objects.all()
        serializer = OrgSerializer(orgs, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = OrgSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class OrgDetailAPIView(APIView):
    def get_object(self, pk):
        try:
            return Org.objects.get(pk=uuid.UUID(pk))
        except Org.DoesNotExist:
            raise NotFound()

    def get(self, request, pk):
        org = self.get_object(pk)
        serializer = OrgSerializer(org)
        return Response(serializer.data)

    def put(self, request, pk):
        org = self.get_object(pk)
        serializer = OrgSerializer(org, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        org = self.get_object(pk)
        org.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)





class OrganizationViewSet(viewsets.ModelViewSet):
    queryset = Organization.objects.all()
    serializer_class = OrganizationSerializer
    #permission_classes = [IsAuthenticated, IsAdminOrReadOnly]


class OrganizationListView(APIView):
    def get(self, request, format=None):
        org = Organization.objects.all()
        org_data = OrganizationSerializer(org, many=True).data
        return Response(org_data)



class OrganizationSubTypeViewSet(viewsets.ModelViewSet):
    queryset = OrganizationSubType.objects.all()
    serializer_class = OrganizationSubTypeSerializer
    #permission_classes = [IsAuthenticated, IsAdminOrReadOnly]

class LocationsViewSet(viewsets.ModelViewSet):
    queryset = Locations.objects.all()
    serializer_class = LocationsSerializer
    #permission_classes = [IsAuthenticated, IsAdminOrReadOnly]

class DepartmentViewSet(viewsets.ModelViewSet):
    queryset = Department.objects.all()
    serializer_class = DepartmentSerializer
    #permission_classes = [IsAuthenticated, IsAdminOrReadOnly]

class DesignationViewSet(viewsets.ModelViewSet):
    queryset = Designation.objects.all()
    serializer_class = DesignationSerializer
    #permission_classes = [IsAuthenticated, IsAdminOrReadOnly]


from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import Organization
from .serializers import OrganizationSerializer
from django.db import IntegrityError

class OrganizationCreateView(APIView):
    model = Organization
    serializer_class = OrganizationSerializer

    def post(self, request, format=None):
        data = request.data
        serializer = self.serializer_class(data=data)
        if serializer.is_valid():
            try:
                org_obj = serializer.save(created_by=request.user, updated_by=request.user)
                return Response(
                    {
                        "error": False,
                        "message": "New organization is created",
                        "org": self.serializer_class(org_obj).data,
                        "status": status.HTTP_201_CREATED,
                    }
                )
            except IntegrityError:
                return Response(
                    {
                        "error": True,
                        "message": "An organization with this name already exists.",
                        "status": status.HTTP_400_BAD_REQUEST,
                    }
                )
        else:
            return Response(
                {
                    "error": True,
                    "errors": serializer.errors,
                    "status": status.HTTP_400_BAD_REQUEST,
                }
            )
class OrganizationDetailView(APIView):
    def get_object(self, pk):
        try:
            return Organization.objects.get(pk=pk)
        except Organization.DoesNotExist:
            return None

    def get(self, request, pk):
        org = self.get_object(pk)
        if not org:
            return Response(
                {
                    "error": True,
                    "errors": "Organization does not exist",
                    "status": status.HTTP_403_FORBIDDEN
                }
            )
        if self.request.user.role != "ADMINISTRATOR" and not self.request.user.is_superuser:
            if not self.request.user == org.created_by:
                return Response(
                    {
                        "error": True,
                        "errors": "You do not have permission to perform this action",
                    },
                    status=status.HTTP_403_FORBIDDEN,
                )
        serializer = OrganizationSerializer(org)
        return Response(serializer.data)

    def delete(self, request, pk, format=None):
        org = self.get_object(pk)
        if not org:
            return Response(
                {
                    "error": True,
                    "errors": "Organization does not exist"
                },
                status=status.HTTP_403_FORBIDDEN,
            )
        org.delete()
        return Response(
            {
                "error": False,
                "message": "Organization deleted successfully"
            },
            status=status.HTTP_200_OK,
        )

    def put(self, request, pk, format=None):
        org = self.get_object(pk)
        params = request.data
        if not org:
            return Response(
                {
                    "error": True,
                    "errors": "Organization does not exist"
                },
                status=status.HTTP_404_NOT_FOUND,
            )
        serializer = OrganizationSerializer(org, data=params)
        if serializer.is_valid():
            try:
                serializer.save(updated_by=request.user)
                return Response(
                    {
                        "error": False,
                        "message": "Organization updated successfully"
                    },
                    status=status.HTTP_200_OK
                )
            except IntegrityError:
                return Response(
                    {
                        "error": True,
                        "message": "An organization with this name already exists.",
                        "status": status.HTTP_400_BAD_REQUEST,
                    }
                )
        return Response(
            {"error": True, "errors": serializer.errors},
            status=status.HTTP_400_BAD_REQUEST,
        )



from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import Organization
from .serializers import OrganizationSerializer
from django.db import IntegrityError

class OrganizationListView(APIView):
    def get(self, request):
        orgs = Organization.objects.all()
        serializer = OrganizationSerializer(orgs, many=True)
        return Response(serializer.data)

class OrganizationCreateView(APIView):
    model = Organization
    serializer_class = OrganizationSerializer

    def post(self, request, format=None):
        data = request.data
        serializer = self.serializer_class(data=data)
        if serializer.is_valid():
            try:
                org_obj = serializer.save(created_by=request.user, updated_by=request.user)
                return Response(
                    {
                        "error": False,
                        "message": "New organization is created",
                        "org": self.serializer_class(org_obj).data,
                        "status": status.HTTP_201_CREATED,
                    }
                )
            except IntegrityError:
                return Response(
                    {
                        "error": True,
                        "message": "An organization with this name already exists.",
                        "status": status.HTTP_400_BAD_REQUEST,
                    }
                )
        else:
            return Response(
                {
                    "error": True,
                    "errors": serializer.errors,
                    "status": status.HTTP_400_BAD_REQUEST,
                }
            )

class OrganizationDetailView(APIView):
    def get_object(self, pk):
        try:
            return Organization.objects.get(pk=pk)
        except Organization.DoesNotExist:
            return None

    def get(self, request, pk):
        org = self.get_object(pk)
        if not org:
            return Response(
                {
                    "error": True,
                    "errors": "Organization does not exist",
                    "status": status.HTTP_403_FORBIDDEN
                }
            )
        if self.request.user.role != "ADMINISTRATOR" and not self.request.user.is_superuser:
            if not self.request.user == org.created_by:
                return Response(
                    {
                        "error": True,
                        "errors": "You do not have permission to perform this action",
                    },
                    status=status.HTTP_403_FORBIDDEN,
                )
        serializer = OrganizationSerializer(org)
        return Response(serializer.data)

    def delete(self, request, pk, format=None):
        org = self.get_object(pk)
        if not org:
            return Response(
                {
                    "error": True,
                    "errors": "Organization does not exist"
                },
                status=status.HTTP_403_FORBIDDEN,
            )
        org.delete()
        return Response(
            {
                "error": False,
                "message": "Organization deleted successfully"
            },
            status=status.HTTP_200_OK,
        )

    def put(self, request, pk, format=None):
        org = self.get_object(pk)
        params = request.data
        if not org:
            return Response(
                {
                    "error": True,
                    "errors": "Organization does not exist"
                },
                status=status.HTTP_404_NOT_FOUND,
            )
        serializer = OrganizationSerializer(org, data=params)
        if serializer.is_valid():
            try:
                serializer.save(updated_by=request.user)
                return Response(
                    {
                        "error": False,
                        "message": "Organization updated successfully"
                    },
                    status=status.HTTP_200_OK
                )
            except IntegrityError:
                return Response(
                    {
                        "error": True,
                        "message": "An organization with this name already exists.",
                        "status": status.HTTP_400_BAD_REQUEST,
                    }
                )
        return Response(
            {"error": True, "errors": serializer.errors},
            status=status.HTTP_400_BAD_REQUEST,
        )
------------------------------------
from rest_framework import serializers
from django.contrib.auth import get_user_model
from django.contrib.auth.password_validation import validate_password

User = get_user_model()

class UserRegistrationSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, required=True, validators=[validate_password])
    confirm_password = serializers.CharField(write_only=True, required=True)

    class Meta:
        model = User
        fields = ('id', 'first_name', 'last_name', 'org_type', 'org_name', 'org_sub_type',
                  'location_type', 'location_name', 'location_code', 'emp_code', 'department',
                  'designation', 'mobile', 'username', 'password', 'confirm_password', 'assigned_pol_no',
                  'is_online', 'is_verified', 'is_authenticator', 'is_site_admin', 'last_password_change',
                  'password_change_required', 'is_sso_user', 'sso_provider')

    def validate(self, attrs):
        if attrs['password'] != attrs['confirm_password']:
            raise serializers.ValidationError({"password": "Password fields didn't match."})
        return attrs

    def create(self, validated_data):
        validated_data.pop('confirm_password')
        password = validated_data.pop('password')
        user = User(**validated_data)
        user.set_password(password)
        user.save()
        return user
-------------------------
from rest_framework import serializers
from .models import Organization, OrganizationSubType, Locations, Department, Designation
from phonenumber_field.formfields import PhoneNumberField

class UserRegistrationSerializer(serializers.Serializer):
    first_name = serializers.CharField(max_length=150)
    last_name = serializers.CharField(max_length=150)
    org_type = serializers.ChoiceField(choices=OrgType.choices)
    org_name = serializers.ChoiceField(choices=[])
    org_sub_type = serializers.ChoiceField(choices=[])
    location_type = serializers.ChoiceField(choices=[])
    location_name = serializers.ChoiceField(choices=[])
    location_code = serializers.ChoiceField(choices=[])
    department = serializers.PrimaryKeyRelatedField(queryset=Department.objects.all())
    designation = serializers.PrimaryKeyRelatedField(queryset=Designation.objects.all())
    mobile = PhoneNumberField()
    username = serializers.CharField(max_length=150)
    password = serializers.CharField(max_length=128)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['org_name'].choices = self.get_org_name_choices([])
        self.fields['org_sub_type'].choices = self.get_org_sub_type_choices([])
        self.fields['location_type'].choices = self.get_location_type_choices([])
        self.fields['location_name'].choices = self.get_location_name_choices([])
        self.fields['location_code'].choices = self.get_location_code_choices([])

    def get_org_name_choices(self, org_type):
        queryset = Organization.objects.filter(org_type=org_type).values_list('id', 'name')
        return [(item[0], item[1]) for item in queryset]

    def get_org_sub_type_choices(self, org_type):
        queryset = OrganizationSubType.objects.filter(org_type=org_type).values_list('id', 'subtype')
        return [(item[0], item[1]) for item in queryset]

    def get_location_type_choices(self, org_name):
        queryset = Locations.objects.filter(org_name=org_name).values_list('id', 'location_type')
        return [(item[0], item[1]) for item in queryset]

    def get_location_name_choices(self, location_type):
        queryset = Locations.objects.filter(location_type=location_type).values_list('id', 'location_name')
        return [(item[0], item[1]) for item in queryset]

    def get_location_code_choices(self, location_type):
        queryset = Locations.objects.filter(location_type=location_type).values_list('id', 'location_code')
        return [(item[0], item[1]) for item in queryset]

    def validate(self, data):
        # Perform additional validation if needed
        return data

    def create(self, validated_data):
        # Create user logic
        pass  # Implement your user creation logic here

from rest_framework import generics, status
from rest_framework.response import Response
from .serializers import UserRegistrationSerializer

class UserRegistrationAPIView(generics.CreateAPIView):
    serializer_class = UserRegistrationSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            # Optionally, return any data related to the registration process
            return Response({'message': 'User registered successfully', 'user_id': user.id}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
---------------------------------------------
from rest_framework import serializers
from django.contrib.auth.password_validation import validate_password
from phonenumber_field.serializerfields import PhoneNumberField
from django.core.exceptions import ValidationError
from .models import CustomUser, Organization, OrganizationSubType, Locations, Department, Designation, OrgType, LocationType

class UserRegistrationSerializer(serializers.ModelSerializer):
    first_name = serializers.CharField(max_length=150)
    last_name = serializers.CharField(max_length=150)
    org_type = serializers.ChoiceField(choices=OrgType.choices)
    org_name = serializers.ChoiceField(choices=[])
    org_sub_type = serializers.ChoiceField(choices=[])
    location_type = serializers.ChoiceField(choices=[])
    location_name = serializers.ChoiceField(choices=[])
    location_code = serializers.ChoiceField(choices=[])
    department = serializers.PrimaryKeyRelatedField(queryset=Department.objects.all())
    designation = serializers.PrimaryKeyRelatedField(queryset=Designation.objects.all())
    mobile = PhoneNumberField()
    username = serializers.CharField(max_length=150)
    emp_code = serializers.CharField(max_length=150)
    password = serializers.CharField(write_only=True, required=True, validators=[validate_password])
    confirm_password = serializers.CharField(write_only=True, required=True)

    class Meta:
        model = CustomUser
        fields = [
            'first_name', 'last_name', 'org_type', 'org_name', 'org_sub_type',
            'location_type', 'location_name', 'location_code', 'department',
            'designation', 'mobile', 'username', 'emp_code', 'password', 'confirm_password'
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['org_name'].choices = self.get_org_name_choices([])
        self.fields['org_sub_type'].choices = self.get_org_sub_type_choices([])
        self.fields['location_type'].choices = self.get_location_type_choices([])
        self.fields['location_name'].choices = self.get_location_name_choices([])
        self.fields['location_code'].choices = self.get_location_code_choices([])

    def get_org_name_choices(self, org_type):
        queryset = Organization.objects.filter(org_type=org_type).values_list('id', 'name')
        return [(item[0], item[1]) for item in queryset]

    def get_org_sub_type_choices(self, org_type):
        queryset = OrganizationSubType.objects.filter(org_type=org_type).values_list('id', 'subtype')
        return [(item[0], item[1]) for item in queryset]

    def get_location_type_choices(self, org_name):
        queryset = Locations.objects.filter(org_name=org_name).values_list('location_type', flat=True).distinct()
        return [(item, item) for item in queryset]

    def get_location_name_choices(self, org_name, location_type):
        queryset = Locations.objects.filter(org_name=org_name, location_type=location_type).values_list('id', 'location_name')
        return [(item[0], item[1]) for item in queryset]

    def get_location_code_choices(self, org_name, location_type):
        queryset = Locations.objects.filter(org_name=org_name, location_type=location_type).values_list('id', 'location_code')
        return [(item[0], item[1]) for item in queryset]

    def validate(self, attrs):
        if attrs['password'] != attrs['confirm_password']:
            raise serializers.ValidationError({"password": "Password fields didn't match."})
        if CustomUser.objects.filter(username=attrs['username']).exists():
            raise serializers.ValidationError({"username": "This username is already taken."})
        if CustomUser.objects.filter(mobile=attrs['mobile']).exists():
            raise serializers.ValidationError({"mobile": "This mobile number is already registered."})
        if CustomUser.objects.filter(emp_code=attrs['emp_code']).exists():
            raise serializers.ValidationError({"emp_code": "This employee code is already registered."})
        return attrs

    def create(self, validated_data):
        validated_data.pop('confirm_password')
        password = validated_data.pop('password')
        user = CustomUser(**validated_data)
        user.set_password(password)
        user.save()
        return user
--------------------------
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import Organization, OrganizationSubType, Locations, CustomUser
from .serializers import UserRegistrationSerializer

@api_view(['GET'])
def get_org_names(request):
    org_type = request.GET.get('orgType')
    if org_type:
        org_names = Organization.objects.filter(org_type=org_type).values('id', 'name')
        return Response(list(org_names), status=status.HTTP_200_OK)
    return Response({"error": "orgType parameter is required"}, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET'])
def get_org_sub_types(request):
    org_type = request.GET.get('orgType')
    if org_type:
        org_sub_types = OrganizationSubType.objects.filter(org_type=org_type).values('id', 'subtype')
        return Response(list(org_sub_types), status=status.HTTP_200_OK)
    return Response({"error": "orgType parameter is required"}, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET'])
def get_location_types(request):
    org_name = request.GET.get('orgName')
    if org_name:
        location_types = Locations.objects.filter(org_name=org_name).values_list('location_type', flat=True).distinct()
        return Response(list(location_types), status=status.HTTP_200_OK)
    return Response({"error": "orgName parameter is required"}, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET'])
def get_location_names_and_codes(request):
    org_name = request.GET.get('orgName')
    location_type = request.GET.get('locationType')
    if org_name and location_type:
        locations = Locations.objects.filter(org_name=org_name, location_type=location_type)
        location_names = locations.values('id', 'location_name')
        location_codes = locations.values('id', 'location_code')
        return Response({'names': list(location_names), 'codes': list(location_codes)}, status=status.HTTP_200_OK)
    return Response({"error": "orgName and locationType parameters are required"}, status=status.HTTP_400_BAD_REQUEST)

@api_view(['POST'])
def register_user(request):
    serializer = UserRegistrationSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response({"message": "User registered successfully"}, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
----------------------------------------
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from .models import Organization, OrganizationSubType, Locations
from .serializers import OrganizationSerializer, OrganizationSubTypeSerializer, LocationsSerializer

class OrgNameList(APIView):
    permission_classes = [AllowAny]

    def get(self, request, *args, **kwargs):
        org_type = request.query_params.get('orgType')
        if org_type:
            organizations = Organization.objects.filter(org_type=org_type)
        else:
            organizations = Organization.objects.all()
        serializer = OrganizationSerializer(organizations, many=True)
        return Response(serializer.data)

class OrgSubTypeList(APIView):
    permission_classes = [AllowAny]

    def get(self, request, *args, **kwargs):
        org_type = request.query_params.get('orgType')
        if org_type:
            org_sub_types = OrganizationSubType.objects.filter(org_type=org_type)
        else:
            org_sub_types = OrganizationSubType.objects.all()
        serializer = OrganizationSubTypeSerializer(org_sub_types, many=True)
        return Response(serializer.data)

class LocationTypeList(APIView):
    permission_classes = [AllowAny]

    def get(self, request, *args, **kwargs):
        org_name = request.query_params.get('orgName')
        if org_name:
            locations = Locations.objects.filter(org_name=org_name)
        else:
            locations = Locations.objects.all()
        serializer = LocationsSerializer(locations, many=True)
        return Response(serializer.data)

class LocationNamesAndCodesList(APIView):
    permission_classes = [AllowAny]

    def get(self, request, *args, **kwargs):
        org_name = request.query_params.get('orgName')
        location_type = request.query_params.get('locationType')
        if org_name and location_type:
            locations = Locations.objects.filter(org_name=org_name, location_type=location_type)
        elif org_name:
            locations = Locations.objects.filter(org_name=org_name)
        elif location_type:
            locations = Locations.objects.filter(location_type=location_type)
        else:
            locations = Locations.objects.all()
        serializer = LocationsSerializer(locations, many=True)
        return Response(serializer.data)
