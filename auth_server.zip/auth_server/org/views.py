import uuid

from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.exceptions import NotFound
from org.models import *
from org.serializers import *
from django.db import IntegrityError
from rest_framework.filters import OrderingFilter, SearchFilter
from rest_framework.pagination import PageNumberPagination



class OrganizationListView(APIView):
    pagination_class = PageNumberPagination
    filter_backends = [OrderingFilter, SearchFilter]
    ordering_fields = ['id', 'org_type', 'name']
    search_fields = ['name', 'org_type', 'created_at']

    def get(self, request):
        paginator = self.pagination_class()
        orgs = Organization.objects.all()
        filtered_orgs = self.filter_queryset(orgs)
        page = paginator.paginate_queryset(filtered_orgs, request)
        serializer = OrganizationSerializer(page, many=True)
        return paginator.get_paginated_response(serializer.data)


class OrganizationCreateView(APIView):
    serializer_class = OrganizationSerializer

    def post(self, request, format=None):
        data = request.data
        serializer = self.serializer_class(data=data)
        if serializer.is_valid():
            try:
                org_obj = serializer.save(created_by=request.user, updated_by=request.user)
                return Response(
                    {
                        "error": False,
                        "message": "New organization is created",
                        "org": self.serializer_class(org_obj).data,

                    },
                    status=status.HTTP_201_CREATED,
                )
            except IntegrityError:
                return Response(
                    {
                        "error": True,
                        "message": "An organization with this name already exists.",

                    },
                    status=status.HTTP_400_BAD_REQUEST,
                )
        else:
            return Response(
                    {
                        "error": True,
                        "errors": serializer.errors,
                    },
                    status=status.HTTP_400_BAD_REQUEST,
            )

class OrganizationDetailView(APIView):
    serializer_class = OrganizationSerializer

    def get_object(self, pk):
        try:
            return Organization.objects.get(pk=pk)
        except Organization.DoesNotExist:
            return None

    def get(self, request, pk):
        try:
            org = self.get_object(pk)
            if not org:
                return Response(
                    {"error": True, "errors": "Organization does not exist"},
                    status=status.HTTP_404_NOT_FOUND,
                )

            # Your permission checks here
            user = request.user
            if user.role != "ADMINISTRATOR" and not user.is_superuser and org.created_by != user:
                return Response(
                    {"error": True, "errors": "You do not have permission to perform this action"},
                    status=status.HTTP_403_FORBIDDEN,
                )

            serializer = self.serializer_class(org)
            return Response(serializer.data)

        except ValueError:
            return Response(
                {"error": True, "errors": "Invalid UUID format"},
                status=status.HTTP_400_BAD_REQUEST,
            )

    def delete(self, request, pk, format=None):
        try:
            org = self.get_object(pk)
            if not org:
                return Response(
                    {"error": True, "errors": "Organization does not exist"},
                    status=status.HTTP_404_NOT_FOUND,
                )

            org.delete()
            return Response(
                {"error": False, "message": "Organization deleted successfully"},
                status=status.HTTP_200_OK,
            )

        except ValueError:
            return Response(
                {"error": True, "errors": "Invalid UUID format"},
                status=status.HTTP_400_BAD_REQUEST,
            )

    def put(self, request, pk, format=None):
        try:
            org = self.get_object(pk)
            if not org:
                return Response(
                    {"error": True, "errors": "Organization does not exist"},
                    status=status.HTTP_404_NOT_FOUND,
                )

            serializer = self.serializer_class(org, data=request.data)
            if serializer.is_valid():
                serializer.save(updated_by=request.user)
                return Response(
                    {"error": False, "message": "Organization updated successfully"},
                    status=status.HTTP_200_OK,
                )
            return Response(
                {"error": True, "errors": serializer.errors},
                status=status.HTTP_400_BAD_REQUEST,
            )

        except ValueError:
            return Response(
                {"error": True, "errors": "Invalid UUID format"},
                status=status.HTTP_400_BAD_REQUEST,
            )


class OrganizationSubtypeListView(APIView):
    def get(self, request):
        org_subtype = OrganizationSubType.objects.all()
        serializer = OrganizationSubTypeSerializer(org_subtype, many=True)
        return Response(serializer.data)

class OrganizationSubtpeCreateView(APIView):
    serializer_class = OrganizationSubTypeSerializer

    def post(self, request, format=None):
        data = request.data
        serializer = self.serializer_class(data=data)
        if serializer.is_valid():
            try:
                org_subtype_obj = serializer.save(created_by=request.user, update_by=request.user)
                return Response(
                    {
                        "error": False,
                        "message": "New Org-subtype is created",
                        "org_subtype": self.serializer_class(org_subtype_obj).data,
                    },
                    status=status.HTTP_201_CREATED
                )
            except IntegrityError:
                return Response(
                    {
                        "error": True,
                        "message": "An organization subtype with this name already exists.",
                    },
                    status=status.HTTP_400_BAD_REQUEST
                )
        else:
            return Response(
                {
                    "error": True,
                    "errors": serializer.errors,
                },
                status=status.HTTP_400_BAD_REQUEST
            )

class OrganizationSubtypeDetailView(APIView):
    serializer_class = OrganizationSubTypeSerializer

    def get_object(self, pk):
        try:
            return OrganizationSubType.objects.get(pk=pk)
        except OrganizationSubType.DoesNotExist:
            return None

    def get(self, request, pk):
        try:
            org_subtype = self.get_object(pk)
            if not org_subtype:
                return Response(
                    {"error": True, "errors": "Organization Subtype Dose not exist"},
                    status=status.HTTP_403_FORBIDDEN
                )
            user = request.user
            if user.role != "ADMINISTRATOR" and not user.is_superuser and org_subtype.created_by != user:
               return Response(
                        {"error": True, "errors": "You do not have permission  to perform this action"},
                        status=status.HTTP_403_FORBIDDEN,
                    )
            serializer = self.serializer_class(org_subtype)
            return Response(serializer.data)
        except ValueError:
            return Response(
                {"error": True, "errors": "Invalid UUID format"},
                status=status.HTTP_400_BAD_REQUEST
            )


    def delete(self, request, pk, format=None):
        try:
            org_subtype = self.get_object(pk)
            if not org_subtype:
                return Response(
                    {
                        "error": True, "errors": "Organization subtype does not exist"
                    },
                    status=status.HTTP_404_NOT_FOUND,
                )
            org_subtype.delete()
            return Response(
                {
                    "error": False,"message": "Organization subtype deleted Successfully "
                },
                status=status.HTTP_200_OK,
            )
        except ValueError:
            return Response(
                {"error": True, "errors": "Invalid UUID format"},
                status=status.HTTP_400_BAD_REQUEST,
            )



    def put(self, request, pk, format=None):
        try:
            org_subtype = self.get_object(pk)
            params = request.data
            if not org_subtype:
                return Response(
                    {"error": True,"errors": "Organization subtype does not exist"},
                    status=status.HTTP_404_NOT_FOUND,
                )
            serializer = self.serializer_class(org_subtype, data=params)
            if serializer.is_valid():
                serializer.save(updated_by=request.user)
                return Response(
                    {"error": False, "message": "Organization updated successfully"},
                    status=status.HTTP_200_OK,
                )

            return Response(
                {"error": True, "errors": serializer.errors},
                status=status.HTTP_400_BAD_REQUEST,
            )
        except ValueError:
            return Response(
                {"error": True, "errors": "Invalid UUID format"},
                status=status.HTTP_400_BAD_REQUEST,
            )


class LocationsListView(APIView):
    def get(self, request):
        loc = Locations.objects.all()
        serializer = LocationsSerializer(loc, many=True)
        return Response(serializer.data)


class LocationsCreateView(APIView):
    serializer_class = LocationsSerializer

    def post(self, request, format=None):
        data = request.data
        serializer = self.serializer_class(data=data)
        if serializer.is_valid():
            try:
                loc_obj = serializer.save(created_by=request.user, update_by=request.user)
                return Response(
                    {
                        "error": False,
                        "message": "New Locations is created",
                        "loc": self.serializer_class(loc_obj).data,
                    },
                    status=status.HTTP_201_CREATED
                )
            except IntegrityError:
                return Response(
                    {
                        "error": True,
                        "message": "An location with this name already exists.",
                    },
                    status=status.HTTP_400_BAD_REQUEST
                )
        else:
            return Response(
                {
                    "error": True,
                    "errors": serializer.errors,
                },
                status=status.HTTP_400_BAD_REQUEST
            )


class LocationsDetailView(APIView):
    serializer_class = LocationsSerializer

    def get_object(self, pk):
        try:
            return Locations.objects.get(pk=pk)
        except Locations.DoesNotExist:
            return None

    def get(self, request, pk):
        try:
            loc = self.get_object(pk)
            if not loc:
                return Response(
                    {"error": True, "errors": "Location Dose not exist"},
                    status=status.HTTP_403_FORBIDDEN
                )
            user = request.user
            if user.role != "ADMINISTRATOR" and not user.is_superuser and loc.created_by != user:
                return Response(
                    {"error": True, "errors": "You do not have permission  to perform this action"},
                    status=status.HTTP_403_FORBIDDEN,
                )
            serializer = self.serializer_class(loc)
            return Response(serializer.data)
        except ValueError:
            return Response(
                {"error": True, "errors": "Invalid UUID format"},
                status=status.HTTP_400_BAD_REQUEST
            )

    def delete(self, request, pk, format=None):
        try:
            loc = self.get_object(pk)
            if not loc:
                return Response(
                    {
                        "error": True, "errors": "Location does not exist"
                    },
                    status=status.HTTP_404_NOT_FOUND,
                )
            loc.delete()
            return Response(
                {
                    "error": False, "message": "Location deleted Successfully "
                },
                status=status.HTTP_200_OK,
            )
        except ValueError:
            return Response(
                {"error": True, "errors": "Invalid UUID format"},
                status=status.HTTP_400_BAD_REQUEST,
            )

    def put(self, request, pk, format=None):
        try:
            loc = self.get_object(pk)
            params = request.data
            if not loc:
                return Response(
                    {"error": True, "errors": "Location does not exist"},
                    status=status.HTTP_404_NOT_FOUND,
                )
            serializer = self.serializer_class(loc, data=params)
            if serializer.is_valid():
                serializer.save(updated_by=request.user)
                return Response(
                    {"error": False, "message": "Location updated successfully"},
                    status=status.HTTP_200_OK,
                )

            return Response(
                {"error": True, "errors": serializer.errors},
                status=status.HTTP_400_BAD_REQUEST,
            )
        except ValueError:
            return Response(
                {"error": True, "errors": "Invalid UUID format"},
                status=status.HTTP_400_BAD_REQUEST,
            )


class DesignationListView(APIView):
    def get(self, request):
        designation = Designation.objects.all()
        serializer = DesignationSerializer(designation, many=True)
        return Response(serializer.data)


class DesignationCreateView(APIView):
    serializer_class = DesignationSerializer

    def post(self, request, format=None):
        data = request.data
        serializer = self.serializer_class(data=data)
        if serializer.is_valid():
            try:
                loc_obj = serializer.save(created_by=request.user, update_by=request.user)
                return Response(
                    {
                        "error": False,
                        "message": "New Designation is created",
                        "loc": self.serializer_class(loc_obj).data,
                    },
                    status=status.HTTP_201_CREATED
                )
            except IntegrityError:
                return Response(
                    {
                        "error": True,
                        "message": "An designation with this name already exists.",
                    },
                    status=status.HTTP_400_BAD_REQUEST,
                )
        else:
            return Response(
                {
                    "error": True,
                    "errors": serializer.errors,
                },
                status=status.HTTP_400_BAD_REQUEST,
            )


class DesignationDetailView(APIView):
    serializer_class = DesignationSerializer

    def get_object(self, pk):
        try:
            return Designation.objects.get(pk=pk)
        except Designation.DoesNotExist:
            return None

    def get(self, request, pk):
        try:
            designation = self.get_object(pk)
            if not designation:
                return Response(
                    {"error": True, "errors": "Designation Dose not exist"},
                    status=status.HTTP_403_FORBIDDEN
                )
            user = request.user
            if user.role != "ADMINISTRATOR" and not user.is_superuser and designation.created_by != user:
                return Response(
                    {"error": True, "errors": "You do not have permission  to perform this action"},
                    status=status.HTTP_403_FORBIDDEN,
                )
            serializer = self.serializer_class(designation)
            return Response(serializer.data)
        except ValueError:
            return Response(
                {"error": True, "errors": "Invalid UUID format"},
                status=status.HTTP_400_BAD_REQUEST
            )

    def delete(self, request, pk, format=None):
        try:
            designation = self.get_object(pk)
            if not designation:
                return Response(
                    {
                        "error": True, "errors": "Designation does not exist"
                    },
                    status=status.HTTP_404_NOT_FOUND,
                )
            designation.delete()
            return Response(
                {
                    "error": False, "message": "Designation deleted Successfully "
                },
                status=status.HTTP_200_OK,
            )
        except ValueError:
            return Response(
                {"error": True, "errors": "Invalid UUID format"},
                status=status.HTTP_400_BAD_REQUEST,
            )

    def put(self, request, pk, format=None):
        try:
            designation = self.get_object(pk)
            params = request.data
            if not designation:
                return Response(
                    {"error": True, "errors": "designation does not exist"},
                    status=status.HTTP_404_NOT_FOUND,
                )
            serializer = self.serializer_class(designation, data=params)
            if serializer.is_valid():
                serializer.save(updated_by=request.user)
                return Response(
                    {"error": False, "message": "designation updated successfully"},
                    status=status.HTTP_200_OK,
                )

            return Response(
                {"error": True, "errors": serializer.errors},
                status=status.HTTP_400_BAD_REQUEST,
            )
        except ValueError:
            return Response(
                {"error": True, "errors": "Invalid UUID format"},
                status=status.HTTP_400_BAD_REQUEST,
            )

