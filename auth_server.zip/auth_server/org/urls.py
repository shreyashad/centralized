from django.urls import path
from org.views import *

urlpatterns = [
    path('organization-list/', OrganizationListView.as_view(), name='org_list'),
    path('organization-create/', OrganizationCreateView.as_view(), name='org_create'),
    path('organization/<uuid:pk>/detail/', OrganizationDetailView.as_view(), name='org_detail'),
    path('org-subtype-list/', OrganizationSubtypeListView.as_view(), name='org_subtype_list'),
    path('org-subtype-create/', OrganizationCreateView.as_view(), name='org_subtype_create'),
    path('org-subtype/<uuid:pk>/detail/', OrganizationSubtypeDetailView.as_view(), name='org_subtype_detail'),
    path('locations-list/', LocationsListView.as_view(), name='location_list'),
    path('location-create/', LocationsCreateView.as_view(), name='location_create'),
    path('location/<uuid:pk>/detail/', LocationsDetailView.as_view(), name='location_detail'),
    path('designations-list/', DesignationListView.as_view(), name='designation_list'),
    path('designation-create/', DesignationCreateView.as_view(), name='designation_create'),
    path('designation/<uuid:pk>/detail/', DesignationDetailView.as_view(), name='designation_detail'),

]