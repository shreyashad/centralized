"use client";

import { useSession } from "next-auth/react";
import StatsCard from "@/components/dashboard/stats-card";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";

const EmployeeDashboard = () => {
    const { data: session, status } = useSession();
    console.log('Session data:', session);
    // Check if session is loading or not authenticated
    if (status === "loading") {
        return <p>Loading...</p>;
    }

    if (!session) {
        return <p>You are not authenticated</p>;
    }

    const { user } = session;

    return (
        <div className="flex h-full flex-col">
            <div className="p-4 grid gap-4 lg:grid-cols-3 xl:grid-cols-3">
                <div className="lg:col-span-2">
                    <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-2 xl:grid-cols-4">
                        <Card className="sm:col-span-2" x-chunk="dashboard-05-chunk-0">
                            <CardHeader className="pb-3">
                                <CardTitle>
                                    
                                    <h2>Welcome back, {user.first_name} 👋🏻</h2>  
                                    <h5>Todays Wisdom</h5>
                                </CardTitle>
                                <CardDescription className="max-w-lg text-balance leading-relaxed">

                                </CardDescription>
                            </CardHeader>
                        </Card>
                    </div>
                    <div className="mt-6">

                    </div>
                </div>
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 sm:grid-cols-1">
                    <StatsCard title="Hours Spent" />
                    <StatsCard title="Test Results" />
                    <StatsCard title="Course Completed" />
                    
                </div>
            </div>
            <div className="flex-1 w-32 space-y-4 p-8 pt-6">

            </div>
        </div>
        
    );
};

export default EmployeeDashboard;
