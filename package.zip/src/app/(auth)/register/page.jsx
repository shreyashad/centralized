"use client";
import axios from "axios";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import zxcvbn from "zxcvbn";

const API_BASE_URL = process.env.API_BASE_URL || '';






const RegistrationForm = () => {
    const [formData, setFormData] = useState({
        first_name:'',
        last_name:'',
        username:'',
        password:'',
        confirm_password:'',
        branch:'',
        department:'',
        designation:'',
        emp_id:'',
        mobile:'',
    });

    const [passwordStrength, setPasswordStrength] = useState(0);
    const [errors, setErrors] = useState({});
    const [success, setSuccess] = useState(false);
    const [branchOptions, setBranchOptions] = useState([]);
    const [designationOptions, setDesignationOptions] = useState([]);
    const [departmentOptions, setDepartmentOptions] = useState([]);
    const router = useRouter();

    useEffect (()=> {
       const fetchDropdownOptions = async () => {
        try{
            const response = await axios.get(` ${API_BASE_URL}/api/accounts/dropdown-options/`);
            const data = response.data;
            setBranchOptions(data.branchOptions);
            setDepartmentOptions(data.departmentOptions);
            setDesignationOptions(data.designationOptions);
        } catch (error) {
            console.error('Error in fetching dropdown options:',error);
        }
       };
       fetchDropdownOptions();
    },[]);

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });

        if (e.target.name === 'password') {
            const strength = zxcvbn(e.target.value);
            setPasswordStrength(strength.score);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setErrors({});
        setSuccess(false);

        try {
            await axios.post(` ${API_BASE_URL}/api/accounts/register/`, formData);
            setSuccess(true);
            router.push('/login')
        } catch (err) {
            if (err.response && err.response.data) {
                setErrors(err.response.data);
            }
        }
    };

    return(
        <div className="container shadow shadow-2xl mx-auto px-4">
            <h1 className="text-2xl font-bold text-center mt-10">User Registration</h1>
                {success && <div className="text-green-500 text-center">Registration successful!</div>}
            <form onSubmit={handleSubmit} className="max-w-md mx-auto mt-10">
                <div className="grid grid-cols-1 gap-x-8 gap-y-6 sm:grid-cols-2">
                    <div className="mb-4">
                        <label className="block text-gray-700">First Name</label>
                        <input
                            type="text"
                            name="first_name"
                            value={formData.first_name}
                            onChange={handleChange}
                            className={`w-full px-3 py-2 border ${errors.first_name ? 'border-red-500' : 'border-gray-300'} rounded-md`}
                        />
                        {errors.first_name && <p className="text-red-500 text-sm">{errors.first_name}</p>}
                    </div>
                    <div className="mb-4">
                        <label className="block text-gray-700">Last Name</label>
                        <input
                            type="text"
                            name="last_name"
                            value={formData.last_name}
                            onChange={handleChange}
                            className={`w-full px-3 py-2 border ${errors.last_name ? 'border-red-500' : 'border-gray-300'} rounded-md`}
                        />
                        {errors.last_name && <p className="text-red-500 text-sm">{errors.last_name}</p>}
                    </div>
                </div>
                <div className="grid grid-cols-1 gap-x-8 gap-y-6 sm:grid-cols-2">
                    <div className="mb-4">
                        <label className="block text-gray-700">Employee ID</label>
                        <input
                            type="text"
                            name="emp_id"
                            value={formData.emp_id}
                            onChange={handleChange}
                            className={`w-full px-3 py-2 border ${errors.emp_id ? 'border-red-500' : 'border-gray-300'} rounded-md`}
                        />
                        {errors.emp_id && <p className="text-red-500 text-sm">{errors.emp_id}</p>}
                    </div>
                    <div className="mb-4">
                        <label className="block text-gray-700">Mobile</label>
                        <input
                            type="text"
                            name="mobile"
                            value={formData.mobile}
                            onChange={handleChange}
                            className={`w-full px-3 py-2 border ${errors.mobile ? 'border-red-500' : 'border-gray-300'} rounded-md`}
                        />
                        {errors.mobile && <p className="text-red-500 text-sm">{errors.mobile}</p>}
                    </div>
                </div>
                <div className="mb-4">
                    <label className="block text-gray-700">Branch</label>
                    <select
                        name="branch"
                        value={formData.branch}
                        onChange={handleChange}
                        className={`w-full px-3 py-2 border ${errors.branch ? 'border-red-500' : 'border-gray-300'} rounded-md`}
                    >
                        <option value="">Select a branch</option>
                        {branchOptions.map(branch => (
                        <option key={branch.id} value={branch.name}>{branch.name}</option>
                        ))}
                    </select>
                    {errors.branch && <p className="text-red-500 text-sm">{errors.branch}</p>}
                </div>
                <div className="mb-4">
                    <label className="block text-gray-700">Department</label>
                    <select
                        name="department"
                        value={formData.department}
                        onChange={handleChange}
                        className={`w-full px-3 py-2 border ${errors.department ? 'border-red-500' : 'border-gray-300'} rounded-md`}
                    >
                        <option value="">Select a department</option>
                        {departmentOptions.map(department => (
                        <option key={department.id} value={department.name}>{department.name}</option>
                        ))}
                    </select>
                    {errors.department && <p className="text-red-500 text-sm">{errors.department}</p>}
                </div>

                <div className="mb-4">
                <label className="block text-gray-700">Designation</label>
                <select
                    name="designation"
                    value={formData.designation}
                    onChange={handleChange}
                    className={`w-full px-3 py-2 border ${errors.designation ? 'border-red-500' : 'border-gray-300'} rounded-md`}
                >
                    <option value="">Select a designation</option>
                    {designationOptions.map(designation => (
                    <option key={designation.id} value={designation.name}>{designation.name}</option>
                    ))}
                </select>
                {errors.designation && <p className="text-red-500 text-sm">{errors.designation}</p>}
                </div>

        
        <div className="mb-4">
          <label className="block text-gray-700">Username</label>
          <input
            type="text"
            name="username"
            value={formData.username}
            onChange={handleChange}
            className={`w-full px-3 py-2 border ${errors.username ? 'border-red-500' : 'border-gray-300'} rounded-md`}
          />
          {errors.username && <p className="text-red-500 text-sm">{errors.username}</p>}
        </div>

        <div className="mb-4">
          <label className="block text-gray-700">Password</label>
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            className={`w-full px-3 py-2 border ${errors.password ? 'border-red-500' : 'border-gray-300'} rounded-md`}
          />
          <div className="mt-2">
            <div className={`w-full bg-gray-300 h-2 rounded ${passwordStrength === 0 ? 'bg-red-500' : passwordStrength === 1 ? 'bg-orange-500' : passwordStrength === 2 ? 'bg-yellow-500' : passwordStrength === 3 ? 'bg-blue-500' : 'bg-green-500'}`} style={{ width: `${(passwordStrength + 1) * 20}%` }}></div>
          </div>
          {errors.password && <p className="text-red-500 text-sm">{errors.password}</p>}
        </div>

        <div className="mb-4">
          <label className="block text-gray-700">Confirm Password</label>
          <input
            type="password"
            name="password_confirm"
            value={formData.password_confirm}
            onChange={handleChange}
            className={`w-full px-3 py-2 border ${errors.password_confirm ? 'border-red-500' : 'border-gray-300'} rounded-md`}
          />
          {errors.password_confirm && <p className="text-red-500 text-sm">{errors.password_confirm}</p>}
        </div>


        <button type="submit" className="w-full bg-blue-500 text-white px-4 py-2 rounded-md">Register</button>
      </form>
    </div>
    );
};

export default RegistrationForm;