"use client";
import { useState } from "react";
import { signIn, useSession } from "next-auth/react";
import { useRouter } from "next/navigation";

export default function SignIn() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const router = useRouter();
  const { data: session, status } = useSession();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const result = await signIn("credentials", {
      redirect: false,
      username,
      password,
    });

    if (!result.error) {
      // Redirect based on the user's role
      if (session) {
        switch (session.user.roles[0].name) {
          case 'ADMIN':
            router.push('/admin/dashboard');
            break;
          case 'TRAINERS ADMIN':
            router.push('/trainers-admin/dashboard');
            break;
          case 'HOD':
            router.push('/hod/dashboard');
            break;
          case 'TRAINER':
            router.push('/trainer/dashboard');
            break;
          case 'USER':
            router.push('/employee/dashboard');
            break;
          default:
            router.push('/');
        }
      }
    } else {
      setError(result.error);
    }
  };

  return (
    <div className="container">
      <h2>Sign In</h2>
      {error && <p style={{ color: "red" }}>{error}</p>}
      <form onSubmit={handleSubmit}>
        <div>
          <label>Username</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>
        <div>
          <label>Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <button type="submit">Sign In</button>
      </form>
    </div>
  );
}
"use client";
import { useState, useEffect } from "react";
import { signIn, useSession, SessionProvider } from "next-auth/react";
import { useRouter } from "next/navigation";
import axios from "axios";

export default function SignIn() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const router = useRouter();
  const { data: session, status } = useSession();

  useEffect(() => {
    if (status === "authenticated" && session?.user?.roles) {
      const roles = session.user.roles;
      if (Array.isArray(roles) && roles.length > 0) {
        switch (roles[0].name) {
          case 'ADMIN':
            router.push('/admin/dashboard');
            break;
          case 'TRAINERS ADMIN':
            router.push('/trainers-admin/dashboard');
            break;
          case 'HOD':
            router.push('/hod/dashboard');
            break;
          case 'TRAINER':
            router.push('/trainer/dashboard');
            break;
          case 'USER':
            router.push('/employee/dashboard');
            break;
          default:
            router.push('/');
        }
      } else {
        console.error("Roles array is empty or not valid", roles);
      }
    } else if (status === "authenticated") {
      console.error("Roles not defined on session.user", session.user);
    }
  }, [session, status, router]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const result = await signIn("credentials", {
      redirect: false,
      username,
      password,
    });

    if (result && !result.error) {
      // Fetch user data if needed or handle session logic here
      const res = await axios.post("/api/accounts/token/", { username, password });
      const data = res.data;

      // Handle the response as needed
      console.log(data);
    } else {
      setError(result.error);
    }
  };

  return (
    <div className="container">
      <h2>Sign In</h2>
      {error && <p style={{ color: "red" }}>{error}</p>}
      <form onSubmit={handleSubmit}>
        <div>
          <label>Username</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>
        <div>
          <label>Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <button type="submit">Sign In</button>
      </form>
    </div>
  );
}

// Wrapping the component with SessionProvider in the app's root
function MyApp({ Component, pageProps }) {
  return (
    <SessionProvider session={pageProps.session}>
      <Component {...pageProps} />
    </SessionProvider>
  );
}

export default MyApp;
"use client";
import axios from "axios";
import { signIn, useSession, getSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useState } from "react";

const API_BASE_URL = process.env.API_BASE_URL || '';

export default function SignIn() {
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState(null);
    const router = useRouter();

    const handleSubmit = async (e) => {
        e.preventDefault();
        const result = await signIn("credentials", {
            redirect: false,
            username,
            password,
        });

        if (!result.error) {
            // Fetch the latest session data
            const session = await getSession();
            if (session && session.user.roles) {
                switch (session.user.roles[0].name) {
                    case 'ADMIN':
                        router.push('/admin/dashboard');
                        break;
                    case 'TRAINERS ADMIN':
                        router.push('/trainers-admin/dashboard');
                        break;
                    case 'HOD':
                        router.push('/hod/dashboard');
                        break;
                    case 'TRAINER':
                        router.push('/trainer/dashboard');
                        break;
                    case 'USER':
                        router.push('/employee/dashboard');
                        break;
                    default:
                        router.push('/');
                }
            } else {
                setError("No roles found for the user.");
            }
        } else {
            setError(result.error);
        }
    };

    return (
        <div className="container">
            <h2>Sign In</h2>
            {error && <p style={{ color: "red" }}>{error}</p>}
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Username</label>
                    <input
                        type="text"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                    />
                </div>
                <div>
                    <label>Password</label>
                    <input
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                    />
                </div>
                <button type="submit">Sign In</button>
            </form>
        </div>
    );
}
