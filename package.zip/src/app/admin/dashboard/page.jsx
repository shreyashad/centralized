import StatsCard from "@/components/dashboard/stats-card";



const AdminDashboard = () => {
    return(
        <div className="grid gap-4 md:grid-cols-2 md:gap-8 lg:grid-cols-4">
            <StatsCard title="Online Users" value=""/>
            <StatsCard />
            <StatsCard />
            <StatsCard />
        </div>
    );
}
export default AdminDashboard;