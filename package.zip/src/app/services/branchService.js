import axios from "axios";

const API_BASE_URL = process.env.API_BASE_URL || '';

export const fetchBranches = async () => {
    const response = await axios.get(`${API_BASE_URL}/api/common/branches`);
    return response.data;
};


export const createBranch = async (branch) => {
    const response = await axios.post(`${API_BASE_URL}/api/common/branches`, branch);
    return response.data;
};

export const updateBranch = async (id, branch) => {
    const response = await axios.put(`${API_BASE_URL}/api/common/branches/${id}`, branch);
    return response.data;
  };
  
  export const deleteBranch = async (id) => {
    const response = await axios.delete(`${API_BASE_URL}/api/common/branches/${id}`);
    return response.data;
  };
  