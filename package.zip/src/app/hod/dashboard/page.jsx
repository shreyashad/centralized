

const HodDashboard = () => {
    return(
        <h1> Hods dashboard</h1>
    );
};
export default HodDashboard;