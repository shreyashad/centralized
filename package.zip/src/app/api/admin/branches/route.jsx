import { fetchBranches } from "@/app/services/branchService";
import { NextResponse } from "next/server";


export async function GET() {
    try {
        const branches = await fetchBranches();
        return NextResponse.json(branches, { status: 200});
    } catch (error) {
        return NextResponse.json({ error: error.message }, {status: 500});
    }
}