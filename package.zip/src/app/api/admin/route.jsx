import { NextResponse } from 'next/server';
import { fetchBranches, createBranch, updateBranch, deleteBranch } from '../../../services/branchService';

export async function GET() {
  try {
    const branches = await fetchBranches();
    return NextResponse.json(branches, { status: 200 });
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(req) {
  try {
    const data = await req.json();
    const branch = await createBranch(data);
    return NextResponse.json(branch, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 400 });
  }
}
import axios from 'axios';

const API_URL = process.env.API_BASE_URL || 'http://localhost:8000/api/branches';

export const fetchBranches = async () => {
  const response = await axios.get(API_URL);
  return response.data;
};

export const createBranch = async (branch) => {
  const response = await axios.post(API_URL, branch);
  return response.data;
};

export const updateBranch = async (id, branch) => {
  const response = await axios.put(`${API_URL}/${id}/`, branch);
  return response.data;
};

export const deleteBranch = async (id) => {
  const response = await axios.delete(`${API_URL}/${id}/`);
  return response.data;
};
