import axios from "axios";
import NextAuth from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";

const authOptions = {
    providers: [
        CredentialsProvider({
            name: "Credentails",
            credentials: {
                username: { label: "Username", type: "text" },
                password: { label: "Password", type: "password" }
            },
            
            async authorize(credentials) {
                try{
                    const res = await axios.post(`${process.env.API_BASE_URL}api/accounts/token/`, {
                        username: credentials.username,
                        password: credentials.password
                    });

                    const user = res.data.user;
                    const accessToken = res.data.access;

                    if (user) {
                        return { ...user, accessToken };
                    }
                    return null;
                } catch (error) {
                    throw new Error("Invalid credentials or network error");
                }
            }
        })
    ],
    callbacks: {
        async jwt ({ token, user }) {
            if (user) {
                // token.accessToken = user.accessToken;
                // token.roles = user.roles;
                token.user = user
            }
            return token;
        },

        async session({ session, token }) {
            // session.user.accessToken = token.accessToken;
            // session.user.roles = token.roles;
            session.user = token.user;
            return session;
        }
    },
    pages: {
        signIn: "/login",
    },
};



const handler = NextAuth(authOptions);

export { handler as GET, handler as POST };