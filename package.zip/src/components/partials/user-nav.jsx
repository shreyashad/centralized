import { LogOut } from "lucide-react";
import { Button } from "../ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "../ui/dropdown-menu";
import { UserAvatar } from "./user-avatar";
import { signOut } from "next-auth/react";




export function UserNav({user}) {
    return(
        <DropdownMenu>
            <DropdownMenuTrigger>
                <UserAvatar 
                    user={{
                        first_name: user?.first_name || null,
                        last_name:user?.last_name || null, 
                        image: user?.image || null
                    }}
                    className="h-8 w-8 cursor-pointer"
                />
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
                <div className="flex items-center justify-start gap-4 p-2">
                    <div className="flex flex-col space-y-1 leading-none">
                        {user?.first_name && user?.last_name && <p className="font-medium">{user.first_name} {user.last_name}</p>}
                        {user?.username && (
                            <p className="w-[200px] truncate text-sm text-zinc-700">
                                {user.username}
                            </p>
                        )}
                    </div>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                    <Button
                        variant="outline"
                        className="w-full"
                        onClick={() => {
                            void signOut({ callbackUrl: '/login' });
                        }}
                    >
                        <LogOut className="mr-2 h-4 w-4" aria-hidden="true" />
                        Log Out
                    </Button>
                </DropdownMenuItem>
            </DropdownMenuContent>
        </DropdownMenu>
    )
}