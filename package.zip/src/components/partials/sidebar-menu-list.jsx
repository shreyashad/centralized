import { BookCheckIcon, BookOpenCheck, BookOpenText, BookUser, Briefcase, BriefcaseBusiness, Building2, LayoutDashboard, NotebookPen, Settings, Trophy, UserRoundCog, UsersRound } from "lucide-react";


export const DashboardMenuConfig = {
    Admin: [
        {
            title: "Dashboard",
            icon: LayoutDashboard,
            href: "/admin/dashboard",
            color: "text-sky-500",
        },
        {
            title: "User-Management",
            icon: UserRoundCog,
            href: "/admin/users",
            color: "text-sky-500",
            
        },
        {
            title: "Organization-Management",
            icon: Building2,
            href: "/admin/organization",
            color: "text-sky-500",
            isChidren: true,
            children: [
                {
                    title: "Branches",
                    icon: BriefcaseBusiness,
                    color: "text-red-500",
                    href: "/admin/organization/branches",
                  },
                  {
                    title: "Departments",
                    icon: Briefcase,
                    color: "text-red-500",
                    href: "/admin/organization/departments",
                  },
                  {
                    title: "Designations",
                    icon: BookUser,
                    color: "text-red-500",
                    href: "/admin/organization/designations",
                  },
            ]
        },
        {
            title: "Teams",
            icon: UsersRound,
            href: "/admin/teams",
            color: "text-sky-500",
        },
        {
            title: "Profile",
            icon: Settings,
            href: "/admin/profile",
            color: "text-sky-500",
        },
    ],
    HOD : [
        {
            title: "Dashboard",
            icon: LayoutDashboard,
            href: "/hod/dashboard",
            color: "text-sky-500",
        },
        {
            title: "Traning Request",
            icon: LayoutDashboard,
            href: "/hod/users",
            color: "text-sky-500",
            
        },
        {
            title: "Organization-Management",
            icon: LayoutDashboard,
            href: "/admin/organization",
            color: "text-sky-500",
            isChidren: true,
            children: [
                {
                    title: "Branches",
                    icon: BookOpenCheck,
                    color: "text-red-500",
                    href: "/admin/organization/branches",
                  },
                  {
                    title: "Departments",
                    icon: BookOpenCheck,
                    color: "text-red-500",
                    href: "/admin/organization/departments",
                  },
                  {
                    title: "Designations",
                    icon: BookOpenCheck,
                    color: "text-red-500",
                    href: "/admin/organization/designations",
                  },
            ]
        },
        {
            title: "Teams",
            icon: UsersRound,
            href: "/admin/teams",
            color: "text-sky-500",
        },
        {
            title: "Profile",
            icon: Settings,
            href: "/admin/profile",
            color: "text-sky-500",
        },
    ],
    Employee : [
        {
            title: "Dashboard",
            icon: LayoutDashboard,
            href: "/employee/dashboard",
            color: "text-sky-500",
        },
        {
            title: "My-Course",
            icon: BookOpenText,
            href: "/employee/my-courses",
            color: "text-sky-500",
            
        },
        {
            title: "My-Exams",
            icon: NotebookPen,
            href: "/employee/exams",
            color: "text-sky-500",
        },
        {
            title: "My-Performance",
            icon: Trophy,
            href: "/employee/teams",
            color: "text-sky-500",
        },
        {
            title: "Teams",
            icon: UsersRound,
            href: "/employee/teams",
            color: "text-sky-500",
        },
        {
            title: "Profile",
            icon: Settings,
            href: "/employee/profile",
            color: "text-sky-500",
        },
    ],
    TrainersAdmin : [
        {
            title: "Dashboard",
            icon: LayoutDashboard,
            href: "/admin/dashboard",
            color: "text-sky-500",
        },
        {
            title: "User-Management",
            icon: LayoutDashboard,
            href: "/admin/users",
            color: "text-sky-500",
            
        },
        {
            title: "Organization-Management",
            icon: LayoutDashboard,
            href: "/admin/organization",
            color: "text-sky-500",
            isChidren: true,
            children: [
                {
                    title: "Branches",
                    icon: BookOpenCheck,
                    color: "text-red-500",
                    href: "/admin/organization/branches",
                  },
                  {
                    title: "Departments",
                    icon: BookOpenCheck,
                    color: "text-red-500",
                    href: "/admin/organization/departments",
                  },
                  {
                    title: "Designations",
                    icon: BookOpenCheck,
                    color: "text-red-500",
                    href: "/admin/organization/designations",
                  },
            ]
        },
        {
            title: "Teams",
            icon: UsersRound,
            href: "/admin/teams",
            color: "text-sky-500",
        },
        {
            title: "Profile",
            icon: Settings,
            href: "/admin/profile",
            color: "text-sky-500",
        },
    ],


};