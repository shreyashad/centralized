"use client";
import { useEffect, useState } from "react";
import { Sheet, SheetContent, SheetTrigger } from "../ui/sheet";
import { MenuIcon } from "lucide-react";
import Image from "next/image";
import SideNav from "./side-nav";
import { DashboardMenuConfig } from "./sidebar-menu-list";

const MobileSidebar = ({ dashboardType }) => {
    const [open, setOpen] = useState(false);
    const [isMounted, setIsMounted] = useState(false);

    useEffect(()=> {
        setIsMounted(true);
    }, []);

    if (!isMounted) {
        return null;
    }

    const menuItems = DashboardMenuConfig[dashboardType] || [];
    return(
        <>
            <Sheet open={open} onOpenChange={setOpen}>
                <SheetTrigger asChild>
                    <div className="flex items-center justify-center gap-2">
                        <MenuIcon />
                        <Image src="/mdi_logo1.png" height={30} width={30} />
                    </div>
                </SheetTrigger>
                <SheetContent side="left" className="w-72">
                    <div className="px-1 py-6 pt-16">
                        <SideNav items={menuItems} setOpen={setOpen} />
                    </div>
                </SheetContent>
            </Sheet>

        </>
    );
};

export default MobileSidebar;