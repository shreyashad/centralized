// components/Notification.js
import { useState } from 'react';
import { useShadow } from 'shadow-core';

export default function Notification() {
  const { ShadowRoot, html } = useShadow();
  const [message, setMessage] = useState('');
  const [isVisible, setIsVisible] = useState(false);

  const handleButtonClick = () => {
    setMessage('This is a notification!');
    setIsVisible(true);
    setTimeout(() => setIsVisible(false), 3000); // Hide notification after 3 seconds
  };

  return (
    <div>
      <button onClick={handleButtonClick}>Show Notification</button>
      {isVisible && (
        <ShadowRoot>
          <div className="notification">
            {html`<style>.notification { background-color: yellow; padding: 10px; }</style>`}
            {message}
          </div>
        </ShadowRoot>
      )}
    </div>
  );
}
