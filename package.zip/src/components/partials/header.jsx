"use client";
import { useSession } from "next-auth/react";
import ThemeToggle from "./theme-toggle";
import { UserNav } from "./user-nav";
import { cn } from "@/lib/utils";
import Image from "next/image";
import MobileSidebar from "./mobile-sidebar";

const Header = ( { dashboardType }) => {
    const { data: session, status } = useSession();
    if (session) {
        console.log("User details:", session.user);
        // Access user details from session.user
    }
    return(
        <div className="supports-backdrop-blur:bg-background/60 fixed left-0 right-0 top-0 z-20 border-b bg-background/95 backdrop-blur">
            <nav className="flex h-16 items-center justify-between px-4">
                <div className="hidden items-center justify-between gap-2 md:flex">
                    <Image src="/mdi_logo1.png" height={50} width={50} />
                </div>
                <div className={cn("block md:!hidden")}>
                    <MobileSidebar dashboardType={dashboardType} />
                </div>
                <div className="flex items-center gap-2">
                    <ThemeToggle />
                   
                    {session && session.user ? <UserNav user={session.user} /> : <p>Loading user...</p>}
                </div>

            </nav>
        </div>
    );
};

export default Header;