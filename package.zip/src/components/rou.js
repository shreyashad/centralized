"use client";

import { useSidebar } from "@/hooks/useSidebar";
import { cn } from "@/lib/utils";
import { useState } from "react";
import { BsArrowLeftShort } from "react-icons/bs";
import SideNav from "./side-nav";
import { DashboardMenuConfig } from "@/components/constants/side-nav";

export default function Sidebar({ dashboardType, className }) {
    const { isOpen, toggle } = useSidebar();
    const [status, setStatus] = useState(false);

    const handleToggle = () => {
        setStatus(true);
        toggle();
        setTimeout(() => setStatus(false), 500);
    };

    // Get the menu items based on the dashboardType
    const menuItems = DashboardMenuConfig[dashboardType] || [];

    return (
        <nav
            className={cn(
                `relative hidden h-screen border-r pt-20 md:block`,
                status && "duration-500",
                isOpen ? "w-72" : "w-[78px]",
                className
            )}
        >
            <BsArrowLeftShort
                className={cn(
                    "absolute -right-3 top-20 cursor-pointer rounded-full border bg-background text-3xl text-foreground",
                    !isOpen && "rotate-180"
                )}
                onClick={handleToggle}
            />
            <div className="space-y-4 py-4">
                <div className="px-3 py-2">
                    <div className="mt-3 space-y-1">
                        <SideNav
                            className="text-background opacity-0 transition-all duration-300 group-hover:z-50 group-hover:ml-4 group-hover:rounded group-hover:bg-foreground group-hover:p-2 group-hover:opacity-100"
                            items={menuItems}
                        />
                    </div>
                </div>
            </div>
        </nav>
    );
}
import { useState, useEffect } from "react";
import { MenuIcon } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import SideNav from "@/components/layout/side-nav";
import { DashboardMenuConfig } from "@/components/constants/side-nav";

const MobileSidebar = ({ dashboardType }) => {
    const [open, setOpen] = useState(false);
    const [isMounted, setIsMounted] = useState(false);

    useEffect(() => {
        setIsMounted(true);
    }, []);

    if (!isMounted) {
        return null;
    }

    // Get the menu items based on the dashboardType
    const menuItems = DashboardMenuConfig[dashboardType] || [];

    return (
        <>
            <Sheet open={open} onOpenChange={setOpen}>
                <SheetTrigger asChild>
                    <div className="flex items-center justify-center gap-2">
                        <MenuIcon />
                        <h1 className="text-lg font-semibold">T3 app template</h1>
                    </div>
                </SheetTrigger>
                <SheetContent side="left" className="w-72">
                    <div className="px-1 py-6 pt-16">
                        <SideNav items={menuItems} setOpen={setOpen} />
                    </div>
                </SheetContent>
            </Sheet>
        </>
    );
};

export default MobileSidebar;
import axios from "axios";
import NextAuth from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";

const authOptions = {
    providers: [
        CredentialsProvider({
            name: "Credentials",
            credentials: {
                username: { label: "Username", type: "text" },
                password: { label: "Password", type: "password" }
            },
            async authorize(credentials) {
                try {
                    const res = await axios.post(`${process.env.API_BASE_URL}api/accounts/token/`, {
                        username: credentials.username,
                        password: credentials.password
                    });

                    const user = res.data.user;
                    const accessToken = res.data.access;

                    if (user) {
                        return { ...user, accessToken };
                    }
                    return null;
                } catch (error) {
                    throw new Error("Invalid credentials or network error");
                }
            }
        })
    ],
    callbacks: {
        async jwt({ token, user }) {
            if (user) {
                token.user = user; // Store the full user object in the token
            }
            return token;
        },
        async session({ session, token }) {
            session.user = token.user; // Pass the full user object to the session
            return session;
        }
    },
    pages: {
        signIn: "/login",
    },
};

const handler = NextAuth(authOptions);

export { handler as GET, handler as POST };
import { LogOut } from "lucide-react";
import { Button } from "../ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "../ui/dropdown-menu";
import { UserAvatar } from "./user-avatar";
import { signOut } from "next-auth/react";

export function UserNav({ user }) {
    return (
        <DropdownMenu>
            <DropdownMenuTrigger>
                <UserAvatar
                    user={{
                        first_name: user?.first_name || null,
                        last_name: user?.last_name || null,
                        image: user?.image || null
                    }}
                    className="h-8 w-8 cursor-pointer"
                />
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
                <div className="flex items-center justify-start gap-4 p-2">
                    <div className="flex flex-col space-y-1 leading-none">
                        {user?.first_name && user?.last_name && <p className="font-medium">{user.first_name} {user.last_name}</p>}
                        {user?.username && (
                            <p className="w-[200px] truncate text-sm text-zinc-700">
                                {user.username}
                            </p>
                        )}
                    </div>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                    <Button
                        variant="outline"
                        className="w-full"
                        onClick={() => {
                            void signOut({ callbackUrl: '/login' });
                        }}
                    >
                        <LogOut className="mr-2 h-4 w-4" aria-hidden="true" />
                        Log Out
                    </Button>
                </DropdownMenuItem>
            </DropdownMenuContent>
        </DropdownMenu>
    );
}
