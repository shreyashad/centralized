


const TimeSpendingChart = ({ totalHours }) => {
    const data = {
        labels: ['Total Hours'],
        datasets: [
            {
                data: [totalHours, 1000 - totalHours], // Example: Total 1000 hours
                backgroundColor: ['#4caf50', '#e0e0e0'],
                hoverBackgroundColor: ['#388e3c', '#bdbdbd'],
            }
        ]
    }

    const options = {
        cutout: '80%',
        plugins: {
            tooltip: {
                callbacks: {
                    label: (tooltipItem) => {
                        return `${tooltipItem.label}: ${tooltipItem.raw} hours`;
                    },
                },
            },
        },
    };
    return (
        <div className="relative w-40 h-40">
            < data={data} options={options} />
            <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-xl font-semibold">{totalHours}h</span>
            </div>
        </div>
    );
};

export default TimeSpendingChart;