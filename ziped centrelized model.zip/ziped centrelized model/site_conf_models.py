from django.db import models
import uuid
# Create your models here.



class Domain(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=255, unique=True)
    registration_date = models.DateField(auto_now_add=True)
    expiry_date = models.DateField()
    organization = models.ForeignKey('accounts.Organization', on_delete=models.SET_NULL, null=True, blank=True)
    status = models.CharField(max_length=20, choices=[('Active', 'Active'), ('Inactive', 'Inactive')], default='Active')

    def __str__(self):
        return self.name
