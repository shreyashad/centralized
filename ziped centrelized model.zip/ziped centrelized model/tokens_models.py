from django.db import models
from django.utils import timezone
from uuid import uuid4
# Create your models here.
# tokens/models.py



class TokenBlacklist(models.Model):
    """
    Model to store revoked or invalidated tokens.
    """
    token = models.UUIDField(primary_key=True, default=uuid4, editable=False)
    reason = models.CharField(max_length=100)
    revoked_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return str(self.token)


class TokenLog(models.Model):
    """
    Model to log token-related events.
    """
    EVENT_CHOICES = [
        ('ISSUANCE', 'Token Issuance'),
        ('VALIDATION', 'Token Validation'),
        ('REVOCATION', 'Token Revocation'),
    ]
    token = models.UUIDField()
    event_type = models.CharField(max_length=20, choices=EVENT_CHOICES)
    user = models.ForeignKey('accounts.CustomUser', on_delete=models.SET_NULL, null=True, blank=True)
    timestamp = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"{self.event_type} - {self.token}"
