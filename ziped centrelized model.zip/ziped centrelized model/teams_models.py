from django.db import models
from accounts.base import BaseModel
from accounts.models import UserProfile
from django.utils.translation import gettext_lazy as _
# Create your models here.

class Teams(BaseModel):
    name = models.CharField(max_length=150)
    description = models.TextField()
    users = models.ManyToManyField(UserProfile, related_name="users_teams")
    created_on = models.DateTimeField(_("created on"), auto_now_add=True)

    class Meta:
        verbose_name = "Team"
        verbose_name_plural = "Teams"
        db_table = "teams"
        ordering = ("-created_at",)

    def __str__(self):
        return f"{self.name}"

    def get_users(self):
        return ",".join(
            [str(_id) for _id in list(self.users.values_list("id", flat=True))]
        )