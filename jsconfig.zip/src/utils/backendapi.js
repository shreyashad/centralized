import axios from "axios";



const API_BASE_URL = process.env.API_BASE_URL || "";

const api = {
    administratorDashboar:{
        totaluser: async () => {
            try {
                const response = await axios.get(`${API_BASE_URL}/api/total-users/`);
                console.log("total user count:", response.data)
                return response.data;
            } catch (error) {
                console.error("Error fetching total user count:", error);
                throw error;
            }
        },
        activeuser: async () => {
            try {
                const response = await axios.get(`${API_BASE_URL}/api/active-users/`);
                console.log("active user count:", response.data)
                return response.data;
            } catch (error) {
                console.error("Error fetching active user count:", error);
                throw error;
            }
        },
        totalapp: async () => {
            try {
                const response = await axios.get(`${API_BASE_URL}/api/application-count/`);
                console.log("total application count:", response.data)
                return response.data;
            } catch (error) {
                console.error("Error fetching total applications count:", error);
                throw error;
            }
        },
        penddingverification: async () => {
            try {
                const response = await axios.get(`${API_BASE_URL}/api/verification-pending/`);
                console.log("pendding verification count:", response.data)
                return response.data;
            } catch (error) {
                console.error("Error fetching pendding verification count:", error);
                throw error;
            }
        },

    },
    userManagement: {
        list: async () => {
            try {
                const response = await axios.get(`${API_BASE_URL}/api/user-list/`);
                console.log("User List Data:", response.data)
                return response.data;

            } catch (error) {
                console.error("Error fetching user list:", error);
                throw error;
            }
        },
        create: async () => {
            try {
                const response = await axios.post(`${API_BASE_URL}/api/organization-create/`, data);
                return response.data;
            } catch (error) {
                console.error("Error creating organization:", error);
                throw error;
            }
        },
        detail: async (id) => {
            try {
                const response = await axios.get(`${API_BASE_URL}/api/organization/${id}/detail/`);
                return response.data;
            } catch (error) {
                console.error("Error fetching organization details:", error);
                throw error;
            }
        },
        update: async (id, data) => {
            try {
                const response = await axios.put(`${API_BASE_URL}/api/organization/${id}/detail/`, data);
                return response.data;
            } catch (error) {
                console.error("Error updating organization:", error);
                throw error;
            }
        },
        delete: async (id) => {
            try {
                const response = await axios.delete(`${API_BASE_URL}/api/organization/${id}/detail/`);
                return response.data;
            } catch (error) {
                console.error("Error deleting organization:", error);
                throw error;
            }
        },

    },

    organization: {
        list: async ({ page, size, sortBy, filters }) => {
            const params = {
                page,
                size,
                ordering: sortBy.map(sort => (sort.desc ? `-${sort.id}`: sort.id)).join(','),
                ...filters,
            };
            try {
                const response = await axios.get(`${API_BASE_URL}/api/organization-list/`, { params });
                console.log("Organization List Data:", response.data)
                return {
                    data: response.data,
                    totalPages: response.data.total_pages,
                };
            } catch (error) {
                console.error("Error fetching organization list:", error);
                throw error;
            }    
            
        },
        create: async (data) => {
            try {
                const response = await axios.post(`${API_BASE_URL}/api/organization-create/`, data);
                return response.data;
            } catch (error) {
                console.error("Error creating organization:", error);
                throw error;
            }
            
        },

        detail: async (id) => {
            const response = await axios.get(`${API_BASE_URL}/api/organization/${id}/detail/`);
            return response.data;
        },
        update: async (id, data) => {
            const response = await axios.put(`${API_BASE_URL}/api/organization/${id}/detail/`, data);
            return response.data;
        },
        delete: async (id) => {
            const response = await axios.delete(`${API_BASE_URL}/api/organization/${id}/detail/`);
            return response.data;
        },

    },
    orgSubtypes : {
        list: async () => {
            try {
                const response = await axios.get(`${API_BASE_URL}/api/org-subtype-list/`);
                console.log("Organization SubType List Data:", response.data)
                return response.data;

            } catch (error) {
                console.error("Error fetching org-subtype list:", error);
                throw error;
            }
        },
        create: async () => {
            try {
                const response = await axios.post(`${API_BASE_URL}/api/org-subtype-create/`, data);
                return response.data;
            } catch (error) {
                console.error("Error creating organization subtype:", error);
                throw error;
            }
        },
        detail: async (id) => {
            try {
                const response = await axios.get(`${API_BASE_URL}/api/org-subtype/${id}/detail/`);
                return response.data;
            } catch (error) {
                console.error("Error fetching organization subtype details:", error);
                throw error;
            }
        },
        update: async (id, data) => {
            try {
                const response = await axios.put(`${API_BASE_URL}/api/org-subtype/${id}/detail/`, data);
                return response.data;
            } catch (error) {
                console.error("Error updating organization subtype:", error);
                throw error;
            }
        },
        delete: async (id) => {
            try {
                const response = await axios.delete(`${API_BASE_URL}/api/org-subtype/${id}/detail/`);
                return response.data;
            } catch (error) {
                console.error("Error deleting organization subtype:", error);
                throw error;
            }
        },

    },
    locations: {
        list: async () => {
            try {
                const response = await axios.get(`${API_BASE_URL}/api/locations-list/`);
                console.log("Location List Data:", response.data)
                return response.data;

            } catch (error) {
                console.error("Error fetching location list:", error);
                throw error;
            }
        },
        create: async () => {
            try {
                const response = await axios.post(`${API_BASE_URL}/api/location-create/`, data);
                return response.data;
            } catch (error) {
                console.error("Error creating location:", error);
                throw error;
            }
        },
        detail: async (id) => {
            try {
                const response = await axios.get(`${API_BASE_URL}/api/location/${id}/detail/`);
                return response.data;
            } catch (error) {
                console.error("Error fetching location details:", error);
                throw error;
            }
        },
        update: async (id, data) => {
            try {
                const response = await axios.put(`${API_BASE_URL}/api/location/${id}/detail/`, data);
                return response.data;
            } catch (error) {
                console.error("Error updating location:", error);
                throw error;
            }
        },
        delete: async (id) => {
            try {
                const response = await axios.delete(`${API_BASE_URL}/api/location/${id}/detail/`);
                return response.data;
            } catch (error) {
                console.error("Error deleting location:", error);
                throw error;
            }
        },

    },
    designations: {
        list: async () => {
            try {
                const response = await axios.get(`${API_BASE_URL}/api/designations-list/`);
                console.log("Organization List Data:", response.data)
                return response.data;

            } catch (error) {
                console.error("Error fetching designation list:", error);
                throw error;
            }
        },
        create: async () => {
            try {
                const response = await axios.post(`${API_BASE_URL}/api/designation-create/`, data);
                return response.data;
            } catch (error) {
                console.error("Error creating designation:", error);
                throw error;
            }
        },
        detail: async (id) => {
            try {
                const response = await axios.get(`${API_BASE_URL}/api/designation/${id}/detail/`);
                return response.data;
            } catch (error) {
                console.error("Error fetching designation details:", error);
                throw error;
            }
        },
        update: async (id, data) => {
            try {
                const response = await axios.put(`${API_BASE_URL}/api/designation/${id}/detail/`, data);
                return response.data;
            } catch (error) {
                console.error("Error updating designation:", error);
                throw error;
            }
        },
        delete: async (id) => {
            try {
                const response = await axios.delete(`${API_BASE_URL}/api/designation/${id}/detail/`);
                return response.data;
            } catch (error) {
                console.error("Error deleting designation:", error);
                throw error;
            }
        },

    },
    
    roles: {
        list: async () => {
            try {
                const response = await axios.get(`${API_BASE_URL}/api/organization-list/`);
                console.log("Organization List Data:", response.data)
                return response.data;

            } catch (error) {
                console.error("Error fetching organization list:", error);
                throw error;
            }
        },
        create: async () => {
            try {
                const response = await axios.post(`${API_BASE_URL}/api/organization-create/`, data);
                return response.data;
            } catch (error) {
                console.error("Error creating organization:", error);
                throw error;
            }
        },
        detail: async (id) => {
            try {
                const response = await axios.get(`${API_BASE_URL}/api/organization/${id}/detail/`);
                return response.data;
            } catch (error) {
                console.error("Error fetching organization details:", error);
                throw error;
            }
        },
        update: async (id, data) => {
            try {
                const response = await axios.put(`${API_BASE_URL}/api/organization/${id}/detail/`, data);
                return response.data;
            } catch (error) {
                console.error("Error updating organization:", error);
                throw error;
            }
        },
        delete: async (id) => {
            try {
                const response = await axios.delete(`${API_BASE_URL}/api/organization/${id}/detail/`);
                return response.data;
            } catch (error) {
                console.error("Error deleting organization:", error);
                throw error;
            }
        },

    },
    permissions: {
        list: async () => {
            try {
                const response = await axios.get(`${API_BASE_URL}/api/organization-list/`);
                console.log("Organization List Data:", response.data)
                return response.data;

            } catch (error) {
                console.error("Error fetching organization list:", error);
                throw error;
            }
        },
        create: async () => {
            try {
                const response = await axios.post(`${API_BASE_URL}/api/organization-create/`, data);
                return response.data;
            } catch (error) {
                console.error("Error creating organization:", error);
                throw error;
            }
        },
        detail: async (id) => {
            try {
                const response = await axios.get(`${API_BASE_URL}/api/organization/${id}/detail/`);
                return response.data;
            } catch (error) {
                console.error("Error fetching organization details:", error);
                throw error;
            }
        },
        update: async (id, data) => {
            try {
                const response = await axios.put(`${API_BASE_URL}/api/organization/${id}/detail/`, data);
                return response.data;
            } catch (error) {
                console.error("Error updating organization:", error);
                throw error;
            }
        },
        delete: async (id) => {
            try {
                const response = await axios.delete(`${API_BASE_URL}/api/organization/${id}/detail/`);
                return response.data;
            } catch (error) {
                console.error("Error deleting organization:", error);
                throw error;
            }
        },

    },
    teams: {
        list: async () => {
            try {
                const response = await axios.get(`${API_BASE_URL}/api/organization-list/`);
                console.log("Organization List Data:", response.data)
                return response.data;

            } catch (error) {
                console.error("Error fetching organization list:", error);
                throw error;
            }
        },
        create: async () => {
            try {
                const response = await axios.post(`${API_BASE_URL}/api/organization-create/`, data);
                return response.data;
            } catch (error) {
                console.error("Error creating organization:", error);
                throw error;
            }
        },
        detail: async (id) => {
            try {
                const response = await axios.get(`${API_BASE_URL}/api/organization/${id}/detail/`);
                return response.data;
            } catch (error) {
                console.error("Error fetching organization details:", error);
                throw error;
            }
        },
        update: async (id, data) => {
            try {
                const response = await axios.put(`${API_BASE_URL}/api/organization/${id}/detail/`, data);
                return response.data;
            } catch (error) {
                console.error("Error updating organization:", error);
                throw error;
            }
        },
        delete: async (id) => {
            try {
                const response = await axios.delete(`${API_BASE_URL}/api/organization/${id}/detail/`);
                return response.data;
            } catch (error) {
                console.error("Error deleting organization:", error);
                throw error;
            }
        },

    },
    notifications: {},
    registration: {
        getOrgNames: async (orgType) => {
            const response = await axios.get(` ${API_BASE_URL}/api/org-names/`,orgType);
            return response.data;
        },

        getOrgSubTypes: async (orgType) => {
            const response = await axios.get(` ${API_BASE_URL}/api/org-sub-types`, orgType);
            return response.data;
        },

        getLocationType: async (orgName) => {
            const response = await axios.get(` ${API_BASE_URL}/api/location-types?orgName=${orgName}`);
            return response.data;
        },

        getLocationNameAndCodes: async (orgName, locationType) => {
            const response = await axios.get(` ${API_BASE_URL}/api/location-names-and-codes?orgName=${orgName}&locationType=${locationType}`);
            return response.data;
        },


        register: async (data) => {
            const response = await axios.post(` ${API_BASE_URL}/api/register`, data);
            return response.data
        },
    }

};

export default api;