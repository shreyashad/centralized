import axios from "axios";
import CredentialsProvider from "next-auth/providers/credentials"

const API_BASE_URL = process.env.API_BASE_URL || "";

const authOptions = {
    providers : [
        CredentialsProvider({
            name: 'Credentials',
            credentials: {
                username: { label: 'Username' , type: 'text' },
                password: { label: 'Password', type: 'password' },
            },
            authorize(credentials, req) {
                try {
                    const res = await axios.post(` ${API_BASE_URL}/api/token`, {
                        username: credentials.username,
                        password: credentials.password,
                    });

                    const user = res.data;
                    if (!user) {
                        throw new Error("Invalid Credentials");
                    }
                    return user;
                } catch (error) {
                    throw new Error("Invalid Credentials");
                }
            },
        }),
    ],
    callbacks: {
        async jwt ({ token, user }) {
            if (user) {
                token.accessToken = user.access;
                token.refreshToken = user.refresh;
            }
            return token;
        },

        async session({ session, token }) {
            session.accessToken = token.accessToken;
            session.refreshToken = token.refreshToken;
            return session;
        },
    },
    pages: {
        signIn: "/login",
    }
};

export default authOptions;