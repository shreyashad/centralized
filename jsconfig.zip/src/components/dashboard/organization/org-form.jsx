"use client";
import { organizationFormSchema } from "@/lib/validator";
import api from "@/utils/backendapi";
import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation"
import { useState } from "react";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";
import { DashHeading } from "../dash-heading";
import { Button } from "@/components/ui/button";
import { Trash } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertModal } from "../alert-modal";



export const OrganizationForm = ({ initialData }) => {
    const router = useRouter();
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);

    const title = initialData ? "Edit Organization" : "Create Organization";
    const description = initialData ? "Edit a Organization" : "Create a new Organization";
    const toastMessage = initialData
    ? "Organization updated successfully"
    : "Organization created successfully";
    const action = initialData ? "Save Changes" : "Create";

    const form = useForm({
        resolver: zodResolver(organizationFormSchema),
        defaultValues: initialData || {
            name: "",
            org_type: "",
        },
    });

    const onSubmit = async (values) => {
        setLoading(true);
        try {
            if (initialData) {
                await api.organization.update(initialData.id, values);
            } else {
                await api.organization.create(values);
            }
            toast.success(toastMessage);
            router.push(`/administrator/org-management/organizations`);
        } catch (err) {
            toast.error(err.message);
        }
        setLoading(false);
    };
    
    const onDelete = async () => {
        setLoading(true);
        try {
            await api.organization.delete(initialData.id);
            toast.success("Organization deleted successfully");
            router.push(`/administrator/org-management/organizations`)
        } catch (err) {
            toast.error(err.message);
        }
        setLoading(false);
    };

    return(
        <>
            <div className="flex items-center justify-between">
                <DashHeading title={title} description={description} />
                {initialData && (
                    <Button
                        disabled={loading}
                        variant="destructive"
                        size="icon"
                        onClick={() => setOpen(true)}
                    >
                        <Trash className="h-4 w-4" />
                    </Button>
                )}
            </div>
            <Separator />
            <Form {...form}>
                <form
                    onSubmit={form.handleSubmit(onSubmit)}
                    className="w-full space-y-8"
                >
                    <div className="grid-cols-2 gap-8 md:grid">
                        <FormField
                            control={form.control}
                            name="name"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Name</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="Name"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField 
                            control={form.control}
                            name="org_type"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Organization Type</FormLabel>
                                    <Select
                                        disabled={loading}
                                        onValueChange={field.onChange}
                                        value={field.value}
                                        defaultValue={field.value}
                                    >
                                        <FormControl>
                                            <SelectTrigger>
                                                <SelectValue
                                                    defaultValue={field.value}
                                                    placeholder="Organization Type"
                                                />
                                            </SelectTrigger>
                                        </FormControl>
                                        <SelectContent>
                                            <SelectItem value="MDIndia">MDIndia</SelectItem>
                                            <SelectItem value="Insurance Company">Insurance Company</SelectItem>
                                            <SelectItem value="Broker">Broker</SelectItem>
                                            <SelectItem value="Corporate">Corporate</SelectItem>
                                        </SelectContent>
                                    </Select>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                    </div>
                    <div className="space-x-4">
                        <Button disabled={loading} className="ml-auto" type="submit">
                            {action}
                        </Button>
                        <Button
                            disabled={loading}
                            className="ml-auto"
                            type="button"
                            onClick={() => {
                                router.back();
                            }}
                        >
                            Cancel
                        </Button>
                    </div>
                </form>
            </Form>
            {initialData && (
                <AlertModal
                    title="Are you Sure"
                    description="This action cannot be undone."
                    name={initialData?.name}
                    isOpen={open}
                    onClose={() => setOpen(false)}
                    onConfirm={onDelete}
                    loading={loading}
                />
            )}
        </>
    );

};