"use client";
import { useRouter } from "next/navigation"
import { DashHeading } from "../dash-heading";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Plus } from "lucide-react";

import { useCallback, useEffect, useState } from "react";
import api from "@/utils/backendapi";
import { Loading } from "../loading";
import DataTable from "@/components/ui/data-table/data-table";
import { OrgCellAction } from "./cell-action";


const OrganizationClient = () => {
    const router = useRouter();
    const [data, setData] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);
    const [pageCount, setPageCount] = useState(0);

    const fetchData = useCallback(async ({ pageIndex, pageSize, sortBy, filters }) => {
        try {
            const result = await api.organization.list({
                page: pageIndex + 1,
                size: pageSize,
                sortBy,
                filters,
            });
            console.log("Organizations data:", result);
            setData(result.data);
            setPageCount(result.totalPages);
            setIsLoading(false);
        } catch (error) {
            setError(error);
            console.log("Error:", error);
            setIsLoading(false);
        }
    }, []);

    const columns = [
        {
            Header: 'ID',
            accessor: 'id',
        },
        {
            Header: 'Organization Name',
            accessor: 'name',
        },
        {
            Header: 'Organization Type',
            accessor: 'org_type',
        },
        {
            Header: 'Created At',
            accessor: 'created_at',
        },
        {
            Header: 'Actions',
            Cell: ({ row }) => <OrgCellAction data={row.original} />,
        },
    ];

    const actions = [
        {
            label: 'Delete Selected',
            onClick: async (selectedRows) => {
                // Implement batch delete action
                try {
                    await Promise.all(selectedRows.map(row => api.organization.delete(row.id)));
                    toast.success("Selected organizations deleted successfully");
                    fetchData({ pageIndex: 0, pageSize: 10, sortBy: [], filters: [] });
                } catch (error) {
                    toast.error("Error deleting selected organizations");
                }
            },
        }
    ]



    if (isLoading) return <Loading />;

    if (error) return <div>Error: {error.message}</div>;

    return(
        <>
            <div className="flex items-center justify-between">
                <DashHeading
                    title="Organization List "
                />
                <Button
                    onClick={() => {
                        router.push("/administrator/org-management/organizations/new");
                    }}
                >
                    <Plus className="mr-2 h-4 w-4"> Add New</Plus>
                </Button>
            </div>
            <Separator />
            <div>
                    <DataTable
                        columns={columns}
                        fetchData={fetchData}
                        actions={actions}
                    />
            </div>
        </>
    );
};

export default OrganizationClient;