import { Checkbox } from "@/components/ui/checkbox";
import { DataTableColumnHeader } from "@/components/ui/data-table/data-table-column-header";


export const organizationColumns = [
    {
        accessorKey: "id",
        header: ({ column }) => (
            <DataTableColumnHeader column={column} title="ID" />
        ),
        cell: ({ row }) => (
            <div>{row.getValue("id")}</div>
        ),
        enableSorting: false,
        enableHiding: false,
    },
    {
        accessorKey: "name",
        header: ({ column }) => (
          <DataTableColumnHeader column={column} title="Organization Name" />
        ),
        cell: ({ row }) => (
          <div className="font-bold">{row.getValue("name")}</div>
        ),
        enableSorting: true,
        enableHiding: false,
      },
      {
        accessorKey: "org_type",
        header: ({ column }) => (
          <DataTableColumnHeader column={column} title="Organization Type" />
        ),
        cell: ({ row }) => (
          <div>{row.getValue("org_type")}</div>
        ),
        enableSorting: true,
        enableHiding: false,
      },
      {
        accessorKey: "created_at",
        header: ({ column }) => (
          <DataTableColumnHeader column={column} title="Created At" />
        ),
        cell: ({ row }) => (
          <div>{new Date(row.getValue("created_at")).toLocaleString()}</div>
        ),
        enableSorting: true,
        enableHiding: false,
      },
      {
        accessorKey: "created_by",
        header: ({ column }) => (
          <DataTableColumnHeader column={column} title="Created By" />
        ),
        cell: ({ row }) => (
          <div>{row.getValue("created_by.username")}</div> // Assuming username is accessible
        ),
        enableSorting: true,
        enableHiding: false,
      },
      {
        accessorKey: "updated_at",
        header: ({ column }) => (
          <DataTableColumnHeader column={column} title="Last Modified At" />
        ),
        cell: ({ row }) => (
          <div>{new Date(row.getValue("updated_at")).toLocaleString()}</div>
        ),
        enableSorting: true,
        enableHiding: false,
      },
      {
        accessorKey: "updated_by",
        header: ({ column }) => (
          <DataTableColumnHeader column={column} title="Last Modified By" />
        ),
        cell: ({ row }) => (
          <div>{row.getValue("updated_by.username")}</div> // Assuming username is accessible
        ),
        enableSorting: true,
        enableHiding: false,
      },
     
]