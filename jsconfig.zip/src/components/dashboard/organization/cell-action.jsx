import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import api from "@/utils/backendapi";
import { Pencil, Trash2 } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import toast from "react-hot-toast";
import { AlertModal } from "../alert-modal";


export function OrgCellAction({ data }) {
    const router = useRouter();
    const [alertModalOpen, setAlertModalOpen] = useState(false);

    const fetchOrganizations = async () => {
        try {
            const result = await api.organization.list();
            return result;
        } catch (error) {
            toast.error("Error fetching organizations");
            throw error;
        }
    };

    const deleteOrganization = async (id) => {
        try {
            await api.organization.delete(id);
            toast.success("Organization deleted successfully");
            await fetchOrganizations();
        } catch (error) {
            toast.error("Error deleting organization");
        }
    };

    return(
        <div className="flex justify-center space-x-2">
            <TooltipProvider>
                <Tooltip>
                    <TooltipTrigger asChild>
                        <Button
                            variant="ghost"
                            size="icon"
                            className="hover:bg-secondary"
                            onClick={() => {
                                router.push(`/administrator/org-management/organization/${data.id}`);
                            }}
                        >
                            <Pencil className="h-4 w-4 text-foreground" />

                        </Button>

                    </TooltipTrigger>
                    <TooltipContent>
                        <p>Update organization</p>
                    </TooltipContent>
                </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
                <Tooltip>
                    <TooltipTrigger asChild>
                        <Button
                        variant="ghost"
                        size="icon"
                        className="hover:bg-secondary"
                        onClick={() => {
                            setAlertModalOpen(true);
                        }}
                        >
                        <Trash2 className="h-4 w-4 text-foreground" />
                        </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                        <p>Delete organization</p>
                    </TooltipContent>
                </Tooltip>
            </TooltipProvider>

            <AlertModal
                title="Are you sure?"
                description="This action cannot be undone."
                name={data.name}
                isOpen={alertModalOpen}
                onClose={() => setAlertModalOpen(false)}
                onConfirm={() => deleteOrganization(data.id)}
                loading={false} // You can handle loading state as needed
            />
        </div>
    );
}