"use client";
import api from "@/utils/backendapi";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Loading } from "../loading";
import { DashHeading } from "../dash-heading";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Plus } from "lucide-react";




const DepartmentClient = () => {
    const router = useRouter();
    const [data,setData] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchData = async () => {
            try{
                const result = await api.dep.list();
                console.log("Departments list:", result.data );
                setData(result.data);
                setIsLoading(false);

            } catch (error) {
                setError(error);
                console.log("Error:", error);
                setIsLoading(false);

            }
        };
        fetchData();
    }, []);

    if (isLoading) return <Loading />;

    if (error) return <div>Error: {error.message}</div>;

    return(
        <>
            <div className="flex items-center justify-between">
                <DashHeading
                    title="Departments List "
                />
                <Button
                    onClick={() => {
                        router.push("/administrator/org-management/department/new");
                    }}
                >
                    <Plus className="mr-2 h-4 w-4"> Add New</Plus>
                </Button>
            </div>
            <Separator />
            <div>
              {/* <DataTable columns={columns} data={data} /> */}
            </div>
        </>
    );

};

export default DepartmentClient;