


export const columns = [
    {
        accessorkey: "username",
        header: "User",
    },
    {
        accessorkey: "org_type",
        header: "Organization"
    },
    {
        accessorkey: "is_verified",
        header: "Verified"
    },
    {
        accessorkey: "is_online",
        header: "Status"
    },
];