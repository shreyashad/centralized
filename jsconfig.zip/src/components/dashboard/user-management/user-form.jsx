import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation"
import { useState } from "react";
import { useForm } from "react-hook-form";



export const UserForm = ({ initialData }) => {
    const router = useRouter();
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);

    const title = initialData ? " Edit User": " Create User";
    const description = initialData ? " Edit a User": "Create a User";
    const toastMessage = initialData
    ? "User updated Successfully"
    : "User created Successfully";

    const action = initialData ? "Save Changes" : " Create";

    const form = useForm({
        resolver: zodResolver()
    })
}