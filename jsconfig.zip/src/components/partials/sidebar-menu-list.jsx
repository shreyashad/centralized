import { BookCheckIcon, BookOpenCheck, BookOpenText, BookUser, Briefcase, BriefcaseBusiness, Building2, LayoutDashboard, NotebookPen, Settings, Shield, Trophy, UserCheck, UserRoundCog, UsersRound } from "lucide-react";


export const DashboardMenuConfig = {
    Administrator: [
        {
            title: "Dashboard",
            icon: LayoutDashboard,
            href: "/administrator/dashboard",
            color: "text-sky-500",
        },
        {
            title: "User-Management",
            icon: UserRoundCog,
            href: "/administrator/user-management",
            color: "text-sky-500",
            
        },
        {
            title: "Role and Permission",
            icon: Settings,
            href: "/administrator/roles",
            color: "text-sky-500",
            isChidren: true,
            children: [
                {
                    title: "Roles",
                    icon: UserCheck,
                    color: "text-red-500",
                    href: "/administrator/user-management/roles",
                  },
                  {
                    
                    title: "Permissions",
                    icon: Shield,
                    color: "text-red-500",
                    href: "/administrator/user-management/permissions",
                  },
                  
            ]
        },
        {
            title: "Organization-Management",
            icon: Building2,
            href: "/administrator/org-management",
            color: "text-sky-500",
            isChidren: true,
            children: [
                {
                    title: "Organization",
                    icon: BriefcaseBusiness,
                    color: "text-red-500",
                    href: "/administrator/org-management/organizations",
                  },
                  {
                    
                    title: "Org-Subtype",
                    icon: BriefcaseBusiness,
                    color: "text-red-500",
                    href: "/administrator/org-management/org-subtype",
                  },
                  {
                    title: "Locations",
                    icon: BriefcaseBusiness,
                    color: "text-red-500",
                    href: "/administrator/org-management/locations",
                  },
                  {
                    title: "Departments",
                    icon: Briefcase,
                    color: "text-red-500",
                    href: "/administrator/org-management/departments",
                  },
                  {
                    title: "Designations",
                    icon: BookUser,
                    color: "text-red-500",
                    href: "/administrator/org-management/designations",
                  },
            ]
        },
        {
            title: "Teams",
            icon: UsersRound,
            href: "/administrator/teams",
            color: "text-sky-500",
        },
        {
            title: "Application Management",
            icon: UsersRound,
            href: "/administrator/applications",
            color: "text-sky-500",
        },
        {
            title: "Logs and Reports",
            icon: UsersRound,
            href: "/administrator/logs_reports",
            color: "text-sky-500",
        },
        {
            title: "Profile",
            icon: Settings,
            href: "/administrator/profile",
            color: "text-sky-500",
        },
    ],
    Authenticator : [
        {
            title: "Dashboard",
            icon: LayoutDashboard,
            href: "/hod/dashboard",
            color: "text-sky-500",
        },
        {
            title: "Traning Request",
            icon: LayoutDashboard,
            href: "/hod/users",
            color: "text-sky-500",
            
        },
        {
            title: "Organization-Management",
            icon: LayoutDashboard,
            href: "/administrator/organization",
            color: "text-sky-500",
            isChidren: true,
            children: [
                {
                    title: "Branches",
                    icon: BookOpenCheck,
                    color: "text-red-500",
                    href: "/administrator/organization/branches",
                  },
                  {
                    title: "Departments",
                    icon: BookOpenCheck,
                    color: "text-red-500",
                    href: "/administrator/organization/departments",
                  },
                  {
                    title: "Designations",
                    icon: BookOpenCheck,
                    color: "text-red-500",
                    href: "/administrator/organization/designations",
                  },
            ]
        },
        {
            title: "Teams",
            icon: UsersRound,
            href: "/administrator/teams",
            color: "text-sky-500",
        },
        {
            title: "Profile",
            icon: Settings,
            href: "/administrator/profile",
            color: "text-sky-500",
        },
    ],
    Siteadministrator : [
        {
            title: "Dashboard",
            icon: LayoutDashboard,
            href: "/employee/dashboard",
            color: "text-sky-500",
        },
        {
            title: "My-Course",
            icon: BookOpenText,
            href: "/employee/my-courses",
            color: "text-sky-500",
            
        },
        {
            title: "My-Exams",
            icon: NotebookPen,
            href: "/employee/exams",
            color: "text-sky-500",
        },
        {
            title: "My-Performance",
            icon: Trophy,
            href: "/employee/teams",
            color: "text-sky-500",
        },
        {
            title: "Teams",
            icon: UsersRound,
            href: "/employee/teams",
            color: "text-sky-500",
        },
        {
            title: "Profile",
            icon: Settings,
            href: "/employee/profile",
            color: "text-sky-500",
        },
    ]
    

};