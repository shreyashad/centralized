import { forwardRef } from "react";
import { useStepper } from "./use-stepper";
import { Collapsible, CollapsibleContent } from "../collapsible";
import { StepButtonContainer } from "./step-button-container";
import { StepIcon } from "./step-icon";
import { StepLabel } from "./step-label";
import { cn } from "@/lib/utils";


const VerticalStep = forwardRef(function VerticalStep(
    {
        children,
        index,
        isCompletedStep,
        isCurrentStep,
        label,
        description,
        icon,
        hasVisited,
        state,
        checkIcon: checkIconProp,
        errorIcon: errorIconProp,
        onClickStep,
    }, ref
) {
    const {
        checkIcon: checkIconContext,
        errorIcon: errorIconContext,
        isError,
        isLoading,
        variant,
        onClickStep: onClickStepGeneral,
        clickable,
        expandVerticalSteps,
        styles,
        scrollTracking,
        orientation,
        steps,
        setStep,
        isLastStep: isLastStepCurrentStep,
        previousActiveStep,
    } = useStepper();
    const opacity = hasVisited ? 1 : 0.8;
    const localIsLoading = isLoading || state === "loading";
    const localIsError = isError || state === "error";

    const isLastStep = index === steps.length - 1;

    const active =
        variant === "line" ? isCompletedStep || isCurrentStep : isCompletedStep;
    const checkIcon = checkIconProp || checkIconContext;
    const errorIcon = errorIconProp || errorIconContext;

    const renderChildren = () => {
        if (!expandVerticalSteps) {
            return (
                <Collapsible open={isCurrentStep}>
                    <CollapsibleContent
                        ref={(node) => {
                            if(scrollTracking && 
                                ((index === 0 &&
                                    previousActiveStep && 
                                    previousActiveStep === steps.length || 
                                    (index && index > 0)
                                ))) {
                                    node?.scrollIntoView({
                                        behavior: "smooth",
                                        block: "center",
                                    });
                                }
                        }}
                        className="overflow-hidden data-[state=open]:animate-collapsible-down data-[state=closed]:animate-collapsible-up"
                    >
                        {children}
                    </CollapsibleContent>
                </Collapsible>
            );
        }
        return children;
    };
    return (
        <div
            ref={ref}
            className={cn(
                "stepper__vertical-step",
                verticalStepVarianst({
                    variant: variant?.includes("circle") ? "circle" : "line",

                }),
                isLastStepCurrentStep && "gap-[var(--step-gap)]",
                styles?.["vertical-step"]
            )}
            data-optional={steps[index || 0]?.optional}
            data-completed={isCompletedStep}
            data-active={active}
            data-clickable={clickable || !!onClickStep}
            data-invalid={localIsError}
            onClick={() => 
                onClickStep?.(index || 0, setStep) ||
                onClickStepGeneral?.(index || 0, setStep)
            }
        >
            <div
                data-vertical={true}
                data-active={active}
                className={cn(
                  "stepper__vertical-step-container",
                  "flex items-center",
                  variant === "line" &&
                    "border-s-[3px] data-[active=true]:border-primary py-2 ps-3",
                  styles?.["vertical-step-container"]
                )}
            >
                <StepButtonContainer
                    {...{ isLoading: localIsLoading, isError: localIsError, ...props }}
                >
                    <StepIcon 
                        {...{
                            index,
                            isError: localIsError,
                            isLoading: localIsLoading,
                            isCurrentStep,
                            isCompletedStep,
                          }}
                          icon={icon}
                          checkIcon={checkIcon}
                          errorIcon={errorIcon}
                    />
                </StepButtonContainer>
                <StepLabel 
                    label={label}
                    description={description}
                    {...{ isCurrentStep, opacity }}
                />
            </div>
            <div 
                className={cn(
                    "stepper__vertical-step-content",
                    !isLastStep && "min-h-4",
                    variant !== "line" && "ps-[--step-icon-size]",
                    variant === "line" && orientation === "vertical" && "min-h-0",
                    styles?.["vertical-step-content"]
                )}
            >
                {renderChildren()}
            </div>
        </div>
    );

});

export { VerticalStep };