"use client";
import { Children, cloneElement, forwardRef, isValidElement } from "react";
import { Step } from "./steps";
import { useMediaQuery } from "./use-media-query";
import { StepperProvider } from "./context";
import { useStepper } from "./use-stepper";


const VARIABLE_SIZES = {
    sm: "36px",
    md: "40px",
    lg: "44px",
};

const Stepper = forwardRef((props, ref) => {
    const {
        className,
        children,
        orientation: orientationProp,
        state,
        responsive,
        checkIcon,
        errorIcon,
        onClickStep,
        mobileBreakpoint,
        expandVerticalSteps = false,
        initialStep = 0,
        size,
        steps,
        variant,
        styles,
        variables,
        scrollTracking = false,
        ...rest
    } = props;

    const childArr = Children.toArray(children);
    const items = [];
    
    const footer = childArr.map((child, _index) => {
        if (!isValidElement(child)) {
            throw new Error("Stepper children must be valid React elements.");
        }
        if (child.type === Step) {
            items.push(child);
            return null;
        }
        return child;
    });


    const stepCount = items.length;

    const isMobile = useMediaQuery(
        `(max-width: ${mobileBreakpoint || "768px"})`,
    );

    const clickable = !!onClickStep;

    const orientation = isMobile && responsive ? "vertical" : orientationProp;

    const isVertical = orientation === "vertical";

    return (
        <StepperProvider>
            <div>
                <VerticalContent>{items}</VerticalContent>
            </div>
            {orientation === "horizontal" && (
                <HorizontalContent>{items}</HorizontalContent>
            )}
            {footer}
        </StepperProvider>
    );
});

Stepper.defaultProps = {
    size: "md",
    orientation: "horizontal",
    responsive: true,
};


const VerticalContent = ({ children }) => {
    const { activeStep } = useStepper();

    const childArr = Children.toArray(children);
    const stepCount = childArr.length;

    return(
        <>
            {Children.map(children, (child, i) => {
                const isCompletedStep =
                    (isValidElement(child) && 
                        child.props.isCompletedStep) ??
                        i < activeStep;
                const isLastStep = i === stepCount - 1;
                const isCurrentStep = i === activeStep;

                const stepProps = {
                    index: i,
                    isCompletedStep,
                    isCurrentStep,
                    isLastStep,

                };
                if (isValidElement(child)) {
                    return cloneElement(child, stepProps);
                }
                return null;
            })}
        </>
    );
};

const HorizontalContent = ({ children }) => {
    const { activeStep } = useStepper();
    const childArr = Children.toArray(children);

    if (activeStep > childArr.length) {
        return null;
    }

    return (
        <>
            {Children.map(childArr[activeStep], (node) => {
                if (!isValidElement(node)) {
                    return null;
                }
                return Children.map(
                    node.props.children,
                    (childNode) => childNode,
                );
            })}
        </>
    );
};

export {Stepper, Step, useStepper };