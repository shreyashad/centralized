/**
 * @typedef {import("lucide-react").LucideIcon} LucideIcon
 */

/** @typedef {(LucideIcon | React.ComponentType<any> | undefined)} IconType */

/** @typedef {{ id?: string; label?: string; description?: string; icon?: IconType; optional?: boolean; }} StepItem */

/** @typedef {{ orientation?: "vertical" | "horizontal"; state?: "loading" | "error"; responsive?: boolean; checkIcon?: IconType; errorIcon?: IconType; onClickStep?: (step: number, setStep: (step: number) => void) => void; mobileBreakpoint?: string; variant?: "circle" | "circle-alt" | "line"; expandVerticalSteps?: boolean; size?: "sm" | "md" | "lg"; styles?: { "main-container"?: string; "horizontal-step"?: string; "horizontal-step-container"?: string; "vertical-step"?: string; "vertical-step-container"?: string; "vertical-step-content"?: string; "step-button-container"?: string; "step-label-container"?: string; "step-label"?: string; "step-description"?: string; }; variables?: { "--step-icon-size"?: string; "--step-gap"?: string; }; scrollTracking?: boolean; }} StepOptions */

/** @typedef {{ label?: string | React.ReactNode; description?: string; icon?: IconType; state?: "loading" | "error"; checkIcon?: IconType; errorIcon?: IconType; isCompletedStep?: boolean; isKeepError?: boolean; onClickStep?: (step: number, setStep: (step: number) => void) => void; }} StepProps */

/** @typedef {{ isLastStep?: boolean; isCurrentStep?: boolean; index?: number; hasVisited: boolean | undefined; isError?: boolean; isLoading?: boolean; }} StepSharedProps */


module.exports = {
    IconType,
    StepItem,
    StepOptions,
    StepperProps,
    StepProps,
    StepSharedProps,

};