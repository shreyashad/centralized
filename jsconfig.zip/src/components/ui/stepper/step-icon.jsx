import { cva } from "class-variance-authority";
import { forwardRef, useMemo } from "react";
import { useStepper } from "./use-stepper";
import { CheckIcon, Loader2, X } from "lucide-react";
import { cn } from "@/lib/utils";


const iconVariants = cva("", {
    variants: {
        size: {
            sm: "size-4",
            md: "size-4",
            lg: "size-5",
        },
    },
    defaultVariants: {
        size: "md",
    },
});


const StepIcon = forwardRef((props, ref) => {
    const { size } = useStepper();
    const {
        isCompletedStep,
        isCurrentStep,
        isError,
        isLoading,
        isKeepError,
        icon: CustomIcon,
        index,
        checkIcon: CustomCheckIcon,
        errorIcon: CustomErrorIcon,
    } = props;

    const Icon = useMemo(() => (CustomIcon ? CustomIcon : null), [CustomIcon]);
    const ErrorIcon = useMemo(() => (CustomErrorIcon ? CustomErrorIcon : null), [
        CustomErrorIcon,
    ]);
    const Check = useMemo(() => (CustomCheckIcon ? CustomCheckIcon : CheckIcon), [
        CustomCheckIcon,
    ]);

    return useMemo(() => {
        if (isCompletedStep) {
            if (isError && isKeepError) {
                return (
                    <div key="icon">
                        <X className={cn(iconVariants({ size }))} />
                    </div>
                );
            }
            return (
                <div key="check-icon">
                    <Check className={cn(iconVariants({ size }))} />
                </div>
            );
        }
        if (isCurrentStep) {
            if (isError && ErrorIcon) {
                return (
                    <div key="error-icon">
                        <ErrorIcon className={cn(iconVariants({ size }))} />
                    </div>
                );
            }
            if (isError) {
                return (
                    <div key="icon">
                         <X className={cn(iconVariants({ size }))} />
                    </div>
                );
            }
            if (isLoading) {
                return <Loader2 className={cn(iconVariants({ size }), "animate-spin")} />;
            }
        }
        if (Icon) {
            return (
                <div key="step-icon">
                    <Icon className={cn(iconVariants({ size }))} />
                </div>
            );
        }
        return (
            <span ref={ref} key="label" className={cn("font-normal text-center text-md")}>
                 {(index || 0) + 1}
            </span>
        );

    }, [
        isCompletedStep,
        isCurrentStep,
        isError,
        isLoading,
        Icon,
        index,
        Check,
        ErrorIcon,
        isKeepError,
        ref,
        size,
    ]);
});

export { StepIcon };