"use client";
import api from "@/utils/backendapi";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { Stepper } from "../ui/stepper";

const RegistrationStepperForm = () => {
    const [currentStep, setCurrentStep] = useState(0);
    const [designations, setDesignations] = useState([]);
    const [departments, setDepartments] = useState ([]);
    const [orgNames, setOrgNames] = useState([]);
    const [orgSubTypes, setOrgSubTypes] = useState([]);
    const [locationTypes, setLocationTypes] = useState([]);
    const [locationNamesAndCodes, setLocationNamesAndCodes] = useState([]);
    const { register, handleSubmit, watch, formState: {errors} } = useForm();


    const orgType = watch('org_type');
    const orgName = watch('org_name');
    const locationType = watch('location_type');

    useEffect(() => {
        if (orgType) {
            api.registration.getOrgNames(orgType).then(data => setOrgNames(data));
            api.registration.getOrgSubTypes(orgType).then(data => setOrgSubTypes(data));

        }
    }, [orgType]);

    useEffect(() => {
        if (orgName && locationType) {
            api.registration.getLocationType(orgName).then(data => setLocationTypes(data));

        }
    }, [orgName]);



    const onSubmit = data => {
        api.registration.register(data).then(response => {

        }).catch(error => {

        });
    };

    const steps = [
        {
            title: ' User Info',
            content: (
                <>
                    <lable>First Name</lable>
                    <input {...register('first_name', {required: true})} className="input" />
                    {errors.first_name && <span>This field is required</span>}

                    <label>Last Name</label>
                    <input {...register('last_name', { required: true })} className="input" />
                    {errors.last_name && <span>This field is required</span>}

                    <label>Designation</label>
                    <select {...register('designation', { required: true })} className="input">
                        {Object.keys(Designation).map(key => (
                            <option key={key} value={OrgType[key]}>{OrgType[key]}</option>
                        ))}
                    </select>
                    {errors.org_type && <span>This field is required</span>}

                </>
            ),
        }
    ];

    return (
        <form onSubmit={handleSubmit(onSubmit)} className="stepper-form">
            <Stepper steps= {steps} currentStep={currentStep} onStepChange={setCurrentStep} />
        </form>
    );
};
export default RegistrationStepperForm;