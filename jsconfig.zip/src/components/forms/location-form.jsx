import { zodResolver } from "@hookform/resolvers/zod";
import axios from "axios";
import { useRouter } from "next/navigation"
import { useState } from "react";
import { useForm } from "react-hook-form";



const API_BASE_URL = process.env.API_BASE_URL || '';

export const LocationForm = ({ initalData }) => {
    const router = useRouter();
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);

    const title = initalData ? "Edit L" : "Create Location";
    const description = initalData ? "Edit a Location" : "Create a New Location";
    const toastMessage = initalData ? "Location updated successfully": "Location created successfully";
    const action = initalData ? "Save Changes": "Create";

    const form = useForm({
        resolver: zodResolver(),
        defaultValues: initalData || {
            org_type: "",
            org_name: "",
            location_type: "",
            location_name: "",
            location_code: "",
        },
    });

const createLocation = async (values) => {
    try {
        const response = await axios.post(` ${API_BASE_URL}/api/locations/`, values, {
            headers: {
                'Content-Type': 'application/json',
              },
        });
        toast
    }
}

}