import axios from "axios";

const API_BASE_URL = process.env.API_BASE_URL || "";

const api = {
    organization: {
        list: async () => {
            const response = await axios.get(`${API_BASE_URL}/api/organization-list/`);
            return response.data;
        },
        create: async (data) => {
            const response = await axios.post(`${API_BASE_URL}/api/organization-create/`, data);
            return response.data;
        },
        detail: async (id) => {
            const response = await axios.get(`${API_BASE_URL}/api/organization/${id}/detail/`);
            return response.data;
        },
        update: async (id, data) => {
            const response = await axios.put(`${API_BASE_URL}/api/organization/${id}/detail/`, data);
            return response.data;
        },
        delete: async (id) => {
            const response = await axios.delete(`${API_BASE_URL}/api/organization/${id}/detail/`);
            return response.data;
        },
    },
    registration: {
        getOrgNames: async (orgType) => {
            const response = await axios.get(`${API_BASE_URL}/api/org-names`, { params: { orgType } });
            return response.data;
        },
        getOrgSubTypes: async (orgType) => {
            const response = await axios.get(`${API_BASE_URL}/api/org-sub-types`, { params: { orgType } });
            return response.data;
        },
        getLocationTypes: async (orgName) => {
            const response = await axios.get(`${API_BASE_URL}/api/location-types`, { params: { orgName } });
            return response.data;
        },
        getLocationNamesAndCodes: async (orgName, locationType) => {
            const response = await axios.get(`${API_BASE_URL}/api/location-names-and-codes`, { params: { orgName, locationType } });
            return response.data;
        },
        register: async (data) => {
            const response = await axios.post(`${API_BASE_URL}/api/register`, data);
            return response.data;
        },
    },
};

export default api;



import { useState, useEffect } from 'react';
import {
  Box,
  Button,
  FormControl,
  FormLabel,
  Input,
  Stack,
  Select,
  Text,
  useToast,
} from '@chakra-ui/react';
import axios from 'axios';

const RegistrationForm = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    orgType: '',
    orgName: '',
    orgSubType: '',
    locationType: '',
    locationName: '',
    locationCode: '',
    department: '',
    designation: '',
    mobile: '',
    username: '',
    empCode: '',
    password: '',
    confirmPassword: '',
  });

  const [orgNames, setOrgNames] = useState([]);
  const [orgSubTypes, setOrgSubTypes] = useState([]);
  const [locationTypes, setLocationTypes] = useState([]);
  const [locationNames, setLocationNames] = useState([]);
  const [locationCodes, setLocationCodes] = useState([]);

  const toast = useToast();

  useEffect(() => {
    if (formData.orgType) {
      fetchOrgNames(formData.orgType);
    }
  }, [formData.orgType]);

  useEffect(() => {
    if (formData.orgName) {
      fetchOrgSubTypes(formData.orgType);
      fetchLocationTypes(formData.orgName);
    }
  }, [formData.orgName]);

  useEffect(() => {
    if (formData.locationType) {
      fetchLocationNamesAndCodes(formData.orgName, formData.locationType);
    }
  }, [formData.locationType]);

  const fetchOrgNames = async (orgType) => {
    try {
      const response = await axios.get(`/api/org-names?orgType=${orgType}`);
      setOrgNames(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const fetchOrgSubTypes = async (orgType) => {
    try {
      const response = await axios.get(`/api/org-sub-types?orgType=${orgType}`);
      setOrgSubTypes(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const fetchLocationTypes = async (orgName) => {
    try {
      const response = await axios.get(`/api/location-types?orgName=${orgName}`);
      setLocationTypes(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const fetchLocationNamesAndCodes = async (orgName, locationType) => {
    try {
      const response = await axios.get(
        `/api/location-names-and-codes?orgName=${orgName}&locationType=${locationType}`
      );
      setLocationNames(response.data.names);
      setLocationCodes(response.data.codes);
    } catch (error) {
      console.error(error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleNext = () => {
    setStep(step + 1);
  };

  const handlePrev = () => {
    setStep(step - 1);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('/api/register', formData);
      toast({
        title: 'Registration successful.',
        status: 'success',
        duration: 3000,
        isClosable: true,
      });
      // Reset form state or navigate to success page
    } catch (error) {
      console.error(error);
      toast({
        title: 'Registration failed.',
        description: error.response?.data?.message || 'Something went wrong.',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });
    }
  };

  return (
    <Box maxW="xl" mx="auto" p={4}>
      <Stack spacing={6}>
        {step === 1 && (
          <Box>
            <Text fontSize="2xl" fontWeight="semibold" mb={4}>
              Step 1: Personal Information
            </Text>
            <FormControl>
              <FormLabel>First Name</FormLabel>
              <Input
                type="text"
                name="firstName"
                value={formData.firstName}
                onChange={handleChange}
              />
            </FormControl>
            <FormControl>
              <FormLabel>Last Name</FormLabel>
              <Input
                type="text"
                name="lastName"
                value={formData.lastName}
                onChange={handleChange}
              />
            </FormControl>
          </Box>
        )}

        {step === 2 && (
          <Box>
            <Text fontSize="2xl" fontWeight="semibold" mb={4}>
              Step 2: Organization Details
            </Text>
            <FormControl>
              <FormLabel>Organization Type</FormLabel>
              <Select
                name="orgType"
                value={formData.orgType}
                onChange={handleChange}
              >
                <option value="">Select Organization Type</option>
                <option value="MDIndia">MDIndia</option>
                <option value="Insurance Company">Insurance Company</option>
                <option value="Broker">Broker</option>
                <option value="Corporate">Corporate</option>
              </Select>
            </FormControl>
            <FormControl>
              <FormLabel>Organization Name</FormLabel>
              <Select
                name="orgName"
                value={formData.orgName}
                onChange={handleChange}
                isDisabled={!formData.orgType}
              >
                <option value="">Select Organization Name</option>
                {orgNames.map((name) => (
                  <option key={name[0]} value={name[0]}>
                    {name[1]}
                  </option>
                ))}
              </Select>
            </FormControl>
            <FormControl>
              <FormLabel>Organization Sub-Type</FormLabel>
              <Select
                name="orgSubType"
                value={formData.orgSubType}
                onChange={handleChange}
                isDisabled={!formData.orgType}
              >
                <option value="">Select Organization Sub-Type</option>
                {orgSubTypes.map((subtype) => (
                  <option key={subtype[0]} value={subtype[0]}>
                    {subtype[1]}
                  </option>
                ))}
              </Select>
            </FormControl>
            <FormControl>
              <FormLabel>Location Type</FormLabel>
              <Select
                name="locationType"
                value={formData.locationType}
                onChange={handleChange}
                isDisabled={!formData.orgName}
              >
                <option value="">Select Location Type</option>
                {locationTypes.map((type) => (
                  <option key={type} value={type}>
                    {type}
                  </option>
                ))}
              </Select>
            </FormControl>
            <FormControl>
              <FormLabel>Location Name</FormLabel>
              <Select
                name="locationName"
                value={formData.locationName}
                onChange={handleChange}
                isDisabled={!formData.locationType}
              >
                <option value="">Select Location Name</option>
                {locationNames.map((name) => (
                  <option key={name[0]} value={name[0]}>
                    {name[1]}
                  </option>
                ))}
              </Select>
            </FormControl>
            <FormControl>
              <FormLabel>Location Code</FormLabel>
              <Select
                name="locationCode"
                value={formData.locationCode}
                onChange={handleChange}
                isDisabled={!formData.locationType}
              >
                <option value="">Select Location Code</option>
                {locationCodes.map((code) => (
                  <option key={code[0]} value={code[0]}>
                    {code[1]}
                  </option>
                ))}
              </Select>
            </FormControl>
          </Box>
        )}

        {step === 3 && (
          <Box>
            <Text fontSize="2xl" fontWeight="semibold" mb={4}>
              Step 3: Account Information
            </Text>
            <FormControl>
              <FormLabel>Username</FormLabel>
              <Input
                type="text"
                name="username"
                value={formData.username}
                onChange={handleChange}
              />
            </FormControl>
            <FormControl>
              <FormLabel>Password</FormLabel>
              <Input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
              />
            </FormControl>
            <FormControl>
              <FormLabel>Confirm Password</FormLabel>
              <Input
                type="password"
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleChange}
              />
            </FormControl>
          </Box>
        )}

        <Stack direction="row" spacing={4} justify="flex-end">
          {step > 1 && (
            <Button colorScheme="gray" onClick={handlePrev}>
              Previous
            </Button>
          )}
          {step < 3 ? (
            <Button colorScheme="blue" onClick={handleNext}>
              Next
            </Button>
          ) : (
            <Button colorScheme="green" onClick={handleSubmit}>
              Submit
            </Button>
          )}
        </Stack>
      </Stack>
    </Box>
  );
};

export default RegistrationForm;
--------------------------------------------
import { ChakraProvider, Container, Heading } from '@chakra-ui/react';
import RegistrationForm from '../components/RegistrationForm';

export default function Home() {
  return (
    <ChakraProvider>
      <Container maxW="xl" centerContent>
        <Heading as="h1" size="xl" my={8}>
          User Registration
        </Heading>
        <RegistrationForm />
      </Container>
    </ChakraProvider>
  );
}
---------------------------------------
import React, { useState, useEffect } from 'react';
import Stepper from './Stepper'; // Adjust the import path as per your actual Stepper component
import { useForm } from 'react-hook-form';
import api from '../api'; // Adjust the import path for your API calls

const StepperForm = () => {
    const [currentStep, setCurrentStep] = useState(0);
    const [orgNames, setOrgNames] = useState([]);
    const [orgSubTypes, setOrgSubTypes] = useState([]);
    const [locationTypes, setLocationTypes] = useState([]);
    const [locationNamesAndCodes, setLocationNamesAndCodes] = useState([]);
    const { register, handleSubmit, watch, formState: { errors } } = useForm();

    const orgType = watch('org_type');
    const orgName = watch('org_name');
    const locationType = watch('location_type');

    useEffect(() => {
        if (orgType) {
            api.registration.getOrgNames(orgType).then(data => setOrgNames(data));
            api.registration.getOrgSubTypes(orgType).then(data => setOrgSubTypes(data));
        }
    }, [orgType]);

    useEffect(() => {
        if (orgName) {
            api.registration.getLocationTypes(orgName).then(data => setLocationTypes(data));
        }
    }, [orgName]);

    useEffect(() => {
        if (orgName && locationType) {
            api.registration.getLocationNamesAndCodes(orgName, locationType).then(data => setLocationNamesAndCodes(data));
        }
    }, [orgName, locationType]);

    const onSubmit = data => {
        api.registration.register(data).then(response => {
            // Handle successful registration
        }).catch(error => {
            // Handle errors
        });
    };

    const steps = [
        {
            title: 'Step 1',
            content: (
                <>
                    <label>First Name</label>
                    <input {...register('first_name', { required: true })} className="input" />
                    {errors.first_name && <span>This field is required</span>}

                    <label>Last Name</label>
                    <input {...register('last_name', { required: true })} className="input" />
                    {errors.last_name && <span>This field is required</span>}

                    <label>Org Type</label>
                    <select {...register('org_type', { required: true })} className="input">
                        {Object.keys(OrgType).map(key => (
                            <option key={key} value={OrgType[key]}>{OrgType[key]}</option>
                        ))}
                    </select>
                    {errors.org_type && <span>This field is required</span>}

                    <label>Org Name</label>
                    <select {...register('org_name', { required: true })} className="input">
                        {orgNames.map(org => (
                            <option key={org.id} value={org.name}>{org.name}</option>
                        ))}
                    </select>
                    {errors.org_name && <span>This field is required</span>}
                </>
            ),
        },
        {
            title: 'Step 2',
            content: (
                <>
                    <label>Org Sub Type</label>
                    <select {...register('org_sub_type', { required: true })} className="input">
                        {orgSubTypes.map(subType => (
                            <option key={subType.id} value={subType.subtype}>{subType.subtype}</option>
                        ))}
                    </select>
                    {errors.org_sub_type && <span>This field is required</span>}

                    <label>Location Type</label>
                    <select {...register('location_type', { required: true })} className="input">
                        {locationTypes.map(type => (
                            <option key={type} value={type}>{type}</option>
                        ))}
                    </select>
                    {errors.location_type && <span>This field is required</span>}

                    <label>Location Name</label>
                    <select {...register('location_name', { required: true })} className="input">
                        {locationNamesAndCodes.names.map(location => (
                            <option key={location.id} value={location.location_name}>{location.location_name}</option>
                        ))}
                    </select>
                    {errors.location_name && <span>This field is required</span>}

                    <label>Location Code</label>
                    <select {...register('location_code', { required: true })} className="input">
                        {locationNamesAndCodes.codes.map(location => (
                            <option key={location.id} value={location.location_code}>{location.location_code}</option>
                        ))}
                    </select>
                    {errors.location_code && <span>This field is required</span>}
                </>
            ),
        },
        {
            title: 'Step 3',
            content: (
                <>
                    <label>Department</label>
                    <select {...register('department', { required: true })} className="input">
                        {departments.map(dept => (
                            <option key={dept.id} value={dept.id}>{dept.name}</option>
                        ))}
                    </select>
                    {errors.department && <span>This field is required</span>}

                    <label>Designation</label>
                    <select {...register('designation', { required: true })} className="input">
                        {designations.map(designation => (
                            <option key={designation.id} value={designation.id}>{designation.name}</option>
                        ))}
                    </select>
                    {errors.designation && <span>This field is required</span>}

                    <label>Mobile</label>
                    <input {...register('mobile', { required: true })} className="input" />
                    {errors.mobile && <span>This field is required</span>}

                    <label>Username</label>
                    <input {...register('username', { required: true })} className="input" />
                    {errors.username && <span>This field is required</span>}

                    <label>Password</label>
                    <input type="password" {...register('password', { required: true })} className="input" />
                    {errors.password && <span>This field is required</span>}

                    <label>Confirm Password</label>
                    <input type="password" {...register('confirm_password', { required: true })} className="input" />
                    {errors.confirm_password && <span>This field is required</span>}

                    <button type="submit" className="btn">Register</button>
                </>
            ),
        },
    ];

    return (
        <form onSubmit={handleSubmit(onSubmit)} className="stepper-form">
            <Stepper steps={steps} currentStep={currentStep} onStepChange={setCurrentStep} />
        </form>
    );
};

export default StepperForm;


import axios from 'axios';

const API_BASE_URL = process.env.API_BASE_URL || "";

const api = axios.create({
    baseURL: API_BASE_URL,
});

export const organizationAPI = {
    orgNames: async (orgType) => {
        const response = await api.get(`/api/org-names?orgType=${orgType}`);
        return response.data;
    },
    orgSubTypes: async (orgType) => {
        const response = await api.get(`/api/org-sub-types?orgType=${orgType}`);
        return response.data;
    },
    locationTypes: async (orgName) => {
        const response = await api.get(`/api/location-types?orgName=${orgName}`);
        return response.data;
    },
    locationNamesAndCodes: async (orgName, locationType) => {
        const response = await api.get(`/api/location-names-and-codes?orgName=${orgName}&locationType=${locationType}`);
        return response.data;
    },
    register: async (data) => {
        const response = await api.post('/api/register', data);
        return response.data;
    },
};

export default api;
