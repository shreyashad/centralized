import { MyBreadCrumb } from "@/components/dashboard/mybreadcrumb";
import UserClient from "@/components/dashboard/user-management/client";


const UserManagement = () => {
    return (
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
      <MyBreadCrumb
        homelink="administrator/dashboard"
        hometitle="Dashboard"
        mdipagelink="administrator/user-management/"
        mdipagetitle="User Management"
        pagetitle="Users"
      />
      <UserClient/>
    </div>
    );
};

export default UserManagement;