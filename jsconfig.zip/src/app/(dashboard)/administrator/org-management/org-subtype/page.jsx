import { MyBreadCrumb } from "@/components/dashboard/mybreadcrumb";
import OrganizationSubTypeClient from "@/components/dashboard/org_subtype/client";

const OrgSubTypes = () => {
    return (
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <MyBreadCrumb
            homelink="administrator/dashboard"
            hometitle="Dashboard"
            mdipagelink="administrator/org-management/"
            mdipagetitle="Organization Management"
            pagetitle="Organization-SubType"
        />
        <OrganizationSubTypeClient/>
        </div>
    );
};

export default OrgSubTypes;
