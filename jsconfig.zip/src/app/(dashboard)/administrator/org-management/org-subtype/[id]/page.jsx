"use client";

import api from "@/utils/backendapi";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";

const OrgSubType = () => {
    const router = useRouter();
    const [id, setId] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [orgSubType, setOrgSubType ] = useState(null);

    useEffect(() => {
        const fetchOrgSubType = async () => {
            if (id) {
                setIsLoading(true);
                try {
                    const data = await api.
                }
            }
        }
    })
}