"use client";
import { Loading } from "@/components/dashboard/loading";
import { OrganizationForm } from "@/components/dashboard/organization/org-form";
import api from "@/utils/backendapi";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";


const Organization = () => {
    const router = useRouter();
    const [id, setId] = useState(null);
    const [organization, setOrganization] = useState(null);
    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        const fetchOrganization = async () => {
            if (id) {
                setIsLoading(true);
                try{
                    const data = await api.organization.detail(id);
                    setOrganization(data);
                } catch (error) {
                    console.error("Error fetching organization details:", error);
                }
                setIsLoading(false);
            }
        };
        fetchOrganization();
    }, [id]);


    
    if (isLoading) {
        return <Loading />;
    }

    return (
        <div className="flex flex-col">
            <div className="flex-1 space-y-4 p-4 md:p-8">
                <OrganizationForm initialData={organization} />
            </div>
        </div>
    );
};

export default Organization;