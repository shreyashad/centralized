import { MyBreadCrumb } from "@/components/dashboard/mybreadcrumb";


const Departments = () => {
    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <MyBreadCrumb 
                homelink="administrator/dashboard" 
                hometitle="Dashboard" 
                mdipagelink="administrator/org-management/" 
                mdipagetitle="Organization Management" 
                pagetitle="Department"
            />
        </div>
    );
};
export default Departments;