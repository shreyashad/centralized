"use client";
import LocationClient from "@/components/dashboard/locations/client";
import { MyBreadCrumb } from "@/components/dashboard/mybreadcrumb";
import { useRouter } from "next/navigation";


const Locations = () => {
    const router = useRouter();
    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <MyBreadCrumb
                homelink="administrator/dashboard"
                hometitle="Dashboard"
                mdipagelink="administrator/org-management/"
                mdipagetitle="Organization Management"
                pagetitle="Locations"
            />
           <LocationClient/>
        </div>
    );
};
export default Locations;