import { Overview } from "@/components/charts/overview";
import { MyCalendar } from "@/components/dashboard/mycalendar";
import StatsCard from "@/components/dashboard/stats-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import api from "@/utils/backendapi";
import { UserRoundCog } from "lucide-react";



export default async function AdministratorDashboard(){
    
    const totalUser = await api.administratorDashboar.totaluser();
    const activeUser = await api.administratorDashboar.activeuser();
    const verificationPending = await api.administratorDashboar.penddingverification();
    const apps = await api.administratorDashboar.totalapp();

    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <div className="grid gap-4 md:grid-cols-2 md:gap-8 lg:grid-cols-4">
                <StatsCard title="Total Users" value={totalUser.total_user} description="Total number of user that are been registered" icon={ <UserRoundCog />} />
                <StatsCard title="Active Users" value={activeUser.active_user} description="Total number of Active user" icon={<UserRoundCog /> } />
                <StatsCard title="Total Applications" value={apps.apps_count} description="Total number of application been registered" icon={ <UserRoundCog /> }/>
                <StatsCard title="Pending Verifications" value={verificationPending.verification_pending} description="Total number of user pending for verifications" icon={ <UserRoundCog /> } />
            
            </div>
            <div className="grid gap-4 md:grid-cols-2 md:gap-8 lg:grid-cols-10">
                <Card className="col-span-4">
                  <CardHeader>
                    <CardTitle>Overview</CardTitle>
                  </CardHeader>
                  <CardContent className="pl-2">
                   
                  </CardContent>
                </Card>
                <Card className="col-span-3">

                </Card>
                <Card  className="col-span-3 item-center" >
                    <MyCalendar className="w-full" />

                </Card>
            </div>
        
        </div>
    );
}

