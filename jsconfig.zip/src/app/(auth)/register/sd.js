import React, { useState } from 'react';
import axios from 'axios';

const RegistrationForm = () => {
    const [formData, setFormData] = useState({
        first_name: '',
        last_name: '',
        org_type: '',
        org_name: '',
        org_sub_type: '',
        location_type: '',
        location_name: '',
        location_code: '',
        emp_code: '',
        department: '',
        designation: '',
        mobile: '',
        username: '',
        password: '',
        confirm_password: '',
    });

    const [currentStep, setCurrentStep] = useState(1);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (currentStep === 3) {
            try {
                const response = await axios.post('/api/register/', formData);
                console.log(response.data);
                // handle successful registration, e.g., redirect to login page
            } catch (error) {
                console.error(error.response.data);
                // handle error
            }
        } else {
            setCurrentStep(currentStep + 1);
        }
    };

    const renderStep = (step) => {
        switch (step) {
            case 1:
                return (
                    <div>
                        <h2>Step 1</h2>
                        <label htmlFor="first_name">First Name</label>
                        <input
                            type="text"
                            id="first_name"
                            name="first_name"
                            value={formData.first_name}
                            onChange={handleChange}
                        />
                        {/* Add other fields for Step 1 */}
                    </div>
                );
            case 2:
                return (
                    <div>
                        <h2>Step 2</h2>
                        <label htmlFor="org_type">Org Type</label>
                        <input
                            type="text"
                            id="org_type"
                            name="org_type"
                            value={formData.org_type}
                            onChange={handleChange}
                        />
                        {/* Add other fields for Step 2 */}
                    </div>
                );
            case 3:
                return (
                    <div>
                        <h2>Step 3</h2>
                        <label htmlFor="username">Username</label>
                        <input
                            type="text"
                            id="username"
                            name="username"
                            value={formData.username}
                            onChange={handleChange}
                        />
                        {/* Add other fields for Step 3 */}
                    </div>
                );
            default:
                return null;
        }
    };

    return (
        <div>
            <form onSubmit={handleSubmit}>
                {renderStep(currentStep)}
                {currentStep !== 1 && (
                    <button type="button" onClick={() => setCurrentStep(currentStep - 1)}>
                        Previous
                    </button>
                )}
                <button type="submit">{currentStep === 3 ? 'Submit' : 'Next'}</button>
            </form>
        </div>
    );
};

export default RegistrationForm;
