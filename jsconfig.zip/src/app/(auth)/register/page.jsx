const { default: RegistrationStepperForm } = require("@/components/forms/registration-form");


const Registration = () => {
    return(
        <>
            <RegistrationStepperForm />
        </>
    );
}
export default Registration;