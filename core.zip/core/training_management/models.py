from django.db import models
from accounts.models import BaseModel, UserProfile
from common.models import Departments
from course.models import Course
# Create your models here.


class TrainingMode(models.TextChoices):
    ONLINE = 'Online', 'Online'
    CLASSROOM = 'Classroom', 'Classroom'
    SELF_LEARNING = 'Self-learning', 'Self-learning'


class StatusChoices(models.TextChoices):
    PENDING = 'Pending', 'Pending'
    APPROVED = 'Approved', 'Approved'
    REJECTED = 'Rejected', 'Rejected'


class TrainingRooms(BaseModel):
    name = models.CharField(max_length=100, unique=True)
    capacity = models.PositiveIntegerField()
    is_booked = models.BooleanField(default=False)

    def __str__(self):
        return self.name


class RoomAvailability(models.Model):
    room = models.ForeignKey(TrainingRooms, on_delete=models.CASCADE)
    date = models.DateField()
    is_available = models.BooleanField(default=True)
    description = models.TextField()

    def __str__(self):
        status = "Available" if self.is_available else "Not Available"
        return f"{self.room} - {self.date} - {status}"



class TrainingRequest(BaseModel):
    hod = models.ForeignKey(UserProfile, on_delete=models.CASCADE, related_name='training_requests')
    department = models.ForeignKey(Departments, on_delete=models.CASCADE)
    subject = models.CharField(max_length=200)
    training_type = models.CharField(max_length=20, choices=TrainingMode)
    requested_program = models.ForeignKey(Course, on_delete=models.CASCADE)
    description = models.TextField()
    status = models.CharField(max_length=10, choices=StatusChoices, default='PENDING')
    is_read = models.BooleanField(default=False)


class TrainingScheduling(models.Model):
    training_request = models.OneToOneField(TrainingRequest, on_delete=models.CASCADE, related_name='training_scheduling')
    room = models.ForeignKey(TrainingRooms, on_delete=models.CASCADE, blank=True, null=True)
    trainer = models.ForeignKey(UserProfile, on_delete=models.CASCADE)
    start_date_time = models.DateTimeField()
    end_date_time = models.DateTimeField()
    agenda = models.TextField()
    is_online = models.BooleanField(default=False)  # to distinguish between online and classroom

    def save(self, *args, **kwargs):
        if self.room:
            RoomAvailability.objects.filter(room=self.room, date=self.start_date_time.date()).update(is_available=False)
            self.room.is_booked = True
            self.room.save()
        self.trainer.profile.is_booked = True
        self.trainer.profile.save()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Scheduled Training for {self.training_request.subject} on {self.start_date_time}"

class TrainingResponse(BaseModel):
    request = models.OneToOneField(TrainingRequest, on_delete=models.CASCADE, related_name='response')
    trainer = models.ForeignKey(UserProfile, on_delete=models.CASCADE, related_name='training_responses')
    scheduled_time = models.DateTimeField()
    message = models.TextField()
    is_read = models.BooleanField(default=False)
