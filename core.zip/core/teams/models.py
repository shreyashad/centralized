import arrow
from django.db import models
from accounts.models import UserProfile, BaseModel


class Team(BaseModel):
    name = models.CharField(max_length=100)
    description = models.TextField()
    users = models.ManyToManyField(UserProfile, related_name="teams")

    class Meta:
        verbose_name = "Team"
        verbose_name_plural = "Teams"
        db_table = "teams"
        ordering = ("-created_at",)

    def __str__(self):
        return self.name

    @property
    def created_on_arrow(self):
        return arrow.get(self.created_at).humanize()

    def get_users(self):
        return ", ".join(map(str, self.users.values_list("id", flat=True)))
