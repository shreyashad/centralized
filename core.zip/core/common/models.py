from django.db import models
from accounts.models import BaseModel
# Create your models here.

class Branches(BaseModel):
    name = models.CharField(max_length=255, unique=True)

    class Meta:
        verbose_name = "Branch"
        verbose_name_plural = "Branches"
        db_table = "branches"
        ordering = ("-created_at",)

    def __str__(self):
        return self.name

class Departments(BaseModel):
    name = models.CharField(max_length=255, unique=True)

    class Meta:
        verbose_name = "Department"
        verbose_name_plural = "Departments"
        db_table = "department"
        ordering = ("-created_at",)

    def __str__(self):
        return self.name


class Designation(BaseModel):
    name = models.CharField(max_length=255, unique=True)

    class Meta:
        verbose_name = "Designation"
        verbose_name_plural = "Designations"
        db_table = "designation"
        ordering = ("-created_at",)

    def __str__(self):
        return self.name


class ToDaysWisdom(BaseModel):
    topic = models.TextField()

    class Meta:
        verbose_name = "Today's Wisdom"
        verbose_name_plural = "Today's Wisdoms"
        db_table = "today's_wisdom"
        ordering = ("-created_at",)

    def __str__(self):
        return self.topic
