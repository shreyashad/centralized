from django.urls import path
from . import views


urlpatterns = [
    path('branches/', views.BrachesListView.as_view(), name='branches_list'),
    path('branches/create/', views.BranchesCreateView.as_view(), name='branches_create'),
    path('branches/<int:pk>/', views.BranchDetailView.as_view(), name='branch_detail'),
    path('departments/', views.DepartmentListView.as_view(), name='departments_list'),
    path('departments/create/', views.DepartmentsCreateView.as_view(), name='departments_create'),
    path('departments/<int:pk>/', views.DepartmentDetailView.as_view(), name='department_detail'),
    path('designations/', views.DesignationListView.as_view(), name='designations_list'),
    path('designations/create/', views.DesignationCreateView.as_view(), name='designations_create'),
    path('designations/<int:pk>/', views.DesignationDetailView.as_view(), name='designations_detail'),
    path('today-wisdoms/', views.TodayWisdomListView.as_view(), name='wisdom_list'),
    path('today-wisdoms/create/', views.TodayWisdomCreateView.as_view(), name='wisdom_create'),
    path('today-wisdoms/<int:pk>/', views.TodayWisdomDetailView.as_view(), name='wisdom_detail'),
    path('latest-todays-wisdom/', views.LatestTodaysWisdomView.as_view(), name='latest-todays-wisdom'),
]