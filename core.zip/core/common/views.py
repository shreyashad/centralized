from django.shortcuts import render
from rest_framework import status, generics
from rest_framework.views import APIView
from rest_framework.response import Response
from common.models import *
from common.serializers import *
from django.utils import timezone
# Create your views here.

# for Branch related views


class BranchesListView(APIView):
    def get(self, request, *args, **kwargs):
        branches = Branches.objects.all()
        branch_data = BranchesSerializer(branches, many=True)
        return Response(branch_data)


class BranchesCreateView(APIView):
    model = Branches
    serializer_class = BranchesSerializer

    def post(self, request, format=None):
        data = request.data
        serializer = self.serializer_class(data=data)
        if serializer.is_valid():
            branch_obj = serializer.save()
            return Response(
                {
                    "error": False,
                    "message": "New branch is created,",
                    "branch": self.serializer_class(branch_obj).data,
                    "status": status.HTTP_201_CREATED,
                }
            )
        else:
            return Response(
                {
                    "error": True,
                    "errors": serializer.errors,
                    "status": status.HTTP_400_BAD_REQUEST,
                }
            )

class BranchDetailView(APIView):
    #permission_classes = (IsAuthenticated,)

    def get_object(self,pk):
        return Branches.object.filter(id=pk).first()

    def get(self, request, pk, format=None):
        self.object = self.get_object(pk)
        if not self.object:
            return Response(
                {
                    "error": True,
                    "errors": "Branch does not exist",
                    "status": status.HTTP_403_FORBIDDEN
                }

            )
        if self.request.userprofile.role != "ADMINISTRATOR" and not self.request.user.is_superuser:
            if not (
                    (self.request.user == self.object.created_by)

            ):
                return Response(
                    {
                        "error": True,
                        "errors": "You don not have Permission to perform this action",
                    },
                    status= status.HTTP_403_FORBIDDEN,
                )


    def delete(self, request, pk, format=None):
        branch = self.get_object(pk)
        if not branch:
            return Response(
                {
                    "error": True,
                    "errors": "Branch does not exist"
,
                },
                status=status.HTTP_403_FORBIDDEN,

            )
        branch.delete()
        return Response(
            {
                "error": False,
                "message": "Branch deleted Successfully"
            },
            status=status.HTTP_200_OK,
        )

    def put(self, request, pk, format=None):
        self.object = self.get_object(pk)
        params = request.data
        if not self.object:
            return Response(
                {
                    "error": True,
                    "errors": "Branch does not exist"
                },
                status=status.HTTP_403_FORBIDDEN,
            )
        serializer = BranchesSerializer()
        if serializer.is_valid():
            branch = serializer.save()
            return Response(
                {
                    "error": False,
                    "message": "Brach Updated Successfully"
                },
                status=status.HTTP_200_OK
            )
        return Response(
            {"error": True, "errors": serializer.errors},
            status=status.HTTP_400_BAD_REQUEST,
        )


# for Department related
class DepartmentListView(APIView):
    def get(self, request, *args, **kwargs):
        data = {}
        departments = Departments.objects.all()
        departments_data = DepartmentSerializer(departments, many=True).data
        return Response(data)


class DepartmentsCreateView(APIView):
    model = Departments
    serializer_class = DepartmentSerializer

    def post(self, request, format=None):
        data = request.data
        serializer = self.serializer_class(data=data)
        if serializer.is_valid():
            department_oj = serializer.save()
            return Response(
                {
                    "error": False,
                    "message": "New department is created,",
                    "department": self.serializer_class(department_oj).data,
                    "status": status.HTTP_201_CREATED,
                }
            )
        else:
            return Response(
                {
                    "error": True,
                    "errors": serializer.errors,
                    "status": status.HTTP_400_BAD_REQUEST,
                }
            )


class DepartmentDetailView(APIView):
    # permission_classes = (IsAuthenticated,)
    def get_object(self,pk):
        return Departments.objects.filter(id=pk).first()

    def get(self, request, pk, format=None):
        self.object = self.get_object(pk)
        if not self.object:
            return Response(
                {
                    "error": True,
                    "errors": "Department does not exist",
                    "status": status.HTTP_403_FORBIDDEN
                }
            )
        if self.request.userprofile.role != "ADMINISTRATOR" and not self.request.user.is_superuser:
            if not (
                    (self.request.user == self.object.created_by)
            ):
                return Response(
                    {
                        "error": True,
                        "errors": "You don't not have Permission to perform this action",
                    },
                    status= status.HTTP_403_FORBIDDEN,
                )

    def delete(self, request, pk, format=None):
        department = self.get_object(pk)
        if not department:
            return Response(
                {
                    "error": True,
                    "errors": "Department does not exist"
                },
                status=status.HTTP_403_FORBIDDEN,
            )
        department.delete()
        return Response(
            {
                "error": False,
                "message": "Department deleted Successfully"
            },
            status=status.HTTP_200_OK
        )

    def put(self, request, pk, format=None):
        self.object = self.get_object(pk)
        params = request.data
        if not self.object:
            return Response(
                {
                    "error":True,
                    "errors": "Department dose not exist"
                },
                status=status.HTTP_403_FORBIDDEN,
            )
        serializer = DepartmentSerializer()
        if serializer.is_valid():
            department = serializer.save()
            return Response(
                {
                    "error": False,
                    "message": "Department Updated Successfully"
                },
                status=status.HTTP_200_OK
            )
            return Response(
                {"error": True, "errors": serializer.errors},
                status=status.HTTP_400_BAD_REQUEST,
            )


# for Designation related
class DesignationListView(APIView):

    def get(self, request, *args, **kwargs):
        data = {}
        designation = Designation.objects.all()
        designation_data = DesignationSerializer(designation, many=True).data
        return Response(data)



class DesignationCreateView(APIView):
    #permission_classes = (IsAuthenticated)
    model = Designation
    serializer_class = DesignationSerializer

    def post(self, request, format=None):
        data = request.data
        serializer = self.serializer_class(data=data)
        if serializer.is_valid():
            designation_obj = serializer.save()
            return Response(
                {
                    "error": False,
                    "message": "New designation is created,",
                    "branch": self.serializer_class(designation_obj).data,
                    "status": status.HTTP_201_CREATED,
                }
            )
        else:
            return Response(
                {
                    "error": True,
                    "errors": serializer.errors,
                    "status": status.HTTP_400_BAD_REQUEST,
                }
            )


class DesignationDetailView(APIView):
    #permission_classes = (IsAuthenticated,)

    def get_object(self,pk):
        return Designation.object.filter(id=pk).first()

    def get(self, request, pk, format=None):
        self.object = self.get_object(pk)
        if not self.object:
            return Response(
                {
                    "error": True,
                    "errors": "Designation does not exist",
                    "status": status.HTTP_403_FORBIDDEN
                }

            )
        if self.request.userprofile.role != "ADMINISTRATOR" and not self.request.user.is_superuser:
            if not (
                    (self.request.user == self.object.created_by)

            ):
                return Response(
                    {
                        "error": True,
                        "errors": "You don not have Permission to perform this action",
                    },
                    status= status.HTTP_403_FORBIDDEN,
                )


    def delete(self, request, pk, format=None):
        designation = self.get_object(pk)
        if not designation:
            return Response(
                {
                    "error": True,
                    "errors": "Designation does not exist",

                },
                status=status.HTTP_403_FORBIDDEN,

            )
        designation.delete()
        return Response(
            {
                "error": False,
                "message": "Designation deleted Successfully"
            },
            status=status.HTTP_200_OK,
        )

    def put(self, request, pk, format=None):
        self.object = self.get_object(pk)
        params = request.data
        if not self.object:
            return Response(
                {
                    "error": True,
                    "errors": "Designation does not exist"
                },
                status=status.HTTP_403_FORBIDDEN,
            )
        serializer = DesignationSerializer()
        if serializer.is_valid():
            designation = serializer.save()
            return Response(
                {
                    "error": False,
                    "message": "Designation Updated Successfully"
                },
                status=status.HTTP_200_OK
            )
        return Response(
            {"error": True, "errors": serializer.errors},
            status=status.HTTP_400_BAD_REQUEST,
        )


# for today's wisdom related
class TodayWisdomListView(APIView):
    def get(self, request, *args, **kwargs):
        data = {}
        wisdom = ToDaysWisdom.objects.all()
        wisdom_data = TodaysWisdomSerializer(wisdom, many=True).data
        return Response(data)


class TodayWisdomCreateView(APIView):
    #permission_classes = (IsAuthenticated)
    model = ToDaysWisdom
    serializer_class = TodaysWisdomSerializer

    def post(self, request, format=None):
        data = request.data
        serializer = self.serializer_class(data=data)
        if serializer.is_valid():
            wisdom_obj = serializer.save()
            return Response(
                {
                    "error": False,
                    "message": "New wisdom is created,",
                    "branch": self.serializer_class(wisdom_obj).data,
                    "status": status.HTTP_201_CREATED,
                }
            )
        else:
            return Response(
                {
                    "error": True,
                    "errors": serializer.errors,
                    "status": status.HTTP_400_BAD_REQUEST,
                }
            )


class TodayWisdomDetailView(APIView):
    #permission_classes = (IsAuthenticated,)

    def get_object(self,pk):
        return ToDaysWisdom.object.filter(id=pk).first()

    def get(self, request, pk, format=None):
        self.object = self.get_object(pk)
        if not self.object:
            return Response(
                {
                    "error": True,
                    "errors": "wisdom does not exist",
                    "status": status.HTTP_403_FORBIDDEN
                }

            )
        if self.request.userprofile.role != "ADMINISTRATOR" and not self.request.user.is_superuser:
            if not (
                    (self.request.user == self.object.created_by)

            ):
                return Response(
                    {
                        "error": True,
                        "errors": "You don not have Permission to perform this action",
                    },
                    status= status.HTTP_403_FORBIDDEN,
                )


    def delete(self, request, pk, format=None):
        wisdom = self.get_object(pk)
        if not wisdom:
            return Response(
                {
                    "error": True,
                    "errors": "Wisdom does not exist"
,
                },
                status=status.HTTP_403_FORBIDDEN,

            )
        wisdom.delete()
        return Response(
            {
                "error": False,
                "message": "Wisdom deleted Successfully"
            },
            status=status.HTTP_200_OK,
        )

    def put(self, request, pk, format=None):
        self.object = self.get_object(pk)
        params = request.data
        if not self.object:
            return Response(
                {
                    "error": True,
                    "errors": "Wisdom does not exist"
                },
                status=status.HTTP_403_FORBIDDEN,
            )
        serializer = TodaysWisdomSerializer()
        if serializer.is_valid():
            wisdom = serializer.save()
            return Response(
                {
                    "error": False,
                    "message": "Wisdom Updated Successfully"
                },
                status=status.HTTP_200_OK
            )
        return Response(
            {"error": True, "errors": serializer.errors},
            status=status.HTTP_400_BAD_REQUEST,
        )


class LatestTodaysWisdomView(APIView):
    #permission_classes = [IsAuthenticated]

    def get(self, request, *args, **kwargs):
        today = timezone.now().date()
        latest_wisdom = ToDaysWisdom.objects.filter(created_at__date=today).order_by('-created_at').first()
        if latest_wisdom:
            serializer = TodaysWisdomSerializer(latest_wisdom)
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response({"detail": "No wisdom found for today."}, status=status.HTTP_404_NOT_FOUND)
