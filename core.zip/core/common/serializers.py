from rest_framework import serializers
from common.models import *


class BranchesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Branches
        fields = "__all__"


class DepartmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Departments
        fields = "__all__"


class DesignationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Designation
        fields = "__all__"


class TodaysWisdomSerializer(serializers.ModelSerializer):
    class Meta:
        model = ToDaysWisdom
        fields = "__all__"

