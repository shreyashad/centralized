import uuid
from django.db import models
from django.contrib.auth.models import AbstractBaseUser,PermissionsMixin
from accounts.manager import CustomUserManager
from phonenumber_field.modelfields import PhoneNumberField

# Create your models here.


def user_directory_path(instance, filename):
    return f'user_{instance.user.id}/{filename}'


class GenderChoice(models.TextChoices):
    MALE = 'Male', 'Male'
    FEMALE = 'Female', 'Female'
    OTHERS = 'Others', 'Others'


class CustomUser(AbstractBaseUser,PermissionsMixin):
    id = models.UUIDField(default=uuid.uuid4, unique=True, editable=False, db_index=True, primary_key=True)
    first_name = models.CharField(max_length=150)
    last_name = models.CharField(max_length=150)
    username = models.CharField(max_length=150, unique=True)
    branch = models.CharField(max_length=150, null=True)
    department = models.CharField(max_length=150, null=True)
    designation = models.CharField(max_length=150, null=True)
    emp_id = models.CharField(max_length=15, unique=True)
    mobile = PhoneNumberField(null=True, unique=True)
    is_superuser = models.BooleanField(default=False)
    is_staff = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    is_verified = models.BooleanField(default=False)
    is_online = models.BooleanField(default=False)

    USERNAME_FIELD = "username"
    REQUIRED_FIELDS = []

    objects = CustomUserManager()

    class Meta:
        verbose_name = "CustomUser"
        verbose_name_plural = "CustomUsers"
        db_table = "custom_user"
        ordering = ("-is_active",)

    def __str__(self):
        return self.username

    def get_full_name(self):
        return f"{self.first_name}{self.last_name}"


class BaseModel(models.Model):
    id = models.UUIDField(default=uuid.uuid4, unique=True,editable=False,db_index=True, primary_key=True)
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="created at")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="last modified at")
    created_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, related_name="%(class)s_created_by",
                                   verbose_name="created by", null=True)
    updated_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, related_name="%(class)s_updated_by",
                                   verbose_name="last modified by", null=True)

    class Meta:
        abstract = True

    def save(self, *args, **kwargs):
        if not self.id:
            user = kwargs.pop('user', None)
            self.created_by = user
        self.updated_by = kwargs.pop('user', None)
        super(BaseModel, self).save(*args, **kwargs)

    def __str__(self):
        return str(self.id)


class Roles(BaseModel):
    name = models.CharField(max_length=250, unique=True)
    description = models.TextField(blank=True)

    def __str__(self):
        return self.name


class Permission(BaseModel):
    codename = models.CharField(max_length=150)
    name = models.CharField(max_length=255)
    role = models.ForeignKey(Roles, related_name='permissions', on_delete=models.CASCADE)


    def __str__(self):
        return f"{self.role}" - {self.name}

    def assign_role_by_name(self, role_name):
        role = Roles.objects.get(name=role_name)
        self.roles.add(role)


class Skill(BaseModel):
    name = models.CharField(max_length=100, unique=True)

    class Meta:
        verbose_name = "Skill"
        verbose_name_plural = "Skills"
        db_table = "skill"
        ordering = ("-created_at",)

    def __str__(self):
        return self.name


class UserProfile(BaseModel):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE)
    date_of_birth = models.DateField(null=True, blank=True)
    gender = models.CharField(max_length=10, choices=GenderChoice,blank=True)
    join_date = models.DateTimeField(null=True, blank=True)
    email = models.EmailField(max_length=254, unique=True, null=True)
    bio = models.TextField(blank=True)
    address = models.TextField(blank=True)
    photo = models.ImageField(upload_to=user_directory_path, blank=True)
    skills = models.ManyToManyField(Skill, related_name='users', blank=True, )
    roles = models.ManyToManyField(Roles,related_name='users_roles', default="USER")

    class Meta:
        verbose_name = "Profile"
        verbose_name_plural = "Profiles"
        db_table = "profile"
        ordering = ("-created_at",)

    def __str__(self):
        return f" Profile of {self.user.username} "

    def get_photo_url(self):
        if self.photo:
            return self.photo.url
        else:
            return '/static/assets/img/avatars/default.png'  # Replace 'default_photo_url_name' with the actual URL name

    @property
    def get_user_skills(self):
        return self.skills.all()

    @property
    def user_details(self):
        return {
            'username': self.user.username,
            'id': self.user.id,
            'is_active': self.user.is_active,
            'is_verified': self.user.is_verified,
            'profile_pic': self.profile_pic,
            'roles': self.roles,
        }

    def has_role(self, role_name):
        return self.roles.filter(name=role_name).exists()

    def has_permission(self, perm_codename):
        return self.roles.filter(permissions__codename=perm_codename).exists()

    def assign_role_by_name(self, role_name):
        role = Roles.objects.get(name=role_name)
        self.roles.add(role)