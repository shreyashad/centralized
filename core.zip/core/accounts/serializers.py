from rest_framework import serializers
from accounts.models import *
from django.contrib.auth import authenticate
from django.db import IntegrityError
from django.contrib.auth.password_validation import validate_password
from common.models import *
from rest_framework_simplejwt.serializers import RefreshToken


class RolesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Roles
        fields = ["name", "description"]


class PermissionSerializer(serializers.ModelSerializer):
    role = RolesSerializer()

    class Meta:
        model = Permission
        fields = ["codename", "name", "role"]

class CustomUserSerializer(serializers.ModelSerializer):
    roles = serializers.SerializerMethodField()

    class Meta:
        model = CustomUser
        fields = [
            "id", "first_name", "last_name", "username", "branch", "department",
            "designation", "emp_id", "mobile", "is_superuser", "is_staff",
            "is_active", "is_verified", "is_online", "roles"
        ]
        read_only_fields = ["id"]

    def get_roles(self, obj):
        roles = obj.userprofile.roles.all()
        return RolesSerializer(roles, many=True).data


class CustomUserRegistrationSerializer(serializers.ModelSerializer):
    branch = serializers.SlugRelatedField(queryset=Branches.objects.all(), slug_field="name" )
    department = serializers.SlugRelatedField(queryset=Departments.objects.all(), slug_field='name')
    designation = serializers.SlugRelatedField(queryset=Designation.objects.all(), slug_field='name')
    password = serializers.CharField(write_only=True, required=True, validators=[validate_password])
    password_confirm = serializers.CharField(write_only=True, required=True)

    class Meta:
        model = CustomUser
        fields = ['first_name', 'last_name', 'username', 'password', 'password_confirm', 'branch', 'department',
                  'designation', 'emp_id',
                  'mobile']
        extra_kwargs = {
            'username': {'validators': []},
            'emp_id': {'validators': []},
            'mobile': {'validators': []},
        }

    def validate(self, data):
        if data['password'] != data['password_confirm']:
            raise serializers.ValidationError({"password": "Password fields didn't match."})

        if CustomUser.objects.filter(username=data['username']).exists():
            raise serializers.ValidationError({"username": "Username already exists."})

        # Ensure emp_id is unique
        if CustomUser.objects.filter(emp_id=data['emp_id']).exists():
            raise serializers.ValidationError({"emp_id": "Employee ID already exists."})

        # Validate mobile number (assumed to be a 10-digit number)
        if not (str(data['mobile']).isdigit() and len(str(data['mobile'])) == 10):
            raise serializers.ValidationError({'mobile': 'Mobile number should be a 10-digit number.'})

        return data

    def create(self, validated_data):
        branch_data = validated_data.pop('branch')
        department_data = validated_data.pop('department')
        designation_data = validated_data.pop('designation')
        branch, _ = Branches.objects.get_or_create(name=branch_data)
        department, _ = Departments.objects.get_or_create(name=department_data)
        designation, _ = Designation.objects.get_or_create(name=designation_data)

        validated_data.pop('password_confirm')  # Remove password_confirm as it's not needed for user creation
        try:
            user = CustomUser.objects.create_user(
                branch=branch,
                department=department,
                designation=designation,
                **validated_data
            )
        except IntegrityError:
            raise serializers.ValidationError({
                "detail": "Foreign key constraint failed. Please ensure the branch, department, and designation exist."

            })
        return user


class CustomTokenObtainPairSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField(write_only=True)

    def validate(self, attrs):
        username = attrs.get('username')
        password = attrs.get('password')

        user = authenticate(username=username, password=password)

        if not user:
            raise serializers.ValidationError('Invalid credentials')

        refresh = RefreshToken.for_user(user)

        return {
            'refresh': str(refresh),
            'access': str(refresh.access_token),
            'user': CustomUserSerializer(user).data,
            'status': 'authenticated'
        }

class UserProfileSerializer(serializers.ModelSerializer):
    roles = RolesSerializer(many=True)

    class Meta:
        model = UserProfile
        fields = ['date_of_birth', 'gender', 'join_date', 'email', 'bio', 'address', 'photo', 'skills', 'roles']