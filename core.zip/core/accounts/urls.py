from django.urls import path
from . import views

urlpatterns = [
    path('dropdown-options/', views.DropdownOptionsView.as_view(), name='dropdown-options'),
    path('register/', views.RegistrationView.as_view(), name='user-register'),
    path('token/', views.CustomTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('token/refresh/', views.TokenObtainPairView.as_view(), name='token_refresh'),
    path('session/', views.UserSessionView.as_view(), name='user_session'),
]
