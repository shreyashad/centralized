from django.shortcuts import render
from accounts.models import *
from rest_framework import generics, status
from rest_framework.views import APIView
from rest_framework.response import Response
from common.serializers import *
from accounts.serializers import *
from rest_framework_simplejwt.views import TokenObtainPairView
# Create your views here.


# for user login
class CustomTokenObtainPairView(TokenObtainPairView):
    serializer_class = CustomTokenObtainPairSerializer


class UserSessionView(APIView):
    def get(self, request):
        user = request.user
        profile = user.profile
        serializer = UserProfileSerializer(profile)
        return Response(serializer.data)


# for user registration

class DropdownOptionsView(APIView):
    def get(self, request):
        branches = Branches.objects.all()
        departments = Departments.objects.all()
        designations = Designation.objects.all()

        branch_serializer = BranchesSerializer(branches, many=True)
        department_serializer = DepartmentSerializer(departments, many=True)
        designation_serializer = DesignationSerializer(designations, many=True)

        return Response({
            'branchOptions': branch_serializer.data,
            'departmentOptions': department_serializer.data,
            'designationOptions': designation_serializer.data,
        })


class RegistrationView(generics.CreateAPIView):
    serializer_class = CustomUserRegistrationSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)
