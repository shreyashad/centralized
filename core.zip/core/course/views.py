from django.shortcuts import render
from course.serializers import *
from course.models import *
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import status
# Create your views here.

# for Course category related
class CourseCategoryListView(APIView):
    def get(self, request):
        categories = CourseCategory.objects.all()
        serializer = CourseCategorySerializer(categories, many=True)
        return Response(serializer.data)

class CourseCategoryCreateView(APIView):
    #permission_classes = (IsAuthenticated,)
    model = CourseCategory
    serializer_class = CourseCategorySerializer

    def post(self, request, format=None):
        data = request.data
        serializer = self.serializer_class(data=data)
        if serializer.is_valid():
            category_obj = serializer.save(created_by=request.user, updated_by=request.user)
            return Response(
                {
                    "error": False,
                    "message": "New category is created",
                    "category": self.serializer_class(category_obj).data,
                    "status": status.HTTP_201_CREATED,
                }
            )
        else:
            return Response(
                {
                    "error": True,
                    "errors": serializer.errors,
                    "status": status.HTTP_400_BAD_REQUEST,
                }
            )

class CourseCategoryDetailView(APIView):
    #permission_classes = (IsAuthenticated,)

    def get_object(self, pk):
        try:
            return CourseCategory.objects.get(pk=pk)
        except CourseCategory.DoesNotExist:
            return None



    def get(self, request, pk):
        category = self.get_object(pk)
        if not category:
            return Response(
                {
                    "error": True,
                    "errors": "Course Category Dose not exist",
                    "status": status.HTTP_403_FORBIDDEN
                }
            )
        if self.request.userprofile.roles != "ADMINISTRATOR"  and not self.request.userprofile.roles != "TRAINERS ADMIN"  and not self.request.user.is_superuser:
            if not (
                    (self.request.user == self.object.created_by)
            ):
                return Response(
                    {
                        "error": True,
                        "errors": "You don not have Permission to perform this action",
                    },
                    status=status.HTTP_403_FORBIDDEN,
                )



    def delete(self, request, pk, format=None):
        category = self.get_object(pk)
        if not category:
            return Response(
                {
                    "error": True,
                    "errors": "Course Category does not exist"
                    ,
                },
                status=status.HTTP_403_FORBIDDEN,

            )
        category.delete()
        return Response(
            {
                "error": False,
                "message": "Wisdom deleted Successfully"
            },
            status=status.HTTP_200_OK,
        )

    def put(self, request, pk, format=None):
        category = self.get_object(pk)
        params = request.data
        if not category:
            return Response(
                {
                    "error": True,
                    "errors": "Wisdom does not exist"
                },
                status=status.HTTP_404_NOT_FOUND,
            )
        serializer = CourseCategorySerializer(category, params)
        if serializer.is_valid():
            serializer.save(updated_by=request.user)
            return Response(
                {
                    "error": False,
                    "message": "Course Category Updated Successfully"
                },
                status=status.HTTP_200_OK
            )
        return Response(
            {"error": True, "errors": serializer.errors},
            status=status.HTTP_400_BAD_REQUEST,
        )


# for Course related

class CourseListView(APIView):
    def get(self, request):
        course = Course.objects.all()
        serializer = CourseCategorySerializer(course, many=True)
        return Response(serializer.data)

class CourseCreateView(APIView):
    #permission_classes = (IsAuthenticated,)
    model = Course
    serializer_class = CourseSerializer

    def post(self, request, format=None):
        data = request.data
        serializer = self.serializer_class(data=data)
        if serializer.is_valid():
            course_obj = serializer.save(created_by=request.user, updated_by=request.user)
            return Response(
                {
                    "error": False,
                    "message": "New course is created",
                    "course": self.serializer_class(course_obj).data,
                    "status": status.HTTP_201_CREATED,
                }
            )
        else:
            return Response(
                {
                    "error": True,
                    "errors": serializer.errors,
                    "status": status.HTTP_400_BAD_REQUEST,
                }
            )

class CourseCategoryDetailView(APIView):
    #permission_classes = (IsAuthenticated,)

    def get_object(self, pk):
        try:
            return Course.objects.get(pk=pk)
        except Course.DoesNotExist:
            return None



    def get(self, request, pk):
        course = self.get_object(pk)
        if not course:
            return Response(
                {
                    "error": True,
                    "errors": "Course Dose not exist",
                    "status": status.HTTP_403_FORBIDDEN
                }
            )
        if self.request.userprofile.roles != "ADMINISTRATOR" and not self.request.userprofile.roles != "TRAINERS ADMIN"  and not self.request.user.is_superuser:
            if not (
                    (self.request.user == self.object.created_by)
            ):
                return Response(
                    {
                        "error": True,
                        "errors": "You don not have Permission to perform this action",
                    },
                    status=status.HTTP_403_FORBIDDEN,
                )



    def delete(self, request, pk, format=None):
        course = self.get_object(pk)
        if not course:
            return Response(
                {
                    "error": True,
                    "errors": "Course does not exist"
                    ,
                },
                status=status.HTTP_403_FORBIDDEN,

            )
        course.delete()
        return Response(
            {
                "error": False,
                "message": "Course deleted Successfully"
            },
            status=status.HTTP_200_OK,
        )

    def put(self, request, pk, format=None):
        course = self.get_object(pk)
        params = request.data
        if not course:
            return Response(
                {
                    "error": True,
                    "errors": "Course does not exist"
                },
                status=status.HTTP_404_NOT_FOUND,
            )
        serializer = CourseSerializer(course, params)
        if serializer.is_valid():
            serializer.save(updated_by=request.user)
            return Response(
                {
                    "error": False,
                    "message": "Course Updated Successfully"
                },
                status=status.HTTP_200_OK
            )
        return Response(
            {"error": True, "errors": serializer.errors},
            status=status.HTTP_400_BAD_REQUEST,
        )


# for module related

class ModuleListView(APIView):
    def get(self, request):
        modules = Module.objects.all()
        serializer = ModuleSerializer(modules, many=True)
        return Response(serializer.data)

class ModuleCreateView(APIView):
    #permission_classes = (IsAuthenticated,)
    model = Module
    serializer_class = ModuleSerializer

    def post(self, request, format=None):
        data = request.data
        serializer = self.serializer_class(data=data)
        if serializer.is_valid():
            module_obj = serializer.save(created_by=request.user, updated_by=request.user)
            return Response(
                {
                    "error": False,
                    "message": "New module is created",
                    "category": self.serializer_class(module_obj).data,
                    "status": status.HTTP_201_CREATED,
                }
            )
        else:
            return Response(
                {
                    "error": True,
                    "errors": serializer.errors,
                    "status": status.HTTP_400_BAD_REQUEST,
                }
            )

class ModuleDetailView(APIView):
    #permission_classes = (IsAuthenticated,)

    def get_object(self, pk):
        try:
            return Module.objects.get(pk=pk)
        except Module.DoesNotExist:
            return None



    def get(self, request, pk):
        module = self.get_object(pk)
        if not module:
            return Response(
                {
                    "error": True,
                    "errors": "Module Dose not exist",
                    "status": status.HTTP_403_FORBIDDEN
                }
            )
        if self.request.userprofile.roles != "ADMINISTRATOR"  and not self.request.userprofile.roles != "TRAINERS ADMIN"  and not self.request.user.is_superuser:
            if not (
                    (self.request.user == self.object.created_by)
            ):
                return Response(
                    {
                        "error": True,
                        "errors": "You don not have Permission to perform this action",
                    },
                    status=status.HTTP_403_FORBIDDEN,
                )



    def delete(self, request, pk, format=None):
        module = self.get_object(pk)
        if not module:
            return Response(
                {
                    "error": True,
                    "errors": "Module does not exist"
                    ,
                },
                status=status.HTTP_403_FORBIDDEN,

            )
        module.delete()
        return Response(
            {
                "error": False,
                "message": "Module deleted Successfully"
            },
            status=status.HTTP_200_OK,
        )

    def put(self, request, pk, format=None):
        category = self.get_object(pk)
        params = request.data
        if not category:
            return Response(
                {
                    "error": True,
                    "errors": "Wisdom does not exist"
                },
                status=status.HTTP_404_NOT_FOUND,
            )
        serializer = CourseCategorySerializer(category, params)
        if serializer.is_valid():
            serializer.save(updated_by=request.user)
            return Response(
                {
                    "error": False,
                    "message": "Course Category Updated Successfully"
                },
                status=status.HTTP_200_OK
            )
        return Response(
            {"error": True, "errors": serializer.errors},
            status=status.HTTP_400_BAD_REQUEST,
        )
