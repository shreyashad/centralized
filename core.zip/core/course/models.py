from django.db import models
from accounts.models import BaseModel
from autoslug import AutoSlugField
from django.db.models import Sum
from django.core.validators import FileExtensionValidator
from django.utils.translation import gettext_lazy as _

# Create your models here.



class CourseStatus(models.TextChoices):
    INACTIVE = 'Inactive', 'Inactive'
    PUBLISHED = 'Published', 'Published'


class DifficultyLevel(models.TextChoices):
    BEGINNER = 'Beginner', 'Beginner'
    INTERMEDIATE = 'Intermediate', 'Intermediate'
    ADVANCE = 'Advanced', 'Advanced'
    EXPERT = 'Expert', 'Expert'
    FOUNDATION = 'Foundation', 'Foundation'
    SPECIALIZATION = 'Specialization', 'Specialization'
    CERTIFICATION_PROFESSIONAL = 'Certification/Professional', 'Certification/Professional'


class CourseCategory(BaseModel):
    name = models.CharField(max_length=100, unique=True),
    slug = AutoSlugField(populate_from='name', unique=True)
    image = models.ImageField(upload_to='course_category_images')
    description = models.TextField(null=True)
    category_status = models.CharField(max_length=50, choices=CourseStatus)

    class Meta:
        verbose_name = "Course Category"
        verbose_name_plural = "Course Categories "
        db_table = "course_category"
        ordering = ("-created_at",)

    def __str__(self):
        return self.name


class Course(BaseModel):
    title = models.CharField(max_length=200, unique=True)
    slug = AutoSlugField(populate_from='title', unique=True)
    description = models.TextField()
    category = models.ForeignKey(CourseCategory, on_delete=models.DO_NOTHING)
    image = models.ImageField(upload_to='course_images/', null=True, blank=True)
    duration = models.DurationField()
    difficulty_level = models.CharField(max_length=50, choices=DifficultyLevel)
    status = models.CharField(max_length=50, choices=CourseStatus)

    class Meta:
        verbose_name = "Course"
        verbose_name_plural = "Courses"
        ordering = ['title']

    def __str__(self):
        return self.title

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reversed('course_details', args=[str(self.slug)])

    def calculate_total_duration(self):
        total_duration = self.module_set.annotate(
            total_duration=Sum('videolesson__duration')
        ).aggregate(total=Sum('total_duration'))['total']
        return total_duration or 0

    def enrollment_count(self):
        return self.course_enroll_set.count()

    def average_rating(self):
        reviews = set.course_review_set.all()
        if reviews:
            total_rating = sum(review.rating for review in reviews)
            return total_rating / len(reviews)
        else:
            return 0



class Module(BaseModel):
    title = models.CharField(max_length=250)
    description = models.TextField()
    image = models.ImageField(upload_to='module_images/', blank=True, null=True)
    order = models.PositiveIntegerField(default=0)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    status = models.CharField(max_length=50, choices=CourseStatus)

    class Meta:
        verbose_name = "Module"
        verbose_name_plural = "Modules"
        ordering = ['title']
        unique_together = ('course', 'title')

    def __str__(self):
        return f"{self.title}"



class VideoLesson(BaseModel):
    module = models.ForeignKey(Module, on_delete=models.CASCADE, related_name='video_lessons')
    title = models.CharField(max_length=200)
    video_url = models.URLField()
    description = models.TextField(blank=True, null=True)
    duration = models.DurationField(help_text=_("Duration of the video lesson"))
    order = models.PositiveIntegerField(default=0)
    status = models.CharField(max_length=50, choices=CourseStatus)

    class Meta:
        verbose_name = "Video Lesson"
        verbose_name_plural = "Video Lessons"
        ordering = ['title']
        unique_together = ('module', 'title')


    def __str__(self):
        return self.title


class Material(BaseModel):
    module = models.ForeignKey(Module, on_delete=models.CASCADE, related_name='materials')
    title = models.CharField(max_length=200, db_index=True)
    file = models.FileField(upload_to='materials/', validators=[
        FileExtensionValidator(allowed_extensions=['pdf', 'docx', 'pptx', 'xlsx', 'txt'])])
    description = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = _("Material")
        verbose_name_plural = _("Materials")
        ordering = ['title']
        unique_together = ('module', 'title')


    def __str__(self):
        return self.title